//
//  ManejadorAgenda.swift
//  AgendaPractica1
//
//  Created by Macbook on 30/10/18.
//  Copyright © 2018 Banco Azteca. All rights reserved.
//

import Foundation


class ManejadorAgenda{
    var listaEventos : [Evento] = []
    var listaContactos : [Contacto] = []
    
    
    func agregarContacto(contacto : Contacto) ->Void{
        listaContactos.insert(contacto, at: listaContactos.endIndex)
    }
    
    func mostrarContactos() -> Void{
        for contacto in listaContactos {
            print("Contactos \n")
            print("\(contacto.toStringContacto())")
            print("--------------------------------------------------------")
        }
    }
    
    func agregarEvento(ev : Evento) ->Void{
        if(self.listaEventos.count == 0){
            self.listaEventos.append(ev)
        }else{
            for item in self.listaEventos{
                if item.idEvento == ev.idEvento {
                    print("El evento Id: \(ev.idEvento), asunto:\(ev.asunto) ya esta registrado")
                    break
                }else{
                    self.listaEventos.append(ev)
                }
            }
        }
        
        
        var i = 0
        var existeEvento = false
        var esAsistente = false
        while i < self.listaContactos.count{
            existeEvento = false
            esAsistente = false
            let listaEv = self.listaContactos[i].listaEventosContacto
            // Se valida si el contacto no esta en la lista dse asistentes si no se lo brinca
            /*for idAsist in ev.listaContactosAsistentes {
                if idAsist != self.listaContactos[i].idContacto{
                    esAsistente=false
                }else{
                    esAsistente=true
                    break
                }
            }
            if !esAsistente {
                continue        //se brinca al siguiente contacto
            }*/
            
            for item in listaEv{
                if item == ev.idEvento{
                    print("\(self.listaContactos[i].obtieneNombre()) ya tiene programado este evento: \(ev.asunto)")
                    existeEvento = true
                    break
                }
            }
            
            if existeEvento == false {
                print("Evento: \(ev.asunto) agregado para: \(self.listaContactos[i].obtieneNombre())")
                self.listaContactos[i].listaEventosContacto.append(ev.idEvento)
            }
            i = i + 1;
        }
    }
    
    
    func obtieneNombrePorId(id : Int) -> String {
        var nombre : String = ""
        for c in listaContactos {
            if c.idContacto == id {
                nombre = c.obtieneNombre();
                break
            }
        }
        return nombre
    }
    
    func mostraEventos() -> Void {
        print(listaEventos)
    }
}
