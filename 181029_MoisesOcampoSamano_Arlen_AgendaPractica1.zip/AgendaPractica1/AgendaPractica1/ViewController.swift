//
//  ViewController.swift
//  AgendaPractica1
//
//  Created by Macbook on 30/10/18.
//  Copyright © 2018 Banco Azteca. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        var contactNum: Int = 0;
        
        let manejadorAgenda = ManejadorAgenda()
        
        //agregando Contacto
        contactNum = contactNum + 1
        var domicilio = Domicilio(calle: "Hidalgo", numero: 81, colonia: "Centro", poblacion: "Jojutla", municipio: "Jojutla", estado: "Morelos", cp: 62456)
        var contacto = Contacto(id: contactNum, nombre: "Juan", apePat: "Perez", apeMat: "Gomez", fNac: "13/04/1980", domic: domicilio, tel: "7345623450", parentesco: Parentesco._PROPIETARIO, empresa: "El programador Feliz", email: "jperezg@hotmail.com")
        manejadorAgenda.agregarContacto(contacto: contacto)
        
        
        //agregando Contacto
        contactNum = contactNum + 1
        domicilio = Domicilio(calle: "Vicente Guerrero", numero: 100, colonia: "El Valle", poblacion: "Mazatlan", municipio: "Mazatlan", estado: "Sinaloa", cp: 46652)
        contacto = Contacto(id: contactNum, nombre: "Carlos", apePat: "Lopez", apeMat: "Martinez", fNac: "01/08/1986", domic: domicilio, tel: "555362838", parentesco: Parentesco._TRABAJO, empresa: "El programador Feliz", email: "carloslm@gmail.com")
        manejadorAgenda.agregarContacto(contacto: contacto)
        
        
        
        //agregando Contacto
        contactNum = contactNum + 1
        domicilio = Domicilio(calle: "Iturbide", numero: 40, colonia: "El Camino Real", poblacion: "Cuernavaca", municipio: "Cuernavaca", estado: "Morelos", cp: 76768)
        contacto = Contacto(id: contactNum, nombre: "Luis", apePat: "Jaimes", apeMat: "Toledo", fNac: "01/12/1990", domic: domicilio, tel: "5545767877", parentesco: Parentesco._AMIGO, empresa: "TATTA Consultores", email: "ljt90@gmail.com")
        
        manejadorAgenda.agregarContacto(contacto: contacto)
        
        
        //agregando Contacto
        contactNum+=contactNum
        domicilio = Domicilio(calle: "Buenavista", numero: 100, colonia: "El solitario", poblacion: "Iguala", municipio: "Iguala", estado: "Guerrero", cp: 46652)
        contacto = Contacto(id: contactNum, nombre: "Alfonso", apePat: "Camacho", apeMat: "Orriz", fNac: "13/09/1993", domic: domicilio, tel: "5545767877", parentesco: Parentesco._AMIGO, empresa: "Consultores SA", email: "alcogmail.com")
        
        manejadorAgenda.agregarContacto(contacto: contacto)
        
        
        manejadorAgenda.mostrarContactos()
        
        
        
        var listaAsistentes = [1,3]
        var evento = Evento(id: 1001, f: "01/11/2018", h: 9, l: "Explanada Elektra", a: "Reunion de Daily Meeting", invitados: listaAsistentes)
        manejadorAgenda.agregarEvento(ev : evento)
        
        
        listaAsistentes = [2,4]
        evento = Evento (id: 1002, f: "30/10/2018", h: 8, l: "World Trade Center", a: "Curso swift Netec", invitados: listaAsistentes)
        manejadorAgenda.agregarEvento(ev : evento)
        print("EVENTOS: --------------------------")
        manejadorAgenda.mostraEventos();
        
        
        listaAsistentes = [0,1]
        evento = Evento (id: 1002, f: "30/10/2018", h: 8, l: "World Trade Center", a: "Curso swift Netec", invitados: listaAsistentes)
        manejadorAgenda.agregarEvento(ev : evento)
        print("EVENTOS: --------------------------")
        
        
        manejadorAgenda.mostraEventos();
    }


}

