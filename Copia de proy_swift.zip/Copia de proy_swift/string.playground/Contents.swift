import UIKit

var str = "Hello, playground"

//: Uso de indices en los Strings

str.insert("¡", at: str.startIndex)
str.insert("!", at: str.endIndex)
str.insert("s", at: str.index(before: str.endIndex))
str.insert(contentsOf: " guys", at: str.index(before: str.endIndex))

// Concatenación de Strings
print("..." + str)
print("Esto es: \(str)")


var s = "Buenos dias"
s = s + ", a todos"
print(s)
//s.insert(", a todos", at: s.endIndex)

var s2 = "Buenos dias"
print(s2)
s2.insert(contentsOf: ", a todos", at: s2.endIndex)
print(s2)

//print("Buenos dias")
//print("Buenoa dias, a todos")






