import UIKit

var str = "Hello, playground"

// Guard - Example 1

func greet(person: [String: String]) {
    guard let name = person["name"] else {
        return
    }
    print("Hello \(name)!")
    
    guard let location = person["location"] else {
        print("I hope the weather is nice near you.")
        return
    }
    print("I hope the weather is nice in \(location).")
}

greet(person: ["name": "John"])
// "Hello John!"
// "I hope the weather is nice near you."

greet(person: ["name": "Jane", "location": "Cupertino"])
// "Hello Jane!"
// "I hope the weather is nice in Cupertino.



var nombres = ["Juan","Pedro","Luis","Jose"]
//print(nombres[.count-1])
//print(nombres[nombres.count])
print(nombres[4])
