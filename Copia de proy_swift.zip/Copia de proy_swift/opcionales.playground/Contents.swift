import UIKit

var str = "Hello, playground"

//: Opcionales

var possibleNumber : String = "123"
var convertedNumber : Int? = Int(possibleNumber)
possibleNumber = "abc"
convertedNumber = Int(possibleNumber)

print(convertedNumber)
