import UIKit

var str = "Hello, playground"

// switch - Example 1

var action = "walk"
switch action {
case "jump":
    print("the character is jumping")
    
case "walk":
    print("the character is walking")
    
case "run":
    print("the character is running")
    
default:
    print("the character is waitting for you...")
}


var action1 = "a"
switch action1 {
case "a"..."z", "A"..."Z":
    print("the character is jumping")
    
case "a":
    print("the character is walking")
    
case "b":
    print("the character is running")
    
default:
    print("the character is waitting for you...")
}
