import UIKit

var str = "Hello, playground"

var myArray = [Int]()

var opciones : [Int] = []

var opciones1 : [Int] = [10, 26, 34, 48]

var opciones3 : [String] = ["diez","veinte","treinta"]


print(opciones1)
opciones1.insert(2, at: opciones1.endIndex)
print(opciones1)

opciones1.append(100)
print(opciones1)

opciones1.insert(140, at: opciones1.startIndex)
print(opciones1)

opciones1.remove(at: opciones1.endIndex-1)
print(opciones1)

opciones1.removeLast()
print(opciones1)

//opciones1.removeAll()
//print(opciones1)

//print("1,2,3,4,5,6,7,8,9,10")


//Remover al principio e insertar al final
var opciones4 : [Int] = [1,2,3,4,5,6,7,8,9,10]
print(opciones4)
var dato : Int = 0
for dato in opciones4 {
    opciones4.remove(at: opciones4.startIndex)
    opciones4.insert(dato, at: opciones4.endIndex)
    print(opciones4)
}


//otra forma
for _ in opciones4 {
    print(opciones4)
    opciones4.append(opciones4.removeFirst())
}

//Otra forma
/*for _ in opciones4 {
    
    opciones4.insert(opciones4.first!, at: opciones4.endIndex)
    opciones4.remove(opciones4.endIndex)
    print(opciones4)
    
}*/





