import UIKit

var str = "Hello, playground"

// If - Example 1

let languages = ["C","C++","Objective-C","Swift"]

for item in languages{
    if item == "Swift"{
        print("I like it \(item)")
    }else{
        print("\(item)")
    }
}    
