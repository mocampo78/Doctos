import UIKit

var str = "Hello, playground"

//Control de flujo (while / repeat-while)

// while - Example 1

var message : String = ""
var base = 5
var factorial = 1

base = 5
factorial = 1
var i = 1

while i<=base {
    factorial *= i
    i += 1
}

message = "\(base)! = \(factorial)"
print(message)

// while - Example 2

var iterations = false
i = 0

repeat {
    i += 1
    print("valor de i: \(i)")
}while (iterations != false)

