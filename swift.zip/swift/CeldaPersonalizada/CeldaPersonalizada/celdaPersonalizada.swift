//
//  celdaPersonalizada.swift
//  CeldaPersonalizada
//
//  Created by Macbook on 01/11/18.
//  Copyright © 2018 Banco Azteca. All rights reserved.
//

import UIKit

class celdaPersonalizada: UITableViewCell {

    @IBOutlet weak var imgFotos: UIImageView!
    @IBOutlet weak var lblFotos: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
