//
//  ViewController.swift
//  CeldaPersonalizada
//
//  Created by Macbook on 01/11/18.
//  Copyright © 2018 Banco Azteca. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    @IBOutlet weak var tblFotos: UITableView!
    
    let fotos = ["foto1", "foto2", "foto3","foto4","foto5", "foto6"]
    let fotosExt = ["foto1.jpg", "foto2.jpg", "foto3.jpg","foto4.jpg","foto5.jpg", "foto6.jpeg"]
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return fotos.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let celda = tableView.dequeueReusableCell(withIdentifier: "celda", for: indexPath) as? celdaPersonalizada
        //celda.textLabel?.text = fotos[indexPath.row]
        celda?.lblFotos.text = fotos[indexPath.row]
        celda?.imgFotos.image = UIImage(named: fotosExt[indexPath.row])
        return celda!
    }
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        self.tblFotos.delegate = self
        self.tblFotos.dataSource = self
        
    }


}

