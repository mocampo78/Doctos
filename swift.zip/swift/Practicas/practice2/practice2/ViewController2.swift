//
//  ViewController2.swift
//  practice2
//
//  Created by Macbook on 31/10/18.
//  Copyright © 2018 Banco Azteca. All rights reserved.
//

import UIKit

class ViewController2: UIViewController {

    @IBOutlet weak var lblNotificacion: UILabel!
    @IBOutlet weak var txtEmail: UITextField!
    
    @IBOutlet weak var txtPassword: UITextField!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        txtPassword.isSecureTextEntry=true
    }
    
    
    @IBAction func btnIngresaFace(_ sender: UIButton) {
        if !validaDatos() {
            return
        }
        validaLogin(mje : "NO HAY CONEXION A INTERNET")
    }
    @IBAction func btnIngresa(_ sender: UIButton) {
        if !validaDatos(){
            return
        }
        validaLogin(mje : "USUARIO NO REGISTRADO")
    }
    
    func validaDatos() -> Bool {
        if txtEmail.text == "" {
            lblNotificacion.text = "Ingrese Email"
            return false
        }else{
            if !isValidEmail(string : txtEmail.text!){
                lblNotificacion.text = "Ingrese un Email valido"
                return false
            }
        }
        
        if txtPassword.text == "" {
            lblNotificacion.text = "Ingrese Contraseña"
            return false
        }
        
        
        return true
    }
    
    func isValidEmail(string: String) -> Bool {
        let emailReg = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}"
        let emailTest = NSPredicate(format:"SELF MATCHES %@", emailReg)
        return emailTest.evaluate(with: string)
    }
    
    func validaLogin(mje : String) ->Void {
        lblNotificacion.text = mje
    }

}
