//
//  ViewController4.swift
//  AgendaGraficaPractica3
//
//  Created by mos on 11/1/18.
//  Copyright © 2018 Banco Azteca. All rights reserved.
//

import UIKit

class ViewController4: UIViewController,UITableViewDelegate,UITableViewDataSource, UIPickerViewDelegate, UIPickerViewDataSource {
    
    
    
    @IBOutlet weak var tblAsistentesEvento: UITableView!
    @IBOutlet weak var txtLugar: UITextField!
    
    @IBOutlet weak var txtAsunto: UITextField!
    
    
    
    var fecha : String = ""
    var hora: String = ""
    
    let manejadorAgenda = ManejadorAgenda()
    
    
    //_________________ Hande pickerView______________________________
    @IBOutlet weak var pkvContactos: UIPickerView!
    var asistentesContactos : [String] = []
    var asistenteSeleccionado : String = ""
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return self.manejadorAgenda.listaContactos.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return self.manejadorAgenda.listaContactos[row].obtieneNombre()
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        self.asistenteSeleccionado = self.manejadorAgenda.listaContactos[row].obtieneNombre();
        
    }
    
    //____________________Handle table view____________________________
    func numberOfSections(in tableView: UITableView) -> Int {
        return self.asistentesContactos.count
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let celda = tableView.dequeueReusableCell(withIdentifier: "celda", for: indexPath)
        let sec = indexPath.section
        celda.textLabel?.text = "\(self.asistentesContactos[sec])"
        return celda
    }
    

    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        self.manejadorAgenda.simulaAgenda()
        //self.tblAsistentesEvento.isHidden=true
        
        self.pkvContactos.dataSource = self
        self.pkvContactos.delegate = self
        self.tblAsistentesEvento.dataSource = self
        self.tblAsistentesEvento.delegate = self
        
        //self.tblAsistentesEvento.isHidden = false
    }
    
    
    @IBAction func btnAgregaAsistente(_ sender: UIButton) {
        if (self.asistentesContactos.count == 0){
        self.asistentesContactos.append(asistenteSeleccionado)
            mensaje(mje: "Se agrego \(asistenteSeleccionado)")
        }else {
            if (self.asistentesContactos.contains(asistenteSeleccionado)){
                mensaje(mje: "Ese contacto ya esta agregado")
            } else {
                self.asistentesContactos.append(asistenteSeleccionado)
                mensaje(mje: "Se agrego \(asistenteSeleccionado)")
            }
        }
        //mensaje(mje :"Asistentes \(self.asistentesContactos)")
        print(self.asistentesContactos)
        self.tblAsistentesEvento.reloadData()
       
    }
    
    
    @IBAction func btnRegistrar(_ sender: UIButton) {
        if(fecha=="" || hora == ""){
            mensaje(mje: "Seleccione la fecha y hora del evento")
            return
        }
        
        if(txtLugar.text == ""){
            mensaje(mje: "Indique el lugar del evento")
            return
        }
        
        if(txtAsunto.text == ""){
            mensaje(mje: "Indique el asunto del evento")
            return
        }
        
        if(self.asistentesContactos.isEmpty){
            mensaje(mje: "Debe agregar Asistentes a este evento")
            return
        }

        // Aqui agregaria a los eventos
        let evento = Evento(id: 1001, f: fecha, h: 9, l: txtLugar.text!, a: txtAsunto.text!, invitados: self.asistentesContactos)
        self.manejadorAgenda.agregarEvento(ev : evento)
        
        mensaje(mje: "Se creo el registro del evento. Se notificara a los contactos de su agenda")
        
    }
    
    
    @IBAction func dpkFecha(_ sender: UIDatePicker) {
        let dateFormatter: DateFormatter = DateFormatter()
        let timeFormatter: DateFormatter = DateFormatter()
        dateFormatter.dateFormat = "MM/dd/yyyy"
        timeFormatter.dateFormat = "HH"
        fecha = dateFormatter.string(from: sender.date)
        hora = timeFormatter.string(from: sender.date)
    }
    
    func mensaje(mje : String) -> Void {
        let alerta: UIAlertController = UIAlertController.init(title: "Registro de Evento", message: mje, preferredStyle: UIAlertController.Style.alert);
        
        let okAlerta: UIAlertAction = UIAlertAction.init(title: "Aceptar", style: UIAlertAction.Style.default, handler: nil);
        
        
        alerta.addAction(okAlerta)
        
        
        present(alerta, animated: true, completion: nil);
    }
}
