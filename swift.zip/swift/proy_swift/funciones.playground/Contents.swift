import UIKit

var str = "Hello, playground"

func greet2(_ person: String = "guy", on day: String) {
    print("Hello \(person) today is \(day)!")
}

var greeting : () = greet2(on: "friday")
greeting = greet2("Roger", on:"saturday")

var greeting2 : (String,String) -> () = greet2
greeting2("Roger","sunday")



print("Funciones dentro de funciones")
func addTwoNum(a:Int,b:Int) -> Int{
    return a+b
}

func mutiplyTwoNum(a:Int, b:Int) -> Int{
    return a*b
}

func restarDosNumeros(a:Int, b:Int) -> Int{
    return a-b
}

func divisionDosNumeros(a:Int, b:Int) -> Int{
    if(b == 0){
        print("Division entre 0 invalida")
        return 0
    }
    return a/b
}

func moduloDosNumeros(a:Int, b:Int) -> Int{
    if(b == 0){
        print("Division entre 0 invalida")
        return 0
    }
    return a%b
}

func factorialNumero(a:Int, b:Int) -> Int{
    var factorial : Int = 1;
    for indice in a...b {
        factorial *= indice
    }
    return factorial;
}

//Otra forma
func f(a:Int) -> Int{
    return (a==1) ? 1 : f(a:a-1) * a
}


func printMathResult(operation: (Int,Int) -> Int,a: Int,b: Int) -> Void{
    print("Result: \(operation(a,b))")
}

func printMathResult(operation: (Int) -> Int,a: Int) -> Void{
    print("Result: \(operation(a))")
}

printMathResult(operation: mutiplyTwoNum, a: 2, b: 3)
printMathResult(operation: addTwoNum, a: 2, b: 3)
printMathResult(operation: restarDosNumeros, a: 2, b: 3)
printMathResult(operation: divisionDosNumeros, a: 12, b: 3)
printMathResult(operation: moduloDosNumeros, a: 120, b: 7)
printMathResult(operation: factorialNumero, a: 3, b: 6)
printMathResult(operation: f, a: 5)


