import UIKit

var str = "Hello, playground"


// for-in - Example 1
var base = 5
var factorial = 1

for index in 1...base {
    factorial *= index
}

let resp = "\(base)! = \(factorial)"
print(resp)

// for-in - Example 2
var output = ""
let myScores = ["English":8,"Chemistry":7,"Physics":9,"Biology":7]

for (subject,score) in myScores {
    print("My score in \(subject) is \(score)")
}

