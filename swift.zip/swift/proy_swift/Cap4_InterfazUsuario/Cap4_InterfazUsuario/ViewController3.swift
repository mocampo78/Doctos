//
//  ViewController3.swift
//  Cap4_InterfazUsuario
//
//  Created by Macbook on 31/10/18.
//  Copyright © 2018 Banco Azteca. All rights reserved.
//

import UIKit

class ViewController3: UIViewController {

    let myActivityIndicator = UIActivityIndicatorView(
        style: UIActivityIndicatorView.Style.gray)
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        myActivityIndicator.center = view.center
        myActivityIndicator.hidesWhenStopped = false
        myActivityIndicator.color = UIColor.red
        myActivityIndicator
       //myActivityIndicator.startAnimating()
        //myActivityIndicator.stopAnimating()
        self.view.addSubview(myActivityIndicator)
        
        
        //        MARK :- PROGESSVIEW
        
        creaProgressView()
        
        //    MARK :- STEPPER
        creaStepper()
        
        //    MARK :- DATEPICKER
        creaDatePicker()
    }
    
    @IBAction func btnIniciar(_ sender: UIButton) {
         myActivityIndicator.startAnimating()
    }
    
    @IBAction func btnParar(_ sender: UIButton) {
        myActivityIndicator.stopAnimating()
    }
        
    
    
    var seconds : Float = 0
    var timer : Timer!
    var myProgressView : UIProgressView!
    
    func creaProgressView(){
        
        myProgressView = UIProgressView(progressViewStyle: .default)
        myProgressView.frame.origin = CGPoint(x:75,y:375)
        myProgressView.frame.size = CGSize(width:300,height:150)
        //myProgressView.center.x = self.view.center.x
        myProgressView.progress = 0
        myProgressView.progressTintColor = UIColor.red
        myProgressView.trackTintColor = UIColor.lightGray
        self.view.addSubview(myProgressView)
        exTimer()
        
    }
    
    func exTimer() {
        timer = Timer.scheduledTimer(timeInterval: 0.5,
                                     target: self, selector: #selector(self.updateProgressView),
                                     userInfo: nil, repeats: true)
    }
    
    
    @objc func updateProgressView() {
        seconds += 1
        if seconds <= 10 {
            myProgressView.setProgress(seconds / 10, animated: true)
            print("\(seconds * 10)%")
        } else {
            timer.invalidate()
        }
    }
    
    
    
    //    MARK :- STEPPER
    func creaStepper(){
        
        let myStepper = UIStepper (frame:CGRect(x:115, y:680, width:0, height:0))
        myStepper.wraps = false
        myStepper.autorepeat = true
        myStepper.maximumValue = 10
        myStepper.addTarget(self,
                            action:#selector(stepperValueChanged(sender:)),
                            for: .valueChanged)
        self.view.addSubview(myStepper)
        
    }
    
    @objc func stepperValueChanged(sender: UIStepper){
        
        print("Value stepper: \(Int(sender.value).description)")
        
    }
    
    
    
    // MARK: - DatePiker
    
    func creaDatePicker(){
        
        let myDatePicker = UIDatePicker(
            frame: CGRect(x: 25, y: 100, width: 300, height: 200))
        myDatePicker.center.x = self.view.center.x
        myDatePicker.datePickerMode = UIDatePicker.Mode.dateAndTime
        myDatePicker.backgroundColor = UIColor.white
        myDatePicker.addTarget(self,
                               action: #selector(datePickerValueChanged), for: .valueChanged)
        self.view.addSubview(myDatePicker)
        
    }
    
    @objc func datePickerValueChanged(sender :UIDatePicker){
        let dateFormatter: DateFormatter = DateFormatter()
        dateFormatter.dateFormat = "MM/dd/yyyy hh:mm a"
        let selectedDate: String = dateFormatter.string(from: sender.date)
        print("Selected value \(selectedDate)")
    }

    
    
    @IBAction func btnAlerta(_ sender: UIButton) {
        let alerta: UIAlertController = UIAlertController.init(title: "App dice", message: "Hola, has presionado el boton", preferredStyle: UIAlertController.Style.alert);
        
        let okAlerta: UIAlertAction = UIAlertAction.init(title: "Aceptar", style: UIAlertAction.Style.default, handler: nil);
        
        let okAlerta2 = UIAlertAction.init(title: "Cancelar", style: .destructive, handler: nil)
        
        alerta.addAction(okAlerta)
        alerta.addAction(okAlerta2)
        
        present(alerta, animated: true, completion: nil);
    }
    
    
    
}
