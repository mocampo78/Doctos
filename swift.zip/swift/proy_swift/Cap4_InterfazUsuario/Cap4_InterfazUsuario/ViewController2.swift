//
//  ViewController2.swift
//  Cap4_InterfazUsuario
//
//  Created by Macbook on 30/10/18.
//  Copyright © 2018 Banco Azteca. All rights reserved.
//

import UIKit

class ViewController2: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        let imageName = "homero.jpg"
        let image = UIImage(named: imageName)
        let imageView = UIImageView(image: image!)
        imageView.frame = CGRect(x: 160, y: 215, width: 50, height: 50)
        view.addSubview(imageView)
        
        
        // MARK: - Ejemplo 1 de UITextView
        
        let str : NSString = "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque arcu urna, interdum nec auctor ac, ultrices quis tellus. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Nunc rhoncus semper facilisis."
        
        let textView = UITextView (frame: CGRect(x: 15, y: 320, width: 350, height: 50))
        
        textView.text = str as String
        textView.isEditable = false
        textView.layer.borderWidth=2
        self.view.addSubview(textView)
        
        
        // Ejemplo 2 de UITextView
        let myBoldWord = str.range(of: "Lorem ipsum")
        
        let myMutableString =
            NSMutableAttributedString(
                string: str as String,
                attributes:
                [NSAttributedString.Key.font: UIFont(name: "Georgia",size: 18.0)!])
        
        myMutableString.addAttribute(
            NSAttributedString.Key.font,
            value: UIFont(name: "Helvetica Neue", size: 36.0)!,
            range: myBoldWord)
        
        let textView2 = UITextView(frame: CGRect(x: 15, y: 385, width: 350, height: 150))
        textView2.attributedText = myMutableString
        textView2.layer.borderWidth=1
        self.view.addSubview(textView2)
        
        
        // MARK : -Ejemplo de Slider
        let mySlider = UISlider(frame:CGRect(x:15, y:610, width:280, height:20))
        mySlider.minimumValue = 0
        mySlider.maximumValue = 100
        mySlider.isContinuous = false
        mySlider.tintColor = UIColor.red
        mySlider.value = 50
        mySlider.addTarget(self,
                           action:#selector(sliderValueDidChange(sender:)),
                           for: .valueChanged)
        self.view.addSubview(mySlider)
        
        
        // MARK : -Ejemplo de Switch
        let mySwitch=UISwitch(frame:CGRect(x:15, y:535, width:0, height:0));
        mySwitch.isOn = true
        mySwitch.setOn(false, animated: true);
        mySwitch.tintColor = UIColor.red
        mySwitch.onTintColor = UIColor.blue
        mySwitch.addTarget(self,
                           action:#selector(switchValueDidChange(sender:)),
                           for: .valueChanged);
        self.view.addSubview(mySwitch);
    }
    

    @objc func sliderValueDidChange(sender:UISlider){
        print(sender.value)
    }

    
    @objc func switchValueDidChange(sender : UISwitch){
        print(sender.isOn)
        
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

    
}
