//
//  ViewController.swift
//  Cap4_InterfazUsuario
//
//  Created by Macbook on 30/10/18.
//  Copyright © 2018 Banco Azteca. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var lblName: UILabel!
    
    @IBOutlet weak var lblNombre: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        // UILabel
        let label = UILabel(frame: CGRect(x: 110, y: 50, width: 200, height: 50))
        label.textAlignment = .center
        label.text = "¿What´s your name?"
        label.layer.borderWidth = 6
        self.view.addSubview(label)
        
        
        lblName.text="Swift"
        lblNombre.textColor = UIColor.blue
        
        
        let button = UIButton()
        button.frame = CGRect(x: 85, y: 160, width: 200, height: 50)
        button.backgroundColor = UIColor.lightGray
        button.setTitle("Send ", for: .normal)
        button.addTarget(self, action: #selector(buttonAction), for: .touchUpInside)
        self.view.addSubview(button)
        
        
        // MARK:- UN TEXTFIELD
        let textField = UITextField(frame: CGRect(x: 85, y: 545, width: 200, height: 50))
        textField.textAlignment = NSTextAlignment.center
        textField.textColor = UIColor.red
        //textField.borderStyle = UITextBorderStyle.line
        textField.placeholder = "Your name here ..."
        self.view.addSubview(textField)
    }


    @IBAction func btnEntrar(_ sender: UIButton) {
        lblName.text = "Woohoooo"
    }
    
    @objc func buttonAction(){
        lblNombre.text = "Que tranza con Carranza!!"
    }
    
    @IBAction func txtNombre(_ sender: UITextField) {
        lblName.text = sender.text
    }
    
    
}

