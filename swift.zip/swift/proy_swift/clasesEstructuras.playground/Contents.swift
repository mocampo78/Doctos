import UIKit

var str = "Hello, playground"

//: Clases y Estructuras
// En el siguiente ejemplo se puede apreciar la herencia a partir de la clase MediaItem.

class MediaItem {
    var name: String
    init(name: String) {
        self.name = name
    }
}

class Movie: MediaItem {
    var director: String
    init(name: String, director: String) {
        self.director = director
        super.init(name: name)
    }
}

class Song: MediaItem {
    var artist: String
    init(name: String, artist: String) {
        self.artist = artist
        super.init(name: name)
    }
}



var musica = Song(name : "This love", artist: "Maroon Five")
var music = Song.init(name: "X", artist: "Elvis")



var peli = Movie(name: "SuperMan", director: "X")
var pelic = Movie.init(name: "Start Treck", director: "X")


struct Peliculas{
    var name: String
    var director: String
}


struct Movies{
    var name : String
    var director: String
}

struct canciones {
    var name : String
}


var res = Peliculas.init(name: "", director: "")
var pel = Movie.init(name: "CasaBlanca", director: "X")



