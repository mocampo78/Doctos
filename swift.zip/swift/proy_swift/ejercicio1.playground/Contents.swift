import UIKit

var str = "Hello, playground"
print(str)

// Ejemplo del uso de VAR
var distance: Double
distance = 10
print(distance)

// Descomentar para probar el ejemplo de VAR
//distance = 15
//print(distance)

// Ejemplo del uso de LET
let velocity: Double
velocity = 10
print(velocity)

// Descomentar para probar el ejemplo de LET
//velocity = 15
//print(velocity)


//: Manipulación de Strings
var strMut : String
strMut = "mi string mutable"
strMut = "editando el string"

let strNoMut : String
strNoMut = "mi string no mutable"
//strNoMut = "esto no es un string mutable" // error




// Declaración de tipo en forma explicita.
let myExplicitValue : String = "My Weight is"
let myExplicitValue2 : Double = 70

// Declaración de tipo en forma Implícita.
let myImplicitValue = "My Weight is"

// Para incluir una variable (no String) dentro de un String utiliza \().
let yourWeight = "Your weight is \(myExplicitValue2)"

let nombre = "Fulano"
let saludo = "Hola: "+nombre
print(saludo)


// Los Strings no permiten la conversión implícita de tipo de dato.
let myWeight = myImplicitValue + String(myExplicitValue2)

