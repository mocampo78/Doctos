import UIKit

var str = "Hello, playground"

//_______________SET

var mySet = Set<Character>()
var conjunto : Set<String> = []
var conjuntoA: Set<String> = ["alumno","profesor","secretaria","delegado"]
var conjuntoB: Set<String> = ["conserje","director","profesor"]

print("Interseccion")
print(conjuntoA.intersection(conjuntoB))

print("Diferencia Simetrica")
print(conjuntoA.symmetricDifference(conjuntoB))

print("Union")
print(conjuntoA.union(conjuntoB))

print("substraccion")
print(conjuntoA.subtract(conjuntoB))




//Ejercicios (practica)
var elementsA: Set<String> = ["a","b","c","d","e"]
var elementsB: Set<String> = ["a","b","f","g","h","u","v"]
var elementsC: Set<String> = ["h","g","j","t","v"]
var elementsD: Set<String> = ["j","k","l","m","a","z"]

print("\nUnion D y A")
print(elementsD.union(elementsA))

print("\nUnion C y B")
print(elementsC.union(elementsB))

print("\nElementos Comunes de A y B")
print(elementsA.intersection(elementsB))

print("\nElementos Diferentes de C y D")
print(elementsC.symmetricDifference(elementsD))

print("\nLos Elementos de B estan en C?")
print(elementsB.intersection(elementsC))
print("Respuesta: NO. Faltan algunos")
//Usar subset

print("\nLos Elementos de C que no estan en D")
print(elementsC.subtracting(elementsD))

print("\nLos Elementos de A que no estan en B")
print(elementsA.subtracting(elementsB))

print("\nExisten valores comunes entre A y D?")
print(elementsA.intersection(elementsD))
if elementsA.intersection(elementsD).count > 0 {
    print("Respuesta: SI")
}else{
    print("Respuesta: NO")
}


print("\nExisten valores comunes entre C y B?")
print(elementsC.intersection(elementsB))
//Usar distJoin
if elementsC.intersection(elementsB).count > 0 {
    print("Respuesta: SI...")
}else{
    print("Respuesta: NO")
}


