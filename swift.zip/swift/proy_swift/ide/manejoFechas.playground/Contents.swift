import UIKit

var str = "Hello, playground"

var dateString = "21/02/1989"
var dateStringFormatter = DateFormatter()
dateStringFormatter.dateFormat = "dd/MM/yyyy"
var dateFromString = dateStringFormatter.date(from: dateString)

var edad = Calendar.current.dateComponents([.year], from: dateFromString!, to :Date())
var edad1 = String (edad.year!)
print(edad)
print(edad1)
