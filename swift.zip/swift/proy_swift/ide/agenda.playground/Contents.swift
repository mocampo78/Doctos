import UIKit

var str = "Hello, playground"



//-------------------------------Clase Evento --------------------------------
class Evento{
    var idEvento : Int = 0
    var fecha : String = ""
    var hora : Int
    var lugar : String = ""
    var listaContactosAsistentes : Array<Int>
    init(id: Int, f : String, h : Int, l : String) {
        self.idEvento = id
        self.fecha = f
        self.hora = h
        self.lugar = l
    }
    
}



class ManejadorAgenda{
    var listaEventos : [Int : Evento] = [:]
    var listaContactos : [Contacto] = []
    
    
    
    func programarEvento(id: Int, ev:Evento) -> Void{
        
    }

    func AgregarContacto(contacto : Contacto) ->Void{
        listaContactos.insert(contacto, at: listaContactos.endIndex)
    }
    
    func AgregarEvento(id: Int, ev : Evento) ->Void{
        for c in listaContactos {
            let listEv = c.obtieneListaEventos()
            for i in listEv {
                if i == id{
                    print("El contacto: \(c.obtieneNombre()) ya tiene programado este evento o tiene conflicto")
                }else{
                    listaEventos.updateValue(ev,forKey: id);
                }
            }
        }
    }
}


//----------------------------Clase Domicilio ----------------------------------
class Domicilio{
    var calle : String = ""
    var numero : Int = 0
    var colonia : String = ""
    var poblacion : String = ""
    var municipio : String = ""
    var estado: String = ""
    var cp: Int = 0
    init(calle: String, numero : Int, colonia : String, poblacion : String, municipio : String, estado : String, cp : Int) {
        self.calle = calle
        self.numero = numero
        self.poblacion = poblacion
        self.municipio = municipio
        self.estado = estado
        self.cp = cp
    }
    
    func toStringDomicilio() -> Void{
        print("Domicilio\n  Calle: \(self.calle),       Num.: \(self.numero),       Col: \(self.colonia),      Poblacion:\(self.poblacion),     Municipio:\(self.municipio),        Estado:\(self.estado),      CP:\(self.cp)")
    }
    
}


//-------------------------Enum Parentesco--------------------------------------
enum Parentesco: String {
    case _MADRE = "Mama"
    case _PADRE = "Papa"
    case _HERMANO = "Hermano(a)"
    case _HIJO = "Hijo(a)"
    case _ESPOSO = "Esposo(a)"
    case _AMIGO = "Amigo(a)"
    case _TRABAJO = "Compañero(a) de Trabajo"
    case _PRIMO = "Primo(a)"
    case _TIO = "Tio(a)"
    case _ABUELO = "Abuelo(a)"
    case _CONOCIDO = "Conocido(a)"
    case _OTRO = "Otro Parentesco"
    case _NOCONOCIDO = "Desconocido"
}


//----------------------------Clase Persona----------------------------------------
class Persona{
    var nombre : String = ""
    var apePat : String = ""
    var apeMat : String = ""
    var fechaNac : String = ""
    var edad : Int = 0
    
    
    init(nombre : String, apePat : String, apeMat : String, fechaNac: String){
        self.nombre = nombre
        self.apePat = apePat
        self.apeMat = apeMat
        self.fechaNac = fechaNac    // debe llevar este formato dd/MM/yyyy
        self.edad = calculaEdad(fNac: fechaNac)
    }
    
    func calculaEdad(fNac : String) -> Int {
        let dateStringFormatter = DateFormatter()
        dateStringFormatter.dateFormat = "dd/MM/yyyy"
        let dateFromString = dateStringFormatter.date(from: fNac)
        let edad = Calendar.current.dateComponents([.year], from: dateFromString!, to :Date())
        let edad1 = Int (edad.year!)
        return edad1
    }
    
    func toStringPersona () -> Void {
        print ("Datos\n Nombre: \(self.nombre),      Ape. Paterno:\(self.apePat),        Ape. Materno: \(self.apeMat),        fecha Nac: \(self.fechaNac),      edad: \(self.edad)")
    }
    
    func obtieneNombre() -> String {
        return "\(self.nombre) \(self.apePat) \(self.apeMat)"
    }
}


//----------------------------Clase Contacto----------------------------------------

//https://itunes.apple.com/mx/app/xcode/id497799835?mt=12
class Contacto : Persona {
    var idContacto : Int = 0
    var telefono : String?
    var parentescoAgenda: Parentesco = Parentesco._NOCONOCIDO
    var domicilio : Domicilio?
    var empresa : String = ""
    var email : String?
    var listaEventosContacto : Array<Int>
    init(id: Int, nombre : String, apePat : String, apeMat : String, fNac: String, domic: Domicilio?, tel : String?, parentesco: Parentesco, empresa : String, email : String?){
        super.init(nombre: nombre, apePat: apePat, apeMat: apeMat, fechaNac: fNac)
        self.idContacto = id
        self.empresa = empresa
        self.email = email
        if let t = tel {
            self.telefono = t
        }else{
            self.telefono="Sin Numero"
        }
        self.parentescoAgenda = parentesco
        if let dom = domic {
            self.domicilio = Domicilio(calle: dom.calle, numero : dom.numero, colonia : dom.colonia, poblacion: dom.poblacion, municipio: dom.municipio, estado: dom.estado, cp: dom.cp)
            
        }
    }
    
    func obtieneListaEventos () -> Array<Int> {
        return self.listaEventosContacto;
    }
    
    func toStringContacto() -> Void {
        print("Datos de Contacto:\n     \(self.toStringPersona()),      domicilio:\(self.domicilio!.toStringDomicilio()),        Telefono:\(self.telefono!),     Parentesco:\(self.parentescoAgenda.rawValue)")
    }
   
}
