//
//  ViewController.swift
//  ElementoGraficoPicker
//
//  Created by Macbook on 31/10/18.
//  Copyright © 2018 Banco Azteca. All rights reserved.
//

import UIKit

class ViewController: UIViewController , UIPickerViewDelegate, UIPickerViewDataSource{
    
    
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 2
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        if(component == 0) {
            return autos.count
        }else{
            return autosMarca.count
        }
        
    }
    
    
    let autos : [String] = ["Sentra", "vocho", "Chevy", "Ferrari", "City"]
    let autosMarca : [String] = ["Nissan", "VW", "Chevrolet", "Ferrari", "Honda"]
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        if(component == 0) {
            return autos[row]
        }else{
            return autosMarca[row]
        }
    }

    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        if(component == 0) {
            print("fila: \(row), auto:\(autos[row]) ")
        }else{
            print("fila: \(row), auto:\(autosMarca[row]) ")
        }
        
    }
    
    
    @IBOutlet weak var pkAutos: UIPickerView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        self.pkAutos.delegate = self
        self.pkAutos.dataSource = self
        
    }


    
}

