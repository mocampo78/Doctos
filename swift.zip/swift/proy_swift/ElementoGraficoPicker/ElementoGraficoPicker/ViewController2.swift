//
//  ViewController2.swift
//  ElementoGraficoPicker
//
//  Created by Macbook on 31/10/18.
//  Copyright © 2018 Banco Azteca. All rights reserved.
//

import UIKit

class ViewController2: UIViewController, UIPickerViewDataSource, UIPickerViewDelegate {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        creaPickerView()
    }
    
    // MARK: - PickerView
    
    let myOptions : [String] = ["one","two","three","four"]
    let myPickerView = UIPickerView()
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return myOptions.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return myOptions[row]
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        print("Numero seleccionado : \(myOptions[row])")
    }
    
    func creaPickerView(){
        
        
        self.myPickerView.frame = CGRect(x:0, y:100, width:self.view.bounds.width, height:280)
        
        self.myPickerView.dataSource = self
        self.myPickerView.delegate = self
        
        self.view.addSubview(myPickerView)
        
    }
    
}
