//
//  ViewController.swift
//  TablaPersonalizada
//
//  Created by Macbook on 31/10/18.
//  Copyright © 2018 Banco Azteca. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {
    
    let usuarios : [String] = ["Yasmin", "Karina", "Lupita", "Iseila"]
    let direccion : [String] = ["Col. Doctores", "Col. del Valle", "Col. Napoles", "Col. La Joya"]
    
    let telefonos : [String] = ["89798789787", "787988799", "78989797", "88809890"]
    
    //definimos el numero de secciones (dianmico)
    func numberOfSections(in tableView: UITableView) -> Int {
        return usuarios.count
    }
    
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return usuarios[section]
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        //paso 1 numero de secciones
        return 2
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        //paso 2. Declarar celda
        let celda = tableView.dequeueReusableCell(withIdentifier: "celda", for: indexPath)
        let celda2 = tableView.dequeueReusableCell(withIdentifier: "celda2", for: indexPath)
        //En la celda se coloca la direccion
        let row = indexPath.row
        let sec = indexPath.section
        celda.textLabel?.text = direccion[sec]
        celda2.textLabel?.text = telefonos[sec]
        if(row==0){
            return celda
        }else{
            return celda2
        }
        
        /* Otra solucion
        if(row==0){
            return direccion[sec]
        }else{
            return telefonos[sec]
        }
        
         Otra solucion-- Ojo no siempre tendremos el item. Mejor usar Row. Row y sec siempre los tenemos
         if(indexPath.item==0){
            return direccion[sec]
         }else{
            return telefonos[sec]
         }
         
         */
        
    }

    @IBOutlet weak var tblUsuarios: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        self.tblUsuarios.dataSource = self
        self.tblUsuarios.delegate = self
    }


}

