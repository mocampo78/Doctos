//
//  ViewController.swift
//  TableViewExample
//
//  Created by Macbook on 31/10/18.
//  Copyright © 2018 Banco Azteca. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {
    
    let autos : [String] = ["Sentra", "vocho", "Chevy", "Ferrari", "City"]
    let autosMarca : [String] = ["Nissan", "VW", "Chevrolet", "Ferrari", "Honda"]
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return "seccion: \(section)"
    }
    
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if(section==0){
            return autos.count
        }else{
            return autosMarca.count
        }
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let celda = tableView.dequeueReusableCell(withIdentifier: "celda", for: indexPath)
        let row = indexPath.row
        celda.textLabel?.text = autos[row]
        celda.detailTextLabel?.text = autosMarca[row]
        return celda
       
    }
    

    @IBOutlet weak var tblAutos: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        self.tblAutos.dataSource=self
        self.tblAutos.delegate = self
    }


}

