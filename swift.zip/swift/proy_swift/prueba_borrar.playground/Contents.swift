import UIKit

var str = "Hello, playground"

for i in 20...35{
    switch i {
    case 20...25:
        print("es la fecha de mi cumpleaños")
    case 26...30: print("ya paso la fecha de mi cumpleaños")
    default: print("Error")
    }
    
}
