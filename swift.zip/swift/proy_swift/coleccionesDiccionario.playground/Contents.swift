import UIKit

var str = "Hello, playground"

var myDictionary : [Int : String]
var myDictionary1 : [String : String]

let myScores = ["English":8, "Chemistry":7, "Physics":9, "Biology":7]

for _ in myScores {
    print(myScores.keys)
}

for(subject,score) in myScores{
    print("My score in \(subject) is \(score)")
}
