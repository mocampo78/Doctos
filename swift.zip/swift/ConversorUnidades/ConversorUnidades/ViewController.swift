//
//  ViewController.swift
//  ConversorUnidades
//
//  Created by Macbook on 01/11/18.
//  Copyright © 2018 Banco Azteca. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource {
    
    
    @IBOutlet weak var pkvUnidadOrigen: UIPickerView!
    
    @IBOutlet weak var pkvUnidadDestino: UIPickerView!
  
    @IBOutlet weak var txtUnidadOrigen: UITextField!
    
    @IBOutlet weak var txtUnidadDestino: UITextField!
    
    
    let unidadesMedida = ["centimetro","metro","kilometro", "pulgada", "pie","yarda"]
    //Multiplos de unidades de medida
    let udsCmMedida : [Double] = [1, 0.01, 0.00001, 0.393701, 0.0328084, 0.0109361]
    let udsMtMedida : [Double] = [100, 1, 0.001, 39.3701, 3.28084, 1.09361]
    let udsKmMedida : [Double] = [100000, 1000, 1, 39370.1, 3280.84, 1093.61]
    let udsPulgMedida : [Double] = [2.54, 0.0254, 0.0000254, 1, 0.0833333, 0.0277778]
    let udsPieMedida : [Double] = [30.48, 0.3048, 0.0003048, 12, 1, 0.333333]
    let udsYardaMedida : [Double] = [91.44, 0.9144, 0.0009144, 36, 3, 1]
    
    
    var udMedidaOrigen : String = ""
    var udMedidaDestino : String = ""
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return self.unidadesMedida.count
    }
    
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return self.unidadesMedida[row]
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        self.txtUnidadDestino.text = ""
        if pickerView == pkvUnidadOrigen {
            self.udMedidaOrigen = self.unidadesMedida[row]
            print("Origen: \(self.udMedidaOrigen)")
        }else{
            self.udMedidaDestino = self.unidadesMedida[row]
            print("Destino: \(self.udMedidaDestino)")
        }
        
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        self.pkvUnidadOrigen.delegate = self
        self.pkvUnidadOrigen.dataSource = self
        
        self.pkvUnidadDestino.delegate = self
        self.pkvUnidadDestino.dataSource = self
        
        self.udMedidaOrigen = self.unidadesMedida[0]
        self.udMedidaDestino = self.unidadesMedida[0]
    }

    @IBAction func btnConvierte(_ sender: UIButton) {
        
        if (!validaNumero(string: txtUnidadOrigen.text!)){
            mensaje(mje: "Por favor ingrese un numero valido")
            txtUnidadOrigen.text=""
            return
        }
        
        let multiplo = devuelveMultiplo(udOrigen: self.udMedidaOrigen, udDestino: self.udMedidaDestino)
        print("Multiplo: \(multiplo)")
        
        let longOrigen : Double = Double(txtUnidadOrigen.text!)!
        //let longOrigen = (txtUnidadOrigen.text! as NSString).doubleValue
        print("cantidad Origen :\(longOrigen)")
        print("Valores:", longOrigen,"valor 2: ", multiplo)
        let resultado : Double = longOrigen * multiplo
        txtUnidadDestino.text = "\(resultado)"
        
    }
    
    func validaNumero(string: String) -> Bool {
        return NSPredicate(format: "SELF MATCHES %@", "[0-9]*").evaluate(with: string)
    }
    
    func mensaje(mje : String) -> Void {
        let alerta: UIAlertController = UIAlertController.init(title: "Conversion de Unidades", message: mje, preferredStyle: UIAlertController.Style.alert);
        
        let okAlerta: UIAlertAction = UIAlertAction.init(title: "Aceptar", style: UIAlertAction.Style.default, handler: nil);
        
        
        alerta.addAction(okAlerta)
        
        
        present(alerta, animated: true, completion: nil);
    }

    
    
    func devuelveMultiplo(udOrigen : String, udDestino : String) -> Double {
        var multiplo : Double = 0.0
        switch udOrigen {
            case "centimetro":
                multiplo = udsCmMedida[devuelveIndice(unidad: udDestino)]
                break
            case "metro" :
                multiplo = udsMtMedida[devuelveIndice(unidad: udDestino)]
                break
            case "kilometro" :
                multiplo = udsKmMedida[devuelveIndice(unidad: udDestino)]
                break
            case "pulgada" :
                multiplo = udsPulgMedida[devuelveIndice(unidad: udDestino)]
                break
            case "pie" :
                multiplo = udsPieMedida[devuelveIndice(unidad: udDestino)]
                break
            case "yarda" :
                multiplo = udsYardaMedida[devuelveIndice(unidad: udDestino)]
                break
            default:
                break
        }
        return multiplo
    }
    
    func devuelveIndice(unidad : String) ->Int{
        var indice = 0
        indice = unidadesMedida.lastIndex(of: unidad)!
        return indice
    }
}

