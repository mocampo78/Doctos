/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gs.sistemas.curso.be.modelos;

import com.gs.sistemas.curso.be.utilerias.Estado;
import com.gs.sistemas.curso.be.utilerias.TipoCuenta;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import com.gs.sistemas.curso.be.excepciones.SaldoInsuficienteException;

public abstract class Cuenta {
    private int numeroCuenta;
    private TipoCuenta tipoCuenta;
    private LocalDate fechaApertura;
    private double saldo;
    private Estado estado;
    private LocalDate fechaCancelacion;
    private List<Movimiento> movimientos;


    public Cuenta(int numeroCuenta, double saldo, TipoCuenta tipoCuenta){
        this.numeroCuenta=numeroCuenta;
        this.saldo=saldo;
        this.fechaApertura=LocalDate.now();
        this.estado=Estado.ACTIVO;
        this.tipoCuenta=tipoCuenta;
        this.fechaCancelacion=null;
        this.movimientos = new ArrayList<>();
    }
    
    public abstract void abono(double cantidad);
    public abstract void retiro(double cantidad) throws SaldoInsuficienteException;
    public abstract double consultaSaldo();
    public abstract void imprimirDatos();
    public abstract void consultaMovimientos();
    

    @Override
    public String toString() {
        return "Cuenta{" + "numeroCuenta=" + numeroCuenta + ", tipoCuenta=" + tipoCuenta + ", fechaApertura=" + fechaApertura + ", saldo=" + saldo + ", estado=" + estado + ", fechaCancelacion=" + fechaCancelacion + '}';
    }

    
    public List<Movimiento> getMovimientos() {
        return movimientos;
    }

    public void setMovimientos(List<Movimiento> movimientos) {
        this.movimientos = movimientos;
    }
    
     public TipoCuenta getTipoCuenta() {
        return tipoCuenta;
    }

    public void setTipoCuenta(TipoCuenta tipoCuenta) {
        this.tipoCuenta = tipoCuenta;
    }
    /**
     * @return the numeroCuenta
     */
    public int getNumeroCuenta() {
        return numeroCuenta;
    }

    /**
     * @param numeroCuenta the numeroCuenta to set
     */
    public void setNumeroCuenta(int numeroCuenta) {
        this.numeroCuenta = numeroCuenta;
    }

    /**
     * @return the fechaApertura
     */
    public LocalDate getFechaApertura() {
        return fechaApertura;
    }

    /**
     * @param fechaApertura the fechaApertura to set
     */
    public void setFechaApertura(LocalDate fechaApertura) {
        this.fechaApertura = fechaApertura;
    }

    /**
     * @return the saldo
     */
    public double getSaldo() {
        return saldo;
    }

    /**
     * @param saldo the saldo to set
     */
    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }

    /**
     * @return the estado
     */
    public Estado getEstado() {
        return estado;
    }

    /**
     * @param estado the estado to set
     */
    public void setEstado(Estado estado) {
        this.estado = estado;
    }

    /**
     * @return the fechacancelacion
     */
    public LocalDate getFechaCancelacion() {
        return fechaCancelacion;
    }

    /**
     * @param fechacancelacion the fechacancelacion to set
     */
    public void setFechaCancelacion(LocalDate fechaCancelacion) {
        this.fechaCancelacion = fechaCancelacion;
    }
}
