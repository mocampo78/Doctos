/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gs.sistemas.curso.be.modelos;

import com.gs.sistemas.curso.be.interfaces.ServicioACuentas;
import com.gs.sistemas.curso.be.utilerias.Estado;
import com.gs.sistemas.curso.be.utilerias.EstadoCliente;
import com.gs.sistemas.curso.be.utilerias.GeneraId;
import com.gs.sistemas.curso.be.utilerias.TipoCuenta;


import java.time.LocalDate;

import java.util.ArrayList;
import java.util.Optional;

/**
 *
 * @author 180514-GrupoSalinas
 */
public class Cliente extends Persona implements ServicioACuentas{
    private int idCliente;
    private EstadoCliente estadoCliente;
    private ArrayList<Cuenta> cuentas;

    public Cliente(int idCliente, String nombre, Domicilio domicilio, LocalDate fechaNacimiento, String rfc) {
        super(nombre, domicilio, fechaNacimiento, rfc);
        this.estadoCliente=EstadoCliente.ACTIVO;
        this.idCliente = idCliente;
        this.cuentas = new ArrayList<>();
    }


    @Override
    public String toString() {
        return  "Cliente{" + "idCliente=" + idCliente + ", cuentas=" + cuentas +"     " +super.toString()+ '}';
        
//        return  "Cliente{" + "idCliente=" + idCliente + 
//                ", cuentas=" + cuentas.stream()
//                .filter(cta -> cta.getEstado()==Estado.ACTIVO)            
//                +"     " +super.toString()+ '}';
    }

    @Override
    public void cancelarCuenta(int numeroCuenta) {
        Optional<Cuenta> cuenta = cuentas.stream()
                .filter(cta -> (cta.getNumeroCuenta()==numeroCuenta))
                .findFirst();
        if (cuenta.isPresent()) {
            Cuenta c= cuenta.get();
            c.setEstado(Estado.INACTIVO);
            c.setFechacancelacion(LocalDate.now());
        }
        //cuentas.removeIf(cta -> (cta.getNumeroCuenta()==numeroCuenta));
    }

    @Override
    public Cuenta consultarCuenta(int numeroCuenta) {
        Cuenta c = null;
        Optional<Cuenta> cuenta = cuentas.stream()
                .filter(cta -> (cta.getNumeroCuenta()==numeroCuenta))
                .findFirst();
        if (cuenta.isPresent()) {
            c= cuenta.get();
            System.out.println("Detalles de Cuenta: " + c);
        }else{
            System.out.println("La cuenta no existe!!!! ");
        }
        return c;
    }

    @Override
    public ArrayList<Cuenta> consultarCuentasCliente() {
        return cuentas;
    }

    @Override
    public void crearCuentaDeAhorros(double saldoinicial, double tasaDeInteresAnual) {
        Cuenta cuentaAhorro=new CuentaDeAhorros(GeneraId.getNextIdCuentaAhorro(),saldoinicial,tasaDeInteresAnual);
        cuentas.add(cuentaAhorro);
    }

    @Override
    public void crearCuentaDeCheques(double saldoinicial, double comisionMensual) {
        Cuenta cuentaCheques=new CuentaDeCheques(GeneraId.getNextIdCuentaCheques(),saldoinicial,comisionMensual);
        cuentas.add(cuentaCheques);
    }

    public int getIdCliente() {
        return idCliente;
    }

    public ArrayList<Cuenta> getCuentas() {
        return cuentas;
    }

    public void setCuentas(ArrayList<Cuenta> cuentas) {
        this.cuentas = cuentas;
    }
    
    public EstadoCliente getEstadoCliente() {
        return estadoCliente;
    }

    public void setEstadoCliente(EstadoCliente estadoCliente) {
        this.estadoCliente = estadoCliente;
    }
   
}
