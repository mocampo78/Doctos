/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gs.sistemas.curso.be.modelos;

import com.gs.sistemas.curso.be.excepciones.CuentaInexistenteException;
import com.gs.sistemas.curso.be.interfaces.ServicioACuentas;
import com.gs.sistemas.curso.be.utilerias.Estado;
import com.gs.sistemas.curso.be.utilerias.EstadoCliente;
import com.gs.sistemas.curso.be.utilerias.GeneraId;


import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.FormatStyle;

import java.util.ArrayList;
import java.util.Optional;

/**
 *
 * @author 180514-GrupoSalinas
 */
public class Cliente extends Persona implements ServicioACuentas{
    private int idCliente;
    private EstadoCliente estadoCliente;
    private ArrayList<Cuenta> cuentas;

    public Cliente(int idCliente, String nombre, Domicilio domicilio, LocalDate fechaNacimiento, String rfc) {
        super(nombre, domicilio, fechaNacimiento, rfc);
        this.estadoCliente=EstadoCliente.ACTIVO;
        this.idCliente = idCliente;
        this.cuentas = new ArrayList<>();
    }


    @Override
    public String toString() {
        return  "Cliente{" + "idCliente=" + idCliente + ", cuentas=" + cuentas +"     " +super.toString()+ '}';
        
//        return  "Cliente{" + "idCliente=" + idCliente + 
//                ", cuentas=" + cuentas.stream()
//                .filter(cta -> cta.getEstado()==Estado.ACTIVO)            
//                +"     " +super.toString()+ '}';
    }

    @Override
    public void cancelarCuenta(int numeroCuenta)throws CuentaInexistenteException {        
        try{
            Optional<Cuenta> cuenta = cuentas.stream()
                    .filter(cta -> (cta.getNumeroCuenta()==numeroCuenta))
                    .findFirst();
            if (cuenta.isPresent()) {
                Cuenta c= cuenta.get();
                c.setEstado(Estado.INACTIVO);
                c.setFechaCancelacion(LocalDate.now());
            }else{
                throw new CuentaInexistenteException("La cuenta No existe. IdCuenta: "+ numeroCuenta);
            }
            //cuentas.removeIf(cta -> (cta.getNumeroCuenta()==numeroCuenta));
            
        }catch(Exception ex){
            throw new CuentaInexistenteException("La cuenta No existe. IdCuenta: "+ numeroCuenta);
        }
    }

    @Override
    public Cuenta consultarCuenta(int numeroCuenta) throws CuentaInexistenteException {
        Cuenta c = null;
        try{
            Optional<Cuenta> cuenta = cuentas.stream()
                    .filter(cta -> cta.getEstado()== Estado.ACTIVO)
                    .filter(cta -> (cta.getNumeroCuenta()==numeroCuenta))                
                    .findFirst();
            if (cuenta.isPresent()) {
                c= cuenta.get();
                System.out.println("Detalles de Cuenta: \n" + c);
                c.consultaMovimientos();
            }else{
                throw new CuentaInexistenteException("La cuenta No existe. IdCuenta: "+ numeroCuenta);
            }
        }catch(Exception ex){
            throw new CuentaInexistenteException("La cuenta No existe. IdCuenta: "+ numeroCuenta);
        }
        
        return c;
    }

    @Override
    public ArrayList<Cuenta> consultarCuentasCliente() {
//        return cuentas.stream()
//                .filter(c -> c.getEstado()== Estado.ACTIVO)
        return cuentas;
    }

    @Override
    public void crearCuentaDeAhorros(double saldoinicial, double tasaDeInteresAnual) {
         int idCuenta=GeneraId.getNextIdCuentaAhorro();
        Cuenta cuentaAhorro=new CuentaDeAhorros(idCuenta,saldoinicial,tasaDeInteresAnual);        
        cuentas.add(cuentaAhorro);
        System.out.println("Cuenta de Ahorros Creada. Num. Cuenta: " + idCuenta);
        
    }

    @Override
    public void crearCuentaDeCheques(double saldoinicial, double comisionMensual) {
        int idCuenta=GeneraId.getNextIdCuentaCheques();
        Cuenta cuentaCheques=new CuentaDeCheques(idCuenta,saldoinicial,comisionMensual);
        cuentas.add(cuentaCheques);
        System.out.println("Cuenta De Cheques Creada. Num. Cuenta: " + idCuenta);
    }
    
    @Override
    public void estadoCuenta(int numeroCuenta) throws CuentaInexistenteException{    
        Cuenta c = consultarCuenta(numeroCuenta);
        DateTimeFormatter fmt=DateTimeFormatter.ofLocalizedDateTime(FormatStyle.MEDIUM);
        StringBuilder sb = new StringBuilder();
        System.out.println("\n\n\nEstado de cuenta:");
        sb.append("\n####################################################################################\n");        
        sb.append("                  ▂▃▄▅▆▇█▓▒░   ").append(Banco.getBanco().getNombre()).append("   ░▒▓█▇▆▅▄▃▂                  \n");
        sb.append("Fecha:").append(LocalDateTime.now().format(fmt)).append("\n");
        sb.append("Cliente No.").append(this.getIdCliente());
        sb.append("Nombre: ").append(this.getNombre()).append("\nRFC: ").append(this.getRfc());
        sb.append("\nDomicilio: \n").append(this.getDomicilio().getCalle()).append(this.getDomicilio().getNumero()).append(", ");
        sb.append(this.getDomicilio().getColonia()).append(" ");
        sb.append(this.getDomicilio().getEstado()).append(", CP: ").append(this.getDomicilio().getCodigoPostal());        
        sb.append("\n####################################################################################\n");
        sb.append("\n");
        sb.append("FECHA\t\t\t\t").append("MOVIMIENTO\t").append("CANTIDAD\t").append("SALDO DESPUES DEL MOVIMIENTO\n");
        sb.append("---------------------------------------------------------------------------------------------");
        System.out.println(sb);
        c.getMovimientos().stream()
                .forEach(m -> System.out.println(m.getFechaHora()+"\t\t"+m.getTipoMovimiento()+"\t\t "+m.getMonto()+"\t\t"+m.getSaldoNuevo()));        
        
        Cuenta cta =  cuentas.stream()
                .filter(m -> m.getNumeroCuenta()==numeroCuenta)
                .findFirst().get();
        System.out.println("\t\t\t\nSaldo Actual: "+ cta.getSaldo());
    }
    public int getIdCliente() {
        return idCliente;
    }

    public ArrayList<Cuenta> getCuentas() {
        return cuentas;
    }

    public void setCuentas(ArrayList<Cuenta> cuentas) {
        this.cuentas = cuentas;
    }
    
    public EstadoCliente getEstadoCliente() {
        return estadoCliente;
    }

    public void setEstadoCliente(EstadoCliente estadoCliente) {
        this.estadoCliente = estadoCliente;
    }

    

    
   
}
