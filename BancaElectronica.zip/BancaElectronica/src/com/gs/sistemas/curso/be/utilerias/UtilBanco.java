/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gs.sistemas.curso.be.utilerias;

import java.util.Scanner;

/**
 *
 * @author dell
 */
public class UtilBanco {
    public static void enviaMensaje(String mensaje){
        System.out.println(mensaje);
    }
    
    public static int SeleccionMenu() {
        int opcionEscogida = 0;
        Scanner opcionTeclado = new Scanner(System.in);
        StringBuilder sb = new StringBuilder();
        sb.append("\n\n\n1. Ejecutivo").append("\n").append("2. Cliente\n").append("3. Salir");
        sb.append("\n\nSeleccione una opcion: ");
        System.out.print(sb);
        opcionEscogida = opcionTeclado.nextInt();
        System.out.println("");
        return opcionEscogida;
    }
}
