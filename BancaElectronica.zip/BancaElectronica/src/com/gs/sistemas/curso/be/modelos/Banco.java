/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gs.sistemas.curso.be.modelos;

import com.gs.sistemas.curso.be.interfaces.ServicioAClientes;
import com.gs.sistemas.curso.be.interfaces.ServicioAEmpleados;
import com.gs.sistemas.curso.be.utilerias.EstadoCliente;
import com.gs.sistemas.curso.be.utilerias.GeneraId;
import java.time.LocalDate;
import java.time.Month;
import java.util.ArrayList;
import java.util.Optional;
import com.gs.sistemas.curso.be.excepciones.ClienteNoExisteException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Banco implements ServicioAClientes, ServicioAEmpleados {

    private String nombre;
    private Domicilio domicilio;
    private String rfc;
    private String telefono;
    private ArrayList<Cliente> clientes;
    private ArrayList<Ejecutivo> ejecutivos;

    private static final Banco banco = new Banco();

    private Banco() {
        this.nombre = "BANCO TOTOTE";
        this.domicilio = new Domicilio("Insurgentes Sur", "3579", "La Joya Tlalpan", "CDMX", 14000);
        this.rfc = "BCOTT180518BCTE";
        this.telefono = "55-54-43-69-09";
        this.clientes = new ArrayList<>();
        this.ejecutivos = new ArrayList<>();
    }

    public void bienvenida() {
        StringBuilder sb = new StringBuilder();
        sb.append("####################################################################################\n");
        sb.append("#                                  BIENVENIDOS  A                                  #\n");
        sb.append("#                 ▂▃▄▅▆▇█▓▒░   ").append(this.getNombre()).append("   ░▒▓█▇▆▅▄▃▂                 #\n");
        sb.append("####################################################################################\n");
        sb.append("\n\n\n");
       
        System.out.println(sb);

        //Crear Ejecutivos
        System.out.println("---------------EJECUTIVOS----------------------------");
        Domicilio d = new Domicilio("Calle Guerrero", "178", "El Rincon", "CDMX", 14678);
        Ejecutivo e = new Ejecutivo(GeneraId.getNextIdEjecutivo(), "ejecutivo1", "123", "Juan Camaney R",
                d, LocalDate.of(1978, Month.MARCH, 13), "CARJ780313");
        ejecutivos.add(e);
        consultarEmpleado(e);

        d = new Domicilio("Calle Morelos", "54", "El Rincon", "CDMX", 14678);
        e = new Ejecutivo(GeneraId.getNextIdEjecutivo(), "ejecutivo2", "456", "Bart Simpson",
                d, LocalDate.of(1985, Month.APRIL, 1), "BART850401");
        ejecutivos.add(e);
        consultarEmpleado(e);
    }

    public void despedida(){
        StringBuilder sb = new StringBuilder();
        sb.append("####################################################################################\n");        
        sb.append("#                 ▂▃▄▅▆▇█▓▒░   ").append(this.getNombre()).append("   ░▒▓█▇▆▅▄▃▂                 #\n");
        sb.append("#                     ======= AGRADECE SU PREFERENCIA ======                       #\n");
        sb.append("#                     =======      REGRESE PRONTO     ======                       #\n");
        sb.append("####################################################################################\n");
        sb.append("\n\n\n");
       
        System.out.println(sb);
    }
    
    
    public Optional<Ejecutivo> loginEjecutivo(String usuario, String psw) {
        Optional<Ejecutivo> ejecutivo = Optional.empty();
        ejecutivo = ejecutivos.stream()
                .filter(e -> e.getUsuario() == usuario)
                .filter(e -> e.getPsw() == psw)
                .findFirst();
        return ejecutivo;
    }

    @Override
    public String toString() {
        return "Banco{" + "nombre=" + getNombre() + ", domicilio=" + getDomicilio() + ", rfc=" + getRfc() + ", telefono=" + getTelefono() + '}';
    }

    @Override
    public void altaCliente(Cliente cliente) {
        clientes.add(cliente);
    }

    @Override
    public void bajaCliente(Cliente cliente) {
        Optional<Cliente> cte = clientes.stream()
                .filter(c -> (c.getIdCliente()==cliente.getIdCliente()))
                .filter(c -> (c.getEstadoCliente()==EstadoCliente.ACTIVO))
                .findFirst();
        if (cte.isPresent()) {
            Cliente c = cte.get();
            c.setEstadoCliente(EstadoCliente.INACTIVO);
        }else{
            System.out.println("");
            System.out.println("El cliente no existe o no es un cliente Activo");
            System.out.println("\n\n\n");
        }
    }

    @Override
    public void actualizaDatosCliente(Cliente cliente) {
        Optional<Cliente> cte = clientes.stream()
                .filter(c -> (c.getIdCliente()==cliente.getIdCliente()))
                .filter(c -> c.getEstadoCliente()== EstadoCliente.ACTIVO)
                .findFirst();
        if (cte.isPresent()) {
            Cliente c = cte.get();
            c.setDomicilio(cliente.getDomicilio());
            c.setCuentas(cliente.getCuentas());
            c.setEstadoCliente(cliente.getEstadoCliente());
            c.setFechaNacimiento(cliente.getFechaNacimiento());
            c.setNombre(cliente.getNombre());
            c.setRfc(cliente.getRfc());
        }

    }

    @Override
    public Cliente consultarCliente(int idCliente) throws ClienteNoExisteException{
        Cliente cliente = null;
        try{            
            Optional<Cliente> cte = clientes.stream()
                    .filter(c -> (c.getIdCliente()==idCliente))
                    .filter(c -> c.getEstadoCliente()== EstadoCliente.ACTIVO)
                    .findFirst();
            if (cte.isPresent()) {
                cliente = cte.get();
            }else{
                throw new ClienteNoExisteException("Cliente No existe idCliente: "+ idCliente); 
            }
        }catch(Exception ex){            
            throw new ClienteNoExisteException("Cliente No existe idCliente: "+ idCliente,ex.getCause());            
        }
        return cliente;
    }

    @Override
    public void imprimirClientes() {
        clientes.stream()
                .filter(c -> c.getEstadoCliente()==EstadoCliente.ACTIVO)
                .forEach(c -> System.out.println(c));
    }

    @Override
    public void consultarEmpleado(Ejecutivo ejecutivo) {
        Optional<Ejecutivo> ej = ejecutivos.stream()
                .filter(e -> (e.getIdEjecutivo() == ejecutivo.getIdEjecutivo()))
                .findFirst();
        if (ej.isPresent()) {
            Ejecutivo empleado = ej.get();
            System.out.println(empleado);
        }
    }

    /**
     * @return the nombre
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * @return the domicilio
     */
    public Domicilio getDomicilio() {
        return domicilio;
    }

    /**
     * @param domicilio the domicilio to set
     */
    public void setDomicilio(Domicilio domicilio) {
        this.domicilio = domicilio;
    }

    /**
     * @return the rfc
     */
    public String getRfc() {
        return rfc;
    }

    /**
     * @param rfc the rfc to set
     */
    public void setRfc(String rfc) {
        this.rfc = rfc;
    }

    /**
     * @return the telefono
     */
    public String getTelefono() {
        return telefono;
    }

    /**
     * @param telefono the telefono to set
     */
    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    /**
     * @return the clientes
     */
    public ArrayList<Cliente> getClientes() {
        return clientes;
    }

    /**
     * @param clientes the clientes to set
     */
    public void setClientes(ArrayList<Cliente> clientes) {
        this.clientes = clientes;
    }

    /**
     * @return the banco
     */
    public static Banco getBanco() {
        return banco;
    }

}
