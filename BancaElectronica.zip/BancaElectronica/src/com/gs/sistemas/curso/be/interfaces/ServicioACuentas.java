/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gs.sistemas.curso.be.interfaces;

import com.gs.sistemas.curso.be.modelos.Cuenta;
import java.util.ArrayList;
import com.gs.sistemas.curso.be.excepciones.CuentaInexistenteException;

/**
 *
 * @author dell
 */
public interface ServicioACuentas {
    public void cancelarCuenta(int numeroCuenta) throws CuentaInexistenteException;
    public Cuenta consultarCuenta(int numeroCuenta) throws CuentaInexistenteException;
    public ArrayList<Cuenta> consultarCuentasCliente();
    public void crearCuentaDeAhorros(double saldoinicial, double tasaDeInteresAnual);
    public void crearCuentaDeCheques(double saldoinicial, double comisionMensual);
    public void estadoCuenta(int numeroCuenta) throws CuentaInexistenteException;
}
