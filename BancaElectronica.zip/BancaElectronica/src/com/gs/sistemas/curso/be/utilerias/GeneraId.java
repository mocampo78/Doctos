/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gs.sistemas.curso.be.utilerias;


public class GeneraId {
    private static int idEjecutivo=0;
    private static int idCliente=1000;
    private static int idCuentaAhorro=11110000;
    private static int idCuentaCheques=22220000;

    public static int getNextIdCuentaAhorro() {
        return ++idCuentaAhorro;
    }

    public static int getNextIdCuentaCheques() {
        return ++idCuentaCheques;
    }

    public static int getNextIdEjecutivo() {
        return ++idEjecutivo;
    }

    public static int getNextIdCliente() {
        return ++idCliente;
    }

    
    
    
}
