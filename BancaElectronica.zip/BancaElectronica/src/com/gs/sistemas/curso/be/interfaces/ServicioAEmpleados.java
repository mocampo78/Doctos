/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gs.sistemas.curso.be.interfaces;

import com.gs.sistemas.curso.be.modelos.Ejecutivo;

/**
 *
 * @author dell
 */
public interface ServicioAEmpleados {
//    public void altaEmpleado(Ejecutivo ejecutivo);
//    public void bajaEmpleado(Ejecutivo ejecutivo);
//    public void actualizaDatosEmpleado(Ejecutivo ejecutivo);
    public void consultarEmpleado(Ejecutivo ejecutivo);
}
