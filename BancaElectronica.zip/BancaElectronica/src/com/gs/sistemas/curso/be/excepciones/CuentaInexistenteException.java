/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gs.sistemas.curso.be.excepciones;

/**
 *
 * @author dell
 */
public class CuentaInexistenteException extends Exception {

    public CuentaInexistenteException(String string) {
        super(string);
    }

    public CuentaInexistenteException(String string, Throwable thrwbl) {
        super(string, thrwbl);
    }
    
}
