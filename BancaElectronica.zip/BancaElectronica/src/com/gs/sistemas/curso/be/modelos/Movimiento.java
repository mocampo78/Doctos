/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gs.sistemas.curso.be.modelos;

import com.gs.sistemas.curso.be.utilerias.TipoMovimiento;

public class Movimiento {
    private String fechaHora;
    private TipoMovimiento tipoMovimiento;
    private double monto;
    private double saldoNuevo;

    public Movimiento(String fechaHora, TipoMovimiento tipoMovimiento, double monto, double saldoNuevo) {
        this.fechaHora = fechaHora;
        this.tipoMovimiento = tipoMovimiento;
        this.monto = monto;
        this.saldoNuevo = saldoNuevo;
    }

    
    @Override
    public String toString() {
        return "\t\tMovimiento:\t" + "fechaHora=" + getFechaHora() + "\ttipoMovimiento=" + getTipoMovimiento() + "\tmonto=" + getMonto() + "\tSaldoNuevo=" + getSaldoNuevo() + '}';
    }

    /**
     * @return the fechaHora
     */
    public String getFechaHora() {
        return fechaHora;
    }

    /**
     * @return the tipoMovimiento
     */
    public TipoMovimiento getTipoMovimiento() {
        return tipoMovimiento;
    }

    /**
     * @return the monto
     */
    public double getMonto() {
        return monto;
    }

    /**
     * @return the saldoNuevo
     */
    public double getSaldoNuevo() {
        return saldoNuevo;
    }

    
   
    
    
}
