/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gs.sistemas.curso.be.modelos;


import com.gs.sistemas.curso.be.excepciones.SaldoInsuficienteException;
import com.gs.sistemas.curso.be.utilerias.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.FormatStyle;

public class CuentaDeAhorros extends Cuenta {

    private double tasaInteresAnual;

    public CuentaDeAhorros(int numeroCuenta, double saldo, double tasaDeInteresAnual) {
        super(numeroCuenta, saldo, TipoCuenta.AHORRO);
        this.setTasaInteresAnual(tasaDeInteresAnual);
        
        DateTimeFormatter fmt=DateTimeFormatter.ofLocalizedDateTime(FormatStyle.MEDIUM);
        Movimiento m = new Movimiento(LocalDateTime.now().format(fmt), TipoMovimiento.INICIAL, saldo, this.getSaldo());
        this.getMovimientos().add(m);
    }
    
    
    public void calcularIntereses(){
        LocalDate fechaActual;
        fechaActual = LocalDate.now();
        //LocalDate tiempoTranscurrido=tiempoTranscurrido.minusYears(fechaActual.getYear());
        
    }
    
    @Override
    public void abono(double cantidad) {
        DateTimeFormatter fmt=DateTimeFormatter.ofLocalizedDateTime(FormatStyle.MEDIUM);
        if(cantidad <0){
            System.out.println("No se puede abonar una cantidad negativa");
            return;
        }
        this.setSaldo(this.getSaldo()+cantidad);
        Movimiento m = new Movimiento(LocalDateTime.now().format(fmt), TipoMovimiento.ABONO, cantidad, this.getSaldo());
        this.getMovimientos().add(m);
    }

    @Override
    public void retiro(double cantidad) throws SaldoInsuficienteException{
        DateTimeFormatter fmt=DateTimeFormatter.ofLocalizedDateTime(FormatStyle.MEDIUM);
        if(this.getSaldo()<cantidad){
            System.out.println("Fondos insuficientes para retirar. El retiro maximo es de: " + this.getSaldo());
            throw new SaldoInsuficienteException("Saldo Insuficiente Para Retirar");
        }
        this.setSaldo(this.getSaldo()-cantidad);
        Movimiento m = new Movimiento(LocalDateTime.now().format(fmt), TipoMovimiento.RETIRO, cantidad, this.getSaldo());        
        this.getMovimientos().add(m);
    }

    @Override
    public double consultaSaldo() {
        return this.getSaldo(); 
    }

    @Override
    public void imprimirDatos() {
        System.out.println("Datos de Cuenta de Ahorro: \n");
        this.toString();
    }
    
    @Override
    public void consultaMovimientos() {
        this.getMovimientos().stream()
                .forEach(m -> System.out.println(m.toString()));
    }

    @Override
    public String toString() {
        return "CuentaDeAhorros{" + super.toString() + " tasaInteresAnual=" + tasaInteresAnual + '}';
        
        //POner los demas atributos
    }

   

    /**
     * @return the tasaInteresAnual
     */
    public double getTasaInteresAnual() {
        return tasaInteresAnual;
    }

    /**
     * @param tasaInteresAnual the tasaInteresAnual to set
     */
    public void setTasaInteresAnual(double tasaInteresAnual) {
        this.tasaInteresAnual = tasaInteresAnual;
    }

    
   
    
    
    
}
