/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gs.sistemas.curso.be.modelos;


import com.gs.sistemas.curso.be.utilerias.*;
import java.time.LocalDate;

public class CuentaDeAhorros extends Cuenta {

    private double tasaInteresAnual;

    public CuentaDeAhorros(int numeroCuenta, double saldo, double tasaDeInteresAnual) {
        super(numeroCuenta, saldo, TipoCuenta.AHORRO);
        this.setTasaInteresAnual(tasaDeInteresAnual);
    }
    
    
    public void calcularIntereses(){
        LocalDate fechaActual;
        fechaActual = LocalDate.now();
        //LocalDate tiempoTranscurrido=tiempoTranscurrido.minusYears(fechaActual.getYear());
        
    }
    
    @Override
    public void abono(double cantidad) {
        if(cantidad <0){
            UtilBanco.enviaMensaje("No se puede abonar una cantidad negativa");
            return;
        }
        this.setSaldo(this.getSaldo()+cantidad);
    }

    @Override
    public void retiro(double cantidad) {
        if(this.getSaldo()<cantidad){
            UtilBanco.enviaMensaje("Fondos insuficientes para retirar. El retiro maximo es de: " + this.getSaldo());
            return;
        }
        this.setSaldo(this.getSaldo()-cantidad);
    }

    @Override
    public double consultaSaldo() {
        return this.getSaldo(); 
    }

    @Override
    public void imprimirDatos() {
        UtilBanco.enviaMensaje("Datos de Cuenta de Ahorro: \n");
        this.toString();
    }

    @Override
    public String toString() {
        return "CuentaDeAhorros{" + super.toString() + "tasaInteresAnual=" + tasaInteresAnual + '}';
        
        //POner los demas atributos
    }

   

    /**
     * @return the tasaInteresAnual
     */
    public double getTasaInteresAnual() {
        return tasaInteresAnual;
    }

    /**
     * @param tasaInteresAnual the tasaInteresAnual to set
     */
    public void setTasaInteresAnual(double tasaInteresAnual) {
        this.tasaInteresAnual = tasaInteresAnual;
    }
   
    
    
    
}
