/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gs.sistemas.curso.be.interfaces;

import com.gs.sistemas.curso.be.modelos.Cliente;

/**
 *
 * @author dell
 */
public interface ServicioAClientes {
    public void altaCliente(Cliente cliente);
    public void bajaCliente(Cliente cliente);
    public void actualizaDatosCliente(Cliente cliente);
    public Cliente consultarCliente(int idCliente);
    public void imprimirClientes();
}
