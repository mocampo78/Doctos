/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gs.sistemas.curso.be;

import com.gs.sistemas.curso.be.modelos.Banco;
import com.gs.sistemas.curso.be.modelos.Ejecutivo;
import com.gs.sistemas.curso.be.modelos.Cliente;
import com.gs.sistemas.curso.be.modelos.Cuenta;
import com.gs.sistemas.curso.be.modelos.Domicilio;
import com.gs.sistemas.curso.be.utilerias.GeneraId;
import com.gs.sistemas.curso.be.utilerias.UtilBanco;
import com.gs.sistemas.curso.be.utilerias.Estado;
import com.gs.sistemas.curso.be.excepciones.*;
import java.time.LocalDate;
import java.time.Month;
import java.util.List;
import java.util.Optional;

public class BeMain {

    public static void main(String[] args) {
        //Poner una leyenda por cada proceso (sobreescribir el motodo tostring)

        //BIENVENIDA
        //EL BANCO DEBE DAR LA BIENVENIDA (ENTIDAD)
        Banco banco = Banco.getBanco();
        banco.bienvenida();

        int opcionMenu = 0;
        while (opcionMenu != 3) {
            try{
                opcionMenu = UtilBanco.SeleccionMenu();
                switch (opcionMenu) {
                    case 1:
                        System.out.println("\n\nLogin de ejecutivo\n---------------------------------------------------------------------------------------------------");
                        Optional<Ejecutivo> e = banco.loginEjecutivo("ejecutivo1", "123");
                        if(!e.isPresent()){
                            opcionMenu=0;
                            System.out.println("El usuario no existe. Intente de nuevo \n\n\n");                        
                            break;
                        }
                        System.out.println("\n\n********* Acceso Concedido*********");
                        // EJECUTIVO
                        // Crear Cliente 1
                        System.out.println("\n\nCreando Cliente 1\n---------------------------------------------------------------------------------------------------");
                        Domicilio d = new Domicilio("Calle Florencia", "10", "Col Floresta, Xochimilco", "CDMX", 12345);
                        Cliente c = new Cliente(GeneraId.getNextIdCliente(),"Juan Lulo Cruz",
                                d,LocalDate.of(1978, Month.MARCH, 13), "LUCJ820627ET9");
                        banco.altaCliente(c);
                        banco.imprimirClientes();
                        System.out.println("");


                        // Crear Cliente 2
                        System.out.println("\n\nCreando Cliente 2\n---------------------------------------------------------------------------------------------------"); 
                        d = new Domicilio("Av. Siempre Viva", "401", "Springfield", "USA", 80765);
                        c = new Cliente(GeneraId.getNextIdCliente(),"Homero J. Simpson",
                                d,LocalDate.of(1968, Month.JANUARY, 27), "ABCD680127");
                        banco.altaCliente(c);
                        banco.imprimirClientes();
                        System.out.println("");

                        // Cambiar datos Cliente 2
                        System.out.println("\n\nActualizando Datos Cliente 2\n---------------------------------------------------------------------------------------------------"); 
                        d.setCalle("Del Hueso");
                        d.setColonia("Col. Arteaga");
                        d.setNumero("412");
                        d.setEstado("Edo. Mexico");
                        d.setCodigoPostal(45673);
                        c.setDomicilio(d);
                        banco.actualizaDatosCliente(c);
                        banco.imprimirClientes();


                        // Borrar Cliente 2
                        System.out.println("\n\nEliminando Cliente 2 (Logico)\n---------------------------------------------------------------------------------------------------");
                        banco.bajaCliente(c);
                        banco.imprimirClientes();

                        // Crear dos Cuentas (ahorro y cheques) para cliente 1
                        System.out.println("\n\nCreando cuenta de Ahorro y Cheques para Cliente 1\n---------------------------------------------------------------------------------------------------");
                        c =banco.consultarCliente(1001);
                        c.crearCuentaDeAhorros(133.50,4.4);
                        c.getCuentas().stream()
                                .forEach(ctaCli -> ctaCli.consultaMovimientos());
                        c.crearCuentaDeCheques(1350.00, 10);
                        c.getCuentas().stream()
                                .forEach(ctaCli -> ctaCli.consultaMovimientos());
                        List<Cuenta> cuentas=c.consultarCuentasCliente();
                        //cuentas.stream().forEach(cta -> System.out.println("Cuenta: " +cta.getNumeroCuenta()+"\n"); System.out.println(cta));
                        cuentas.stream().forEach(cta -> System.out.println("Detalles:  \t" + cta));
                        banco.actualizaDatosCliente(c);
                        banco.imprimirClientes();                        
                        
                        System.out.println("\n\nCancelando Cuenta de Cliente 1 \n---------------------------------------------------------------------------------------------------");
                        c.cancelarCuenta(22220001);
                        cuentas=c.consultarCuentasCliente();
                        cuentas.stream().forEach(cta -> System.out.println(cta));
                        banco.actualizaDatosCliente(c);
                        banco.imprimirClientes();



                        // Consultar cuentas
                        System.out.println("\n\nConsulta cuentas de cliente:\n---------------------------------------------------------------------------------------------------");
                        cuentas = c.consultarCuentasCliente();
                        cuentas.stream()
                                .forEach(cta -> System.out.println(cta));



                        // Detalle de cuenta
                        System.out.println("\n\nDetalle de cuenta de cliente:\n---------------------------------------------------------------------------------------------------");
                        Cuenta cta=c.consultarCuenta(11110001);
                        if(cta ==null){
                            System.out.println("Esa cuenta no existe");
                        }
                        
                        // *Borrar Cuenta (Excepciones)
                        System.out.println("Cuenta Borrada anteriormente:\n");
                        cta=c.consultarCuenta(22220001);
                        if(cta ==null){
                            System.out.println("Esa cuenta no existe\n");
                        }

                        System.out.println("\n\nCancelando Cuenta INEXISTENTE de Cliente 1 \n---------------------------------------------------------------------------------------------------");
                        c.cancelarCuenta(222345561);

                        break;

                    case 2:
                        //CLIENTE
                            //Consultar cuentas
                            c =  banco.consultarCliente(1001);
                            Cuenta cuenta;
                            System.out.println("\n\nConsulta cuentas de cliente:\n---------------------------------------------------------------------------------------------------");                            
    //                      c.getCuentas().stream()
    //                                .forEach(cuentaCli -> c.consultarCuenta(cuentaCli.getNumeroCuenta()));
                            for(Cuenta cuentaCli: c.getCuentas()){
                                if(cuentaCli.getEstado()==Estado.ACTIVO){
                                    c.consultarCuenta(cuentaCli.getNumeroCuenta());
                                }                                
                            }
                            
                            //Detalles de cuenta(estado de cuenta, movimientos)
                            System.out.println("\n\nDetalle de cuenta 11110001 de cliente:\n---------------------------------------------------------------------------------------------------");
                            c.estadoCuenta(11110001);


                            //Deposito       
                            System.out.println("\n\nDepositos de cliente:\n---------------------------------------------------------------------------------------------------");
                            cuenta=c.getCuentas().stream()
                                    .filter(cuentasC -> cuentasC.getNumeroCuenta()==11110001)
                                    .findFirst().get();
                            cuenta.abono(450);
                            cuenta.abono(1125);
                            cuenta.abono(150);
                            //Detalles de cuenta (estado de cuenta movimientos)
                            System.out.println("\n\nEstado de Cuenta con depositos:\n-------------------------------------------------------------------------------------------");
                            c.estadoCuenta(11110001);

                            //retiro
                            System.out.println("\n\n\nRetiros de cliente:\n---------------------------------------------------------------------------------------------------");
                            cuenta.retiro(100);
                            cuenta.retiro(245);
                            cuenta.retiro(25);
                            //Detalles de cuenta (estado de cuenta movimientos)
                            System.out.println("\n\nEstado de Cuenta con retiros:\n-------------------------------------------------------------------------------------------");
                            c.estadoCuenta(11110001);
                            
                            //PROVOCANDO UNA EXCEPCION
                            System.out.println("\n\nPROVOCANCO UNA EXCEPCION\n------------------------------------------------------------------------------------------------");
                            cuenta.retiro(25000);
                            break;
                    case 3:
                        banco.despedida();
                        break;
                    default:
                        throw new Exception("La opcion es invalida. Por favor elija una opcion valida");
                }
            }catch(ClienteNoExisteException ex){
                System.out.println(ex.getMessage());
                System.out.println("Por Favor acuda con un ejecutivo para el Alta");
            }catch(CuentaInexistenteException ex){
                System.out.println(ex.getMessage());
                System.out.println("Por favor Acuda con un ejecutivo");
            }catch(SaldoInsuficienteException ex){
                System.out.println(ex.getMessage());
            }catch(Exception ex){                
                System.out.println("Ocurrion un error inesperado. ");
                System.out.println(ex.getMessage()+ ",  "+ ex.getCause());
            }
            

        }
    }

    //LOGIN
    //EJECUTIVO
    //crear cliente
    //Crear cliente 2
    //Cambiar datos cliente 2
    //borrar Cliente 2 (fisicamente del arreglo)
    //Crear 2 cuentas (ahorro y cheques)
    //*Borrar cuenta (Borrar logicamente)
    //Consultar cuentas
    //Detalles de Cuenta    ---cuenta, cuando se creo, movimientos, etc
    //CLIENTE
    //Consultar cuentas
    //Detalles de cuenta(estado de cuenta, movimientos)
    //Deposito
    //Detalles de cuenta (estado de cuenta movimientos)
    //retiro
    //Detalles de cuenta (estado de cuenta movimientos)
    //Despedida
}
//}
