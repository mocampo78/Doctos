/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gs.sistemas.curso.be.excepciones;

/**
 *
 * @author dell
 */
public class SaldoInsuficienteException extends Exception {

    public SaldoInsuficienteException(String string) {
        super(string);
    }

    public SaldoInsuficienteException(String string, Throwable thrwbl) {
        super(string, thrwbl);
    }
    
}
