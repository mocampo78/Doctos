/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gs.sistemas.curso.be.modelos;

import com.gs.sistemas.curso.be.utilerias.*;

public class CuentaDeCheques extends Cuenta{

    private double costoManejoMensual;
    
    public CuentaDeCheques(int numero, double saldo, double costoManejoMensual) {
        super(numero, saldo, TipoCuenta.CHEQUES);
        this.SetCostoManejoMensual(costoManejoMensual);
    }
    
    public double costoManejoMensual(){
        return this.getCostoManejoMensual();
    }

    @Override
    public String toString() {
        return "CuentaDeCheques{" + super.toString()+ " costoManejoMensual=" + getCostoManejoMensual() + '}';
    }

    
    @Override
    public void abono(double cantidad) {
        if(cantidad <0){
            UtilBanco.enviaMensaje("No se puede abonar una cantidad negativa");
            return;
        }
        this.setSaldo(this.getSaldo()+cantidad);
        
    }

    @Override
    public void retiro(double cantidad) {
        if(this.getSaldo()<cantidad){
            UtilBanco.enviaMensaje("Fondos insuficientes para retirar. El retiro maximo es de: " + this.getSaldo());
            return;
        }
        this.setSaldo(this.getSaldo()-cantidad);
    }

    @Override
    public double consultaSaldo() {
        return this.getSaldo();
    }

    @Override
    public void imprimirDatos() {
        UtilBanco.enviaMensaje("Datos de Cuenta de Cheques: \n");
        this.toString();
    }

    /**
     * @return the costoManejoMensual
     */
    public double getCostoManejoMensual() {
        return costoManejoMensual;
    }

    /**
     * @param costoManejoMensual the costoManejoMensual to set
     */
    public void SetCostoManejoMensual(double costoManejoMensual) {
        this.costoManejoMensual = costoManejoMensual;
    }

    
}
