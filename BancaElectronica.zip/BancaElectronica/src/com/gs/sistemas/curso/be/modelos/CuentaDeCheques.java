/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gs.sistemas.curso.be.modelos;

import com.gs.sistemas.curso.be.utilerias.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.FormatStyle;

public class CuentaDeCheques extends Cuenta{

    private double costoManejoMensual;
    
    public CuentaDeCheques(int numero, double saldo, double costoManejoMensual) {
        super(numero, saldo, TipoCuenta.CHEQUES);
        this.SetCostoManejoMensual(costoManejoMensual);
        
        DateTimeFormatter fmt=DateTimeFormatter.ofLocalizedDateTime(FormatStyle.MEDIUM);
        Movimiento m = new Movimiento(LocalDateTime.now().format(fmt), TipoMovimiento.INICIAL, saldo, this.getSaldo());
        this.getMovimientos().add(m);
    }
    
    public double costoManejoMensual(){
        return this.getCostoManejoMensual();
    }

    @Override
    public String toString() {
        return "CuentaDeCheques{" + super.toString()+ " costoManejoMensual=" + getCostoManejoMensual() + '}';
    }

    
    @Override
    public void abono(double cantidad) {
        if(cantidad <0){
            System.out.println("No se puede abonar una cantidad negativa");
            return;
        }
        this.setSaldo(this.getSaldo()+cantidad);
        Movimiento m = new Movimiento(LocalDateTime.now().toString(), TipoMovimiento.ABONO, cantidad, this.getSaldo());
        this.getMovimientos().add(m);
    }

    @Override
    public void retiro(double cantidad) {
        if(this.getSaldo()<cantidad){
            System.out.println("Fondos insuficientes para retirar. El retiro maximo es de: " + this.getSaldo());
            return;
        }
        this.setSaldo(this.getSaldo()-cantidad);
        Movimiento m = new Movimiento(LocalDateTime.now().toString(), TipoMovimiento.RETIRO, cantidad, this.getSaldo());        
        this.getMovimientos().add(m);
    }

    @Override
    public double consultaSaldo() {
        return this.getSaldo();
    }

    @Override
    public void imprimirDatos() {
        System.out.println("Datos de Cuenta de Cheques: \n");
        this.toString();
    }
    
    @Override
    public void consultaMovimientos() {
        this.getMovimientos().stream()
                .forEach(m -> System.out.println(m.toString()));
    }

    /**
     * @return the costoManejoMensual
     */
    public double getCostoManejoMensual() {
        return costoManejoMensual;
    }

    /**
     * @param costoManejoMensual the costoManejoMensual to set
     */
    public void SetCostoManejoMensual(double costoManejoMensual) {
        this.costoManejoMensual = costoManejoMensual;
    }

    
}
