/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gs.sistemas.curso.be.modelos;


import java.time.LocalDate;

import java.util.ArrayList;

/**
 *
 * @author 180514-GrupoSalinas
 */
public class Ejecutivo extends Persona{
    private int idEjecutivo;
    private String usuario;
    private String psw;

    public Ejecutivo(int idEjecutivo, String usuario, String psw, String nombre, Domicilio domicilio, LocalDate fechaNacimiento, String rfc) {
        super(nombre, domicilio, fechaNacimiento, rfc);
        this.idEjecutivo = idEjecutivo;
        this.usuario = usuario;
        this.psw = psw;
    }

    @Override
    public String toString() {
        return super.toString() + "  Ejecutivo{" + "idEjecutivo=" + idEjecutivo + '}';
    }

    
    public int getIdEjecutivo() {
        return idEjecutivo;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public String getPsw() {
        return psw;
    }

    public void setPsw(String psw) {
        this.psw = psw;
    }
    
    
    
    
    
}
