/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gs.sistemas.curso.be;


import com.gs.sistemas.curso.be.modelos.Banco;
import com.gs.sistemas.curso.be.modelos.Ejecutivo;
import com.gs.sistemas.curso.be.modelos.Cliente;
import com.gs.sistemas.curso.be.modelos.Cuenta;
import com.gs.sistemas.curso.be.modelos.Domicilio;
import com.gs.sistemas.curso.be.utilerias.GeneraId;
import com.gs.sistemas.curso.be.utilerias.UtilBanco;
import java.time.LocalDate;
import java.time.Month;
import java.util.List;
import java.util.Optional;


public class Main {

    public static void main(String[] args) {
                //Poner una leyenda por cada proceso (sobreescribir el motodo tostring)
        
        //BIENVENIDA
            //EL BANCO DEBE DAR LA BIENVENIDA (ENTIDAD)
         Banco banco = Banco.getBanco();
         banco.bienvenida();
          
        int opcionMenu=0;
        while(opcionMenu!=3){
            opcionMenu = UtilBanco.SeleccionMenu();
            switch (opcionMenu) {
                case 1:
                    System.out.println("\n\n-----------------Login de ejecutivo------------------------");
                    Optional<Ejecutivo> e = banco.loginEjecutivo("ejecutivo1", "123");
                    if(!e.isPresent()){
                        opcionMenu=0;
                        System.out.println("El usuario no existe. Intente de nuevo \n\n\n");                        
                        break;
                    }
                    System.out.println("\n\n********* Acceso Concedido*********");
                    // EJECUTIVO
                    // Crear Cliente 1
                    System.out.println("\n\n------------------Creando Cliente 1------------------"); 
                    Domicilio d = new Domicilio("Calle Florencia", "10", "Col Floresta, Xochimilco", "CDMX", 12345);
                    Cliente c = new Cliente(GeneraId.getNextIdCliente(),"Juan Lulo Cruz",
                            d,LocalDate.of(1978, Month.MARCH, 13), "LUCJ820627ET9");
                    banco.altaCliente(c);
                    banco.imprimirClientes();
                    System.out.println("");

                    
                    // Crear Cliente 2
                    System.out.println("\n\n------------------Creando Cliente 2------------------"); 
                    d = new Domicilio("Av. Siempre Viva", "401", "Springfield", "USA", 80765);
                    c = new Cliente(GeneraId.getNextIdCliente(),"Homero J. Simpson",
                            d,LocalDate.of(1968, Month.JANUARY, 27), "ABCD680127");
                    banco.altaCliente(c);
                    banco.imprimirClientes();
                    System.out.println("");
                    
                    // Cambiar datos Cliente 2
                    System.out.println("\n\n------------------Actualizando Datos Cliente 2------------------"); 
                    d.setCalle("Del Hueso");
                    d.setColonia("Col. Arteaga");
                    d.setNumero("412");
                    d.setEstado("Edo. Mexico");
                    d.setCodigoPostal(45673);
                    c.setDomicilio(d);
                    banco.actualizaDatosCliente(c);
                    banco.imprimirClientes();
                    
                    
                    // Borrar Cliente 2
                    System.out.println("\n\n------------------Eliminando Cliente 2 (Logico)------------------"); 
                    banco.bajaCliente(c);
                    banco.imprimirClientes();
                    
                    // Crear dos Cuentas (ahorro y cheques) para cliente 1
                    System.out.println("\n\n------------Creando cuenta de Ahorro y Cheques para Cliente 1---------------");
                    c =banco.consultarCliente(1001);
                    c.crearCuentaDeAhorros(133.50,4.4);
                    c.crearCuentaDeCheques(1350.00, 10);
                    List<Cuenta> cuentas=c.consultarCuentasCliente();
                    cuentas.stream().forEach(cta -> System.out.println(cta));
                    banco.actualizaDatosCliente(c);
                    banco.imprimirClientes();
                    
                    
                    // *Borrar Cuenta
                    System.out.println("\n\n------------Cancelando Cuenta de Cliente1---------------");
                    c.cancelarCuenta(11110001);
                    cuentas=c.consultarCuentasCliente();
                    cuentas.stream().forEach(cta -> System.out.println(cta));
                    banco.actualizaDatosCliente(c);
                    banco.imprimirClientes();
                    
                    

                    // Consultar cuentas
                    System.out.println("\n\n------------ Consulta cuentas de cliente--------------------");
                    cuentas = c.consultarCuentasCliente();
                    cuentas.stream()
                            .forEach(cta -> System.out.println(cta));
                   
                    
                    // Detalle de cuenta
                    System.out.println("\n\n------------- Detalle de cuenta de cliente -------------------");
                    Cuenta cta=c.consultarCuenta(22220001);
                    if(cta ==null){
                        System.out.println("Esa cuenta no existe");
                    }
                    
                    cta=c.consultarCuenta(11110001);
                    if(cta ==null){
                        System.out.println("Esa cuenta no existe");
                    }
                   
                    break;
                case 2:
                    break;
                case 3:
                    //Salir
                    break;
                default:
                    System.out.println("La Opcion es invalida por favor intente de Nuevo");
                    
            }    
        }
        
        //LOGIN
            //EJECUTIVO
            //crear cliente
            //Crear cliente 2
            //Cambiar datos cliente 2
            //borrar Cliente 2 (fisicamente del arreglo)
            //Crear 2 cuentas (ahorro y cheques)
            //*Borrar cuenta (Borrar logicamente)
            //Consultar cuentas
            //Detalles de Cuenta    ---cuenta, cuando se creo, movimientos, etc
            
        //CLIENTE
            //Consultar cuentas
            //Detalles de cuenta(estado de cuenta, movimientos)
            //Deposito
            //Detalles de cuenta (estado de cuenta movimientos)
            //retiro
            //Detalles de cuenta (estado de cuenta movimientos)
        //Despedida
    }
    
}
