/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gs.sistemas.curso.be.utilerias;

/**
 *
 * @author dell
 */
public enum TipoMovimiento {
    INICIAL("Saldo Inicial"),
    ABONO("Abono"),
    RETIRO("Retiro");

    
    
   private String tipoMov;


    private TipoMovimiento(String tipoMov) {
        this.tipoMov = tipoMov;
    }

    public String getTipoMov() {
        return tipoMov;
    }  
}
