package com.gs.ccpp.rest.to;

import org.springframework.http.HttpStatus;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * Transfer Object to communicate errors.
 * 
 * @author Emmanuel Salazar
 */
@ApiModel(value = "Application Error")
public class AppErrorTO {

    protected HttpStatus status;
    protected String errorCode;
    protected String errorDescription;

    /**
     * Empty constructor.
     */
    public AppErrorTO() {}

    /**
     * The class constructor with parameters.
     * 
     * @param status The HTTP status 
     * @param errorCode The error code
     * @param errorDescription The error description
     */
    public AppErrorTO(HttpStatus status, String errorCode, String errorDescription) {
        this.status = status;
        this.errorCode = errorCode;
        this.errorDescription = errorDescription;
    }

    /**
     * Get the HTTP status.
     * 
     * @return the HTTP status
     */
    @ApiModelProperty(value = "The http response code.", example = "BAD_HTTP_STATUS", dataType = "String")
    public HttpStatus getStatus() {
        return status;
    }

    /**
     * Set the HTTP status.
     * 
     * @param status the HTTP status to be used
     */
    public void setStatus(HttpStatus status) {
        this.status = status;
    }

    /**
     * Retrieve the error code.
     * 
     * @return the error code
     */
    @ApiModelProperty(value = "Application error code.", example = "Error code", dataType = "String")
    public String getErrorCode() {
        return errorCode;
    }

    /**
     * Set the error code.
     *
     * @param errorCode the error code.
     */
    public void setErrorCode(String errorCode) {
        this.errorCode = errorCode;
    }

    /**
     * Retrieves the error description.
     * 
     * @return the error description
     */
    @ApiModelProperty(value = "Detailed description of the error.", example = "This is a description of the error code", dataType = "String")
    public String getErrorDescription() {
        return errorDescription;
    }

    /**
     * Set the error description.
     * 
     * @param errorDescription the error description
     */
    public void setErrorDescription(String errorDescription) {
        this.errorDescription = errorDescription;
    }
}
