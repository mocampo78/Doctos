package com.gs.ccpp.coppay.client.util;

/**
 * Enum with the crypto currencies available in CopPay.
 * 
 * @author Emmanuel Salazar
 */
public enum CryptoCurrencyEnum {
    bitcoin("bitcoin"), ethereum("ethereum"), steem("steem"), steem_dollars("steem-dollars"), dash("dash"), nem("nem");

    private String value;

    /**
     * Instantiate the enum with a valid value for CopPay's cryptocurrency catalog.
     * 
     * @param value the cryptocurrency item to be used
     */
    CryptoCurrencyEnum(String value) {
        this.value = value;
    }

    /**
     * The value defined by CopPay for the cryptocurrency catalog.
     * 
     * @return the catalog value to be used in the call
     */
    public String getValue() {
        return value;
    }
}
