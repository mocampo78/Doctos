package com.gs.ccpp.coppay.client.order;

import java.io.IOException;

import org.slf4j.LoggerFactory;

import com.gs.ccpp.coppay.client.CopPayClient;
import com.gs.ccpp.coppay.client.to.ClientErrorResponse;
import com.gs.ccpp.coppay.client.to.order.CheckOrderClientRequest;
import com.gs.ccpp.coppay.client.to.order.CheckOrderClientResponse;
import com.gs.ccpp.coppay.client.util.CopPayOperUtil;
import com.gs.ccpp.rest.vo.RequestDataVO;

/**
 * Client for CopPay's web service to check an order.
 * 
 * @author Emmanuel Salazar
 */
public class CheckOrderClient extends CopPayClient {
    public static final Short CHECK_OPER = 2;

    private CheckOrderClientResponse response;

    /**
     * The constructor for the check order client.
     * 
     * @param requestDataVO the information of the caller for the request
     */
    public CheckOrderClient(RequestDataVO requestDataVO) {
        super(requestDataVO);

        log = LoggerFactory.getLogger(AddOrderClient.class);
        url = CopPayOperUtil.getInstance().getCopPayMap().get(CHECK_OPER).getEndpoint();
    }

    /**
     * Execute the check order web service from CopPay.
     * 
     * @param orderId the order id to be retrieved
     * @return the information about the requested order
     */
    public CheckOrderClientResponse checkOrder(String orderId) {
        log.info("Request received to check order: {}", orderId);
        CheckOrderClientRequest request = new CheckOrderClientRequest(requestDataVO.getApiKey(), orderId);
        responseEntity = execute(CHECK_OPER, request);

        try {
            response = mapper.readValue(responseEntity.getBody(), CheckOrderClientResponse.class);
            response.setOrderId(orderId);
        } catch (IOException e) {
            log.error("Error parsing the response from CopPay", e);
            elapsedTime = System.currentTimeMillis() - startTime;

            ClientErrorResponse error = new ClientErrorResponse(e.getMessage());
            saveClientLog(error, false);

            throw new RuntimeException(e);
        }

        saveClientLog(response, true);
        log.info("Check order request processed with response: {}", response.toString());
        return response;
    }
}
