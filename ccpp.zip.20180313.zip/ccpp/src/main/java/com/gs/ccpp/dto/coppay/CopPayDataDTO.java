package com.gs.ccpp.dto.coppay;

import javax.persistence.Column;
import javax.persistence.Entity;

/**
 * DTO to be used to retrieve CopPay's information from database.
 * 
 * @author Emmanuel Salazar
 */
@Entity
public class CopPayDataDTO {
    @Column(name = "FI_PROVIDER_OPERATION_ID")
    private short operationId;
    @Column(name = "FC_PROVIDER_OPERATION")
    private String operation;
    @Column(name = "FI_CLIENT_TIMEOUT")
    private int timeout;
    @Column(name = "FC_PROVIDER_ENDPOINT")
    private String endpoint;

    @Override
    public String toString() {
        return "CopPayDataDTO [operationId=" + operationId + ", operation=" + operation + ", timeout=" + timeout + ", endpoint=" + endpoint + "]";
    }

    public short getOperationId() {
        return operationId;
    }

    public void setOperationId(short operationId) {
        this.operationId = operationId;
    }

    public String getOperation() {
        return operation;
    }

    public void setOperation(String operation) {
        this.operation = operation;
    }

    public int getTimeout() {
        return timeout;
    }

    public void setTimeout(int timeout) {
        this.timeout = timeout;
    }

    public String getEndpoint() {
        return endpoint;
    }

    public void setEndpoint(String endpoint) {
        this.endpoint = endpoint;
    }
}
