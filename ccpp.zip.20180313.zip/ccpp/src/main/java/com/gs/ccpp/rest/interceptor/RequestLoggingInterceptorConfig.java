package com.gs.ccpp.rest.interceptor;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

/**
 * Configuration of the logging interceptor.
 * 
 * @author Emmanuel Salazar
 */
@Configuration
public class RequestLoggingInterceptorConfig extends WebMvcConfigurerAdapter {
    @Autowired
    private RequestLoggingInterceptor requestLoggingInterceptor;

    /**
     * It defines the mapping for the loggin interceptor.
     */
    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        registry.addInterceptor(requestLoggingInterceptor).addPathPatterns("/**/ccpp/**/");
    }

}
