package com.gs.ccpp.core.bll;

import javax.servlet.http.HttpServletRequest;

import com.gs.ccpp.coppay.client.order.AddOrderClient;
import com.gs.ccpp.coppay.client.order.CheckOrderClient;
import com.gs.ccpp.coppay.client.order.DeleteOrderClient;
import com.gs.ccpp.coppay.client.order.RefreshOrderClient;
import com.gs.ccpp.coppay.client.to.order.AddOrderClientRequest;
import com.gs.ccpp.coppay.client.to.order.AddOrderClientResponse;
import com.gs.ccpp.coppay.client.to.order.CheckOrderClientResponse;
import com.gs.ccpp.coppay.client.to.order.DeleteOrderClientResponse;
import com.gs.ccpp.coppay.client.to.order.RefreshOrderClientResponse;
import com.gs.ccpp.coppay.client.util.CryptoCurrencyEnum;
import com.gs.ccpp.coppay.client.util.FiatCurrencyEnum;
import com.gs.ccpp.dao.order.OrderDAO;
import com.gs.ccpp.dto.order.OrderDTO;
import com.gs.ccpp.rest.to.order.AddOrderRequest;
import com.gs.ccpp.rest.to.order.AddOrderResponse;
import com.gs.ccpp.rest.to.order.CheckOrderResponse;
import com.gs.ccpp.rest.to.order.DeleteOrderResponse;
import com.gs.ccpp.rest.to.order.RefreshOrderResponse;

/**
 * Managmenet class for the Order controller. This class will handle the Add-Check-Delete-Refresh methods for the orders.
 * 
 * @author Emmanuel Salazar
 */
public class OrderManagement extends CoreManagement {
    public OrderManagement(HttpServletRequest httpRequest) {
        super(httpRequest);
    }

    /**
     * Create an order with the provider.
     * 
     * @param request information required to create an order
     * @return the created order information
     */
    public AddOrderResponse addOrder(AddOrderRequest request) {
        AddOrderClientRequest clientRequest = new AddOrderClientRequest(requestDataVO.getApiKey());

        clientRequest.setBaseCurrencyName(FiatCurrencyEnum.valueOf(request.getFiatCurrency()).getValue());
        clientRequest.setCryptoCurrencyName(CryptoCurrencyEnum.valueOf(request.getCryptoCurrency()).getValue());
        clientRequest.setDescription(request.getDescription());
        clientRequest.setBaseCurrencyPrice(request.getAmount().toString());

        AddOrderClientResponse clientResponse = new AddOrderClient(requestDataVO).addOrder(clientRequest);

        AddOrderResponse response = new AddOrderResponse();
        response.setAddress(clientResponse.getAddress());
        response.setCryptoPrice(clientResponse.getCryptoPrice());
        response.setOrderId(clientResponse.getOrderId());
        response.setQrText(clientResponse.getQrText());
        response.setTimeout(clientResponse.getTimeout());

        OrderDTO orderDTO = new OrderDTO();
        orderDTO.setAddress(response.getAddress());
        orderDTO.setCenterOperation(requestDataVO.getCenterId());
        orderDTO.setCryptoCode(request.getCryptoCurrency().equals("ethreum") ? "ETH" : "BTC");
        orderDTO.setCryptoPrice(response.getCryptoPrice());
        orderDTO.setDescription(request.getDescription());
        orderDTO.setFiatCode(request.getFiatCurrency());
        orderDTO.setFiatPrice(request.getAmount());
        orderDTO.setIpAddress(requestDataVO.getIpAddress());
        orderDTO.setOrderId(response.getOrderId());
        orderDTO.setQrText(response.getQrText());
        orderDTO.setTimeout(response.getTimeout());
        orderDTO.setTransactionId(requestDataVO.getTransactionId());
        orderDTO.setUser(requestDataVO.getUserId());

        OrderDAO orderDAO = new OrderDAO();
        orderDAO.addOrder(orderDTO);

        return response;
    }

    /**
     * Retrieve the information of an existing order.
     * 
     * @param orderId the id of the order to be retrieved
     * @return the order's information
     */
    public CheckOrderResponse checkOrder(String orderId) {
        CheckOrderClientResponse clientResponse = new CheckOrderClient(requestDataVO).checkOrder(orderId);

        CheckOrderResponse response = new CheckOrderResponse();
        response.setOrderId(clientResponse.getOrderId());
        response.setIsConfirmed(clientResponse.getIsConfirmed());
        response.setIsClosed(clientResponse.getIsClosed());
        response.setIsSuspended(clientResponse.getIsSuspended());
        response.setTimeout(clientResponse.getTimeout());

        if (response.getIsSuspended()) {
            OrderDAO orderDAO = new OrderDAO();
            OrderDTO currentOrderDTO = orderDAO.getOrder(orderId);

            OrderDTO orderDTO = new OrderDTO();
            orderDTO.setCenterOperation(requestDataVO.getCenterId());
            orderDTO.setCryptoPrice(currentOrderDTO.getCryptoPrice());
            orderDTO.setIpAddress(requestDataVO.getIpAddress());
            orderDTO.setOrderId(response.getOrderId());
            orderDTO.setQrText(currentOrderDTO.getQrText());
            orderDTO.setOrderStatusId(OrderDAO.ST_SUSPENDED);
            orderDTO.setOperationId(OrderDAO.OPER_CHECK);
            orderDTO.setTimeout(response.getTimeout());
            orderDTO.setTransactionId(requestDataVO.getTransactionId());
            orderDTO.setUser(requestDataVO.getUserId());

            orderDAO.updateOrder(orderDTO);
        }

        if (response.getIsConfirmed()) {
            OrderDAO orderDAO = new OrderDAO();
            OrderDTO currentOrderDTO = orderDAO.getOrder(orderId);

            OrderDTO orderDTO = new OrderDTO();
            orderDTO.setCenterOperation(requestDataVO.getCenterId());
            orderDTO.setCryptoPrice(currentOrderDTO.getCryptoPrice());
            orderDTO.setIpAddress(requestDataVO.getIpAddress());
            orderDTO.setOrderId(response.getOrderId());
            orderDTO.setQrText(currentOrderDTO.getQrText());
            orderDTO.setOrderStatusId(OrderDAO.ST_CONFIRMED);
            orderDTO.setOperationId(OrderDAO.OPER_CHECK);
            orderDTO.setTimeout(response.getTimeout());
            orderDTO.setTransactionId(requestDataVO.getTransactionId());
            orderDTO.setUser(requestDataVO.getUserId());

            orderDAO.updateOrder(orderDTO);
        }
        return response;
    }

    /**
     * Delete/close an order with the provider.
     * 
     * @param orderId the id of the order to be deleted/closed
     * @return information about the delete process
     */
    public DeleteOrderResponse deleteOrder(String orderId) {
        DeleteOrderClientResponse clientResponse = new DeleteOrderClient(requestDataVO).deleteOrder(orderId);

        DeleteOrderResponse response = new DeleteOrderResponse();
        response.setOrderId(clientResponse.getOrderId());
        response.setIsDeleteSuccessful(clientResponse.getIsDeleteSuccessful());
        response.setMessage(clientResponse.getMessage());

        OrderDAO orderDAO = new OrderDAO();
        OrderDTO currentOrderDTO = orderDAO.getOrder(orderId);

        OrderDTO orderDTO = new OrderDTO();
        orderDTO.setCenterOperation(requestDataVO.getCenterId());
        orderDTO.setCryptoPrice(currentOrderDTO.getCryptoPrice());
        orderDTO.setIpAddress(requestDataVO.getIpAddress());
        orderDTO.setOrderId(response.getOrderId());
        orderDTO.setQrText(currentOrderDTO.getQrText());
        orderDTO.setOrderStatusId(OrderDAO.ST_CLOSED);
        orderDTO.setOperationId(OrderDAO.OPER_DELETE);
        orderDTO.setTimeout(0);
        orderDTO.setTransactionId(requestDataVO.getTransactionId());
        orderDTO.setUser(requestDataVO.getUserId());

        orderDAO.updateOrder(orderDTO);

        return response;
    }

    /**
     * Refresh the order price with the provider.
     * 
     * @param orderId the id of the order to be refreshed
     * @return the updated order's information
     */
    public RefreshOrderResponse refreshOrder(String orderId) {
        RefreshOrderClientResponse clientResponse = new RefreshOrderClient(requestDataVO).refreshOrder(orderId);

        RefreshOrderResponse response = new RefreshOrderResponse();
        response.setOrderId(clientResponse.getOrderId());
        response.setCryptoPrice(clientResponse.getCryptoPrice());
        response.setQrText(clientResponse.getQrText());
        response.setTimeout(clientResponse.getTimeout());

        OrderDTO orderDTO = new OrderDTO();
        orderDTO.setCenterOperation(requestDataVO.getCenterId());
        orderDTO.setCryptoPrice(response.getCryptoPrice());
        orderDTO.setIpAddress(requestDataVO.getIpAddress());
        orderDTO.setOrderId(response.getOrderId());
        orderDTO.setQrText(response.getQrText());
        orderDTO.setOrderStatusId(OrderDAO.ST_PENDING);
        orderDTO.setOperationId(OrderDAO.OPER_REFRESH);
        orderDTO.setTimeout(response.getTimeout());
        orderDTO.setTransactionId(requestDataVO.getTransactionId());
        orderDTO.setUser(requestDataVO.getUserId());

        OrderDAO orderDAO = new OrderDAO();
        orderDAO.updateOrder(orderDTO);

        return response;
    }
}
