package com.gs.ccpp.dto.order;

import javax.persistence.Column;
import javax.persistence.Entity;

import com.gs.ccpp.dto.CoreDTO;

/**
 * DTO to be used to retrieve Order's information from database.
 * 
 * @author Emmanuel Salazar
 */
@Entity
public class OrderDTO extends CoreDTO {
    @Column(name = "FC_ORDER_ID")
    private String orderId;
    @Column(name = "FC_FIAT_CODE")
    private String fiatCode;
    @Column(name = "FN_FIAT_PRICE")
    private Double fiatPrice;
    @Column(name = "FC_CRYPTO_CODE")
    private String cryptoCode;
    @Column(name = "FN_CRYPTO_PRICE")
    private String cryptoPrice;
    @Column(name = "FC_QR_TEXT")
    private String qrText;
    @Column(name = "FC_ADDRESS")
    private String address;
    @Column(name = "FC_ORDER_DESCRIPTION")
    private String description;
    @Column(name = "FI_ORDER_STATUS_ID")
    private Short orderStatusId;
    @Column(name = "FI_PROVIDER_OPERATION_ID")
    private Short operationId;
    @Column(name = "FI_TIMEOUT")
    private Integer timeout;

    @Override
    public String toString() {
        return "OrderDTO [orderId=" + orderId + ", fiatCode=" + fiatCode + ", fiatPrice=" + fiatPrice + ", cryptoCode=" + cryptoCode + ", cryptoPrice=" + cryptoPrice + ", qrText=" + qrText
                        + ", address=" + address + ", description=" + description + ", orderStatusId=" + orderStatusId + ", timeout=" + timeout + "]";
    }

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    public String getFiatCode() {
        return fiatCode;
    }

    public void setFiatCode(String fiatCode) {
        this.fiatCode = fiatCode;
    }

    public Double getFiatPrice() {
        return fiatPrice;
    }

    public void setFiatPrice(Double fiatPrice) {
        this.fiatPrice = fiatPrice;
    }

    public String getCryptoCode() {
        return cryptoCode;
    }

    public void setCryptoCode(String cryptoCode) {
        this.cryptoCode = cryptoCode;
    }

    public String getCryptoPrice() {
        return cryptoPrice;
    }

    public void setCryptoPrice(String cryptoPrice) {
        this.cryptoPrice = cryptoPrice;
    }

    public String getQrText() {
        return qrText;
    }

    public void setQrText(String qrText) {
        this.qrText = qrText;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Short getOrderStatusId() {
        return orderStatusId;
    }

    public void setOrderStatusId(Short orderStatusId) {
        this.orderStatusId = orderStatusId;
    }

    public Short getOperationId() {
        return operationId;
    }

    public void setOperationId(Short operationId) {
        this.operationId = operationId;
    }

    public Integer getTimeout() {
        return timeout;
    }

    public void setTimeout(Integer timeout) {
        this.timeout = timeout;
    }
}
