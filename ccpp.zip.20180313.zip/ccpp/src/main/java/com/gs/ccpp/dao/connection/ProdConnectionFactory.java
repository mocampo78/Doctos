package com.gs.ccpp.dao.connection;

import java.net.ConnectException;
import java.sql.Connection;
import java.sql.SQLException;

import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Implementation to define the database connection using a Datasource.
 * 
 * @author Emmanuel Salazar
 */
public class ProdConnectionFactory implements ConnectionFactory {
    private static Logger log = LoggerFactory.getLogger(ProdConnectionFactory.class);
    private static final ProdConnectionFactory instance = new ProdConnectionFactory();

    private DataSource dataSource;

    private ProdConnectionFactory() {}

    /**
     * Return the singleton instance of this class.
     * 
     * @return the singleton instance
     */
    public static ProdConnectionFactory getInstance() {
        return instance;
    }

    /**
     * Implementation of the create connection method using the spring's DataSource.
     */
    @Override
    public Connection createConnection() throws ConnectException {
        try {
            final long startTime = System.currentTimeMillis();
            Connection connection = dataSource.getConnection();

            long elapsedTime = System.currentTimeMillis() - startTime;
            log.info("Connection stablished with spring datasource in {} ms", elapsedTime);

            return connection;
        } catch (SQLException e) {
            log.error("An error occurs creating the connection", e);
            throw new ConnectException(e.getMessage());
        }
    }

    /**
     * Set the spring's DataSource.
     * 
     * @param dataSource the DataSource to be used
     */
    public void setDataSource(DataSource dataSource) {
        this.dataSource = dataSource;
    }
}
