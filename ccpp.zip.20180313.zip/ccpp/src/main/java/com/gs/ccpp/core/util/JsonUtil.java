package com.gs.ccpp.core.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * Utilities to handle json strings.
 * 
 * @author Emmanuel Salazar
 */
public class JsonUtil {
    private static Logger log = LoggerFactory.getLogger(JsonUtil.class);
    private static ObjectMapper mapper = new ObjectMapper();

    /**
     * This method will take as input a java object and returns its representation as json string.
     * 
     * @param obj object to be parsed as a json string
     * @return The json string, representing the object
     */
    public static String getJsonString(Object obj) {
        try {
            return mapper.writeValueAsString(obj);
        } catch (JsonProcessingException e) {
            log.error("An error occurs parsing the object to json string", e);
            return null;
        }
    }
}
