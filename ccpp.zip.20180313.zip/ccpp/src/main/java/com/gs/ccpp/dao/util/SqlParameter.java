package com.gs.ccpp.dao.util;

/**
 * Auxiliar object to map the sql parameters to be executed.
 * 
 * @author Emmanuel Salazar
 */
public class SqlParameter {

    private SqlParameterType type;
    private String name;
    private Object value;

    /**
     * Enum with the data types available to be used in the stored procedures.
     * 
     * @author Emmanuel Salazar
     */
    public enum SqlParameterType {
        INPUT_STRING, INPUT_INT, INPUT_DOUBLE, INPUT_LONG, INPUT_SHORT, INPUT_BIGINT;
    }

    /**
     * Empty constructor.
     */
    public SqlParameter() {}

    /**
     * Constructor with the parameter's info.
     * 
     * @param type the parameter's data type
     * @param name the parameter's name
     * @param value the parameter's value
     */
    public SqlParameter(SqlParameterType type, String name, Object value) {
        this.type = type;
        this.name = name;
        this.value = value;
    }

    @Override
    public String toString() {
        return "SqlParameter [type=" + type + ", name=" + name + ", value=" + value + "]";
    }

    /**
     * Get the parameter's data type.
     * 
     * @return the parameter's data type
     */
    public SqlParameterType getType() {
        return this.type;
    }

    /**
     * Set the parameter data type.
     * 
     * @param type the data type to be used
     */
    public void setType(SqlParameterType type) {
        this.type = type;
    }

    /**
     * Get the parameter's name.
     * 
     * @return the parameter's name
     */
    public String getName() {
        return this.name;
    }

    /**
     * Set the parameter name.
     * 
     * @param name the name to be used
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Get the parameter's value.
     * 
     * @return the parameter's value
     */
    public Object getValue() {
        return this.value;
    }

    /**
     * Set the parameter's value.
     * 
     * @param value the value to be used
     */
    public void setValue(Object value) {
        this.value = value;
    }
}
