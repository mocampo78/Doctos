package com.gs.ccpp.dao.order;

import java.net.ConnectException;
import java.sql.SQLException;
import java.util.ArrayList;

import com.gs.ccpp.dao.core.CcppDAO;
import com.gs.ccpp.dao.util.SqlParameter;
import com.gs.ccpp.dao.util.SqlParameter.SqlParameterType;
import com.gs.ccpp.dto.order.OrderDTO;

/**
 * Data Access Object for the order entity.
 * 
 * @author Emmanuel Salazar
 */
public class OrderDAO extends CcppDAO {
    public static final Short ST_PENDING = 1;
    public static final Short ST_SUSPENDED = 2;
    public static final Short ST_CONFIRMED = 3;
    public static final Short ST_CLOSED = 4;

    public static final Short OPER_ADD = 1;
    public static final Short OPER_CHECK = 2;
    public static final Short OPER_DELETE = 3;
    public static final Short OPER_REFRESH = 4;

    private String addOrderQuery = "{call SP_EXE_ORDER(?,?,?,?,?,?,?,?,?,?,?,?,?)}";
    private String getOrderQuery = "{call SP_SEL_ORDER(?)}";
    private String updOrderQuery = "{call SP_EXE_UPD_ORDER(?,?,?,?,?,?,?,?,?,?)}";

    /**
     * Add an order to the database.
     * 
     * @param request the order's information
     * @return the order's information saved in the database
     */
    public OrderDTO addOrder(OrderDTO request) {
        parameters = new ArrayList<>();
        parameters.add(new SqlParameter(SqlParameterType.INPUT_STRING, "PI_ORDER_ID", request.getOrderId()));
        parameters.add(new SqlParameter(SqlParameterType.INPUT_STRING, "PI_CCPP_TRANSAC_ID", request.getTransactionId()));
        parameters.add(new SqlParameter(SqlParameterType.INPUT_STRING, "PI_FIAT_CODE", request.getFiatCode()));
        parameters.add(new SqlParameter(SqlParameterType.INPUT_DOUBLE, "PI_FIAT_PRICE", request.getFiatPrice()));
        parameters.add(new SqlParameter(SqlParameterType.INPUT_STRING, "PI_CRYPTO_CODE", request.getCryptoCode()));
        parameters.add(new SqlParameter(SqlParameterType.INPUT_STRING, "PI_CRYPTO_PRICE", request.getCryptoPrice()));
        parameters.add(new SqlParameter(SqlParameterType.INPUT_STRING, "PI_QR_TEXT", request.getQrText()));
        parameters.add(new SqlParameter(SqlParameterType.INPUT_STRING, "PI_ADDRESS", request.getAddress()));
        parameters.add(new SqlParameter(SqlParameterType.INPUT_STRING, "PI_ORDER_DESCRIPTION", request.getDescription()));
        parameters.add(new SqlParameter(SqlParameterType.INPUT_INT, "PI_TIMEOUT", request.getTimeout()));
        parameters.add(new SqlParameter(SqlParameterType.INPUT_STRING, "PI_USER", request.getUser()));
        parameters.add(new SqlParameter(SqlParameterType.INPUT_STRING, "PI_IP_ADDRESS", request.getIpAddress()));
        parameters.add(new SqlParameter(SqlParameterType.INPUT_STRING, "PI_CENTER_OPERATION", request.getCenterOperation()));

        try {
            return (OrderDTO) executeForObject(addOrderQuery, parameters, OrderDTO.class);
        } catch (ConnectException | SQLException e) {
            throw new RuntimeException(e.getMessage());
        }
    }

    /**
     * Get an order's information from the database.
     * 
     * @param orderId the id of the order to be retrieved
     * @return the order's information saved in the database
     */
    public OrderDTO getOrder(String orderId) {
        parameters = new ArrayList<>();
        parameters.add(new SqlParameter(SqlParameterType.INPUT_STRING, "PI_ORDER_ID", orderId));

        try {
            return (OrderDTO) executeForObject(getOrderQuery, parameters, OrderDTO.class);
        } catch (ConnectException | SQLException e) {
            throw new RuntimeException(e.getMessage());
        }
    }

    /**
     * Update an order in the database.
     * 
     * @param request the updated order's information
     * @return the order's information saved in the database
     */
    public OrderDTO updateOrder(OrderDTO request) {
        parameters = new ArrayList<>();
        parameters.add(new SqlParameter(SqlParameterType.INPUT_STRING, "PI_ORDER_ID", request.getOrderId()));
        parameters.add(new SqlParameter(SqlParameterType.INPUT_STRING, "PI_CCPP_TRANSAC_ID", request.getTransactionId()));
        parameters.add(new SqlParameter(SqlParameterType.INPUT_STRING, "PI_CRYPTO_PRICE", request.getCryptoPrice()));
        parameters.add(new SqlParameter(SqlParameterType.INPUT_STRING, "PI_QR_TEXT", request.getQrText()));
        parameters.add(new SqlParameter(SqlParameterType.INPUT_SHORT, "PI_ORDER_STATUS_ID", request.getOrderStatusId()));
        parameters.add(new SqlParameter(SqlParameterType.INPUT_SHORT, "PI_PROVIDER_OPERATION_ID", request.getOperationId()));
        parameters.add(new SqlParameter(SqlParameterType.INPUT_INT, "PI_TIMEOUT", request.getTimeout()));
        parameters.add(new SqlParameter(SqlParameterType.INPUT_STRING, "PI_USER", request.getUser()));
        parameters.add(new SqlParameter(SqlParameterType.INPUT_STRING, "PI_IP_ADDRESS", request.getIpAddress()));
        parameters.add(new SqlParameter(SqlParameterType.INPUT_STRING, "PI_CENTER_OPERATION", request.getCenterOperation()));

        try {
            return (OrderDTO) executeForObject(updOrderQuery, parameters, OrderDTO.class);
        } catch (ConnectException | SQLException e) {
            throw new RuntimeException(e.getMessage());
        }
    }
}
