package com.gs.ccpp.dao.coppay;

import java.net.ConnectException;
import java.sql.SQLException;
import java.util.ArrayList;

import org.springframework.stereotype.Component;

import com.gs.ccpp.dao.core.CcppDAO;
import com.gs.ccpp.dao.util.SqlParameter;
import com.gs.ccpp.dao.util.SqlParameter.SqlParameterType;
import com.gs.ccpp.dto.coppay.ExternalTransactionLogDTO;

/**
 * Data Access Object for the external transaction log entity.
 * 
 * @author Emmanuel Salazar
 */
@Component
public class ExternalTransactionLogDAO extends CcppDAO {
    private static final String ADD_EXTERNAL_TRANSACTION_LOG_QUERY = "{call SP_INS_EXTERNAL_TRANS_LOG(?,?,?,?,?,?,?,?,?,?)}";

    /**
     * Save the log for the external interaction with the provider.
     * 
     * @param request The information to be saved in the external transaction log
     */
    public void addExternalTransactionLog(ExternalTransactionLogDTO request) {
        parameters = new ArrayList<>();
        parameters.add(new SqlParameter(SqlParameterType.INPUT_STRING, "PI_CCPP_TRANSAC_ID", request.getTransactionId()));
        parameters.add(new SqlParameter(SqlParameterType.INPUT_SHORT, "PI_PROVIDER_ID", request.getProviderId()));
        parameters.add(new SqlParameter(SqlParameterType.INPUT_SHORT, "PI_PROVIDER_OPERATION_ID", request.getProviderOperationId()));
        parameters.add(new SqlParameter(SqlParameterType.INPUT_SHORT, "PI_EXTERNAL_TRANSACTION_STATUS_ID", request.getExternalTransactionStatus()));
        parameters.add(new SqlParameter(SqlParameterType.INPUT_STRING, "PI_REQUEST_DATA", request.getRequestData()));
        parameters.add(new SqlParameter(SqlParameterType.INPUT_STRING, "PI_RESPONSE_DATA", request.getResponseData()));
        parameters.add(new SqlParameter(SqlParameterType.INPUT_INT, "PI_RESPONSE_TIME", request.getResponseTime()));
        parameters.add(new SqlParameter(SqlParameterType.INPUT_STRING, "PI_USER", request.getUser()));
        parameters.add(new SqlParameter(SqlParameterType.INPUT_STRING, "PI_IP_ADDRESS", request.getIpAddress()));
        parameters.add(new SqlParameter(SqlParameterType.INPUT_STRING, "PI_CENTER_OPERATION", request.getCenterOperation()));

        try {
            executeNoResultSet(ADD_EXTERNAL_TRANSACTION_LOG_QUERY, parameters);
        } catch (ConnectException | SQLException e) {
            throw new RuntimeException(e.getMessage());
        }
    }
}
