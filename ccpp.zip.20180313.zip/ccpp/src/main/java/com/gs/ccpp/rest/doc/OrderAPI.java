package com.gs.ccpp.rest.doc;

/**
 * Auxiliar class with the information to be used by swagger documentation.
 * 
 * @author Emmanuel Salazar
 */
public class OrderAPI {
    // DELETE
    public static final String DELETE_TITLE = "Delete/Close an order";
    public static final String DELETE_NOTES = "This method will delete/close an order. After this method call the order will not be available.";

    // GET
    public static final String GET_TITLE = "Get an order detail";
    public static final String GET_NOTES = "This method will retrieve the order's information from the provider.";

    // POST
    public static final String POST_TITLE = "Create an order";
    public static final String POST_NOTES =
                    "This method will use the information provided to create an order with the provider. It will include the price of the crypto currency to satisfy the required fiat amount.";

    // PUT
    public static final String PUT_TITLE = "Refresh an order";
    public static final String PUT_NOTES = "This method will update the order information, including the crypto price amount and the qr text.";

}
