package com.gs.ccpp.core.util;

import java.util.ArrayList;
import java.util.List;

import org.springframework.validation.Errors;
import org.springframework.validation.FieldError;

/**
 * Utility to handle the binding errors during request parsing process.
 * 
 * @author Emmanuel Salazar
 */
public class ValidationUtil {

    /**
     * This method will return a list of error messages from binding result.
     * 
     * @param errors the errors found during request parsing
     * @return list of errors to be displayed to consumer
     */
    public static List<String> fromBindingErrors(Errors errors) {
        List<String> errorsList = new ArrayList<>();

        for (FieldError fieldError : errors.getFieldErrors()) {
            errorsList.add("[" + fieldError.getObjectName() + "." + fieldError.getField() + "] - " + fieldError.getDefaultMessage() + " - Rejected value: " + fieldError.getRejectedValue());
        }

        return errorsList;
    }
}
