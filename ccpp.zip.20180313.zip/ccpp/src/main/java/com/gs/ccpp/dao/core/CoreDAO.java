package com.gs.ccpp.dao.core;

import java.math.BigInteger;
import java.net.ConnectException;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.gs.ccpp.dao.util.ObjectMapper;
import com.gs.ccpp.dao.util.SqlParameter;

/**
 * Core Data Access Object. This class will centralize the core methods to interact with the database.
 * 
 * @author Emmanuel Salazar
 */
public abstract class CoreDAO {

    private static Logger log = LoggerFactory.getLogger(CoreDAO.class);

    protected Connection connection;
    protected CallableStatement statement;

    protected String query;
    protected ArrayList<SqlParameter> parameters;

    protected abstract Connection establishConnection() throws ConnectException;

    /**
     * Execute a query with no result set returned from database.
     * 
     * @param query the query string to be executed
     * @param parameters the parameters to perform the call
     * @throws SQLException if an error occurs executing the SQL statement
     * @throws ConnectException if an error occurs when connecting to the database
     */
    protected void executeNoResultSet(String query, ArrayList<SqlParameter> parameters) throws SQLException, ConnectException {
        execution(query, parameters, establishConnection(), true);
        closeConnection();
    }

    /**
     * Executes a query and retrieve a single object from result set.
     * 
     * @param query the query string to be executed
     * @param parameters the parameters to perform the call
     * @param outputClass the class in which the result set will be parsed
     * @return a single object from outpuClass
     * @throws SQLException if an error occurs executing the SQL statement
     * @throws ConnectException if an error occurs when connecting to the database
     */
    protected <T> Object executeForObject(String query, ArrayList<SqlParameter> parameters, Class<T> outputClass) throws SQLException, ConnectException {
        ResultSet resultSet = executionWithResultSet(query, parameters, establishConnection(), true);
        List<T> resultList = new ObjectMapper<T>().loadObjectWithDBColumn(outputClass, resultSet);
        T result = null;

        if (null != resultList && !resultList.isEmpty()) {
            result = resultList.get(0);
        }

        closeConnection();
        return result;
    }

    /**
     * Executes a query and retrieve a list of objects from result set.
     * 
     * @param query the query string to be executed
     * @param parameters the parameters to perform the call
     * @param outputClass the class in which the result set will be parsed
     * @return a list of objects from outpuClass
     * @throws SQLException if an error occurs executing the SQL statement
     * @throws ConnectException if an error occurs when connecting to the database
     */
    protected <T> List<T> executeForList(String query, ArrayList<SqlParameter> parameters, Class<T> outputClass) throws SQLException, ConnectException {
        ResultSet resultSet = executionWithResultSet(query, parameters, establishConnection(), true);
        List<T> resultList = new ObjectMapper<T>().loadObjectWithDBColumn(outputClass, resultSet);

        closeConnection();
        return resultList;
    }

    /**
     * Executes the call to the database.
     * 
     * @param query the query string to be executed
     * @param parameters the parameters to perform the call
     * @param connection the connection to be used for the call
     * @param isAutoCommit flag to set the auto commit configuration
     * @throws SQLException if an error occurs executing the SQL statement
     * @throws ConnectException if an error occurs when connecting to the database
     */
    private void execution(String query, ArrayList<SqlParameter> parameters, Connection connection, boolean isAutoCommit) throws SQLException, ConnectException {
        final long startTime = System.currentTimeMillis();

        this.connection = connection;
        this.connection.setAutoCommit(isAutoCommit);

        this.statement = prepareStatement(query, parameters);
        this.statement.execute();

        long elapsedTime = System.currentTimeMillis() - startTime;
        log.info("Execution of query [{}] in [{}] ms with parameters :: {} ", query, elapsedTime, parameters.toString());
    }

    /**
     * Executes a call to retrieve a ResultSet.
     * 
     * @param query the query string to be executed
     * @param parameters the parameters to perform the call
     * @param connection the connection to be used for the call
     * @param isAutoCommit flag to set the auto commit configuration
     * @return the result set retrieved from database
     * @throws SQLException if an error occurs executing the SQL statement
     * @throws ConnectException if an error occurs when connecting to the database
     */
    private ResultSet executionWithResultSet(String query, ArrayList<SqlParameter> parameters, Connection connection, boolean isAutoCommit) throws SQLException, ConnectException {
        execution(query, parameters, connection, isAutoCommit);
        return statement.getResultSet();
    }

    /**
     * Prepare the statement to be executed.
     * 
     * @param query the query string to be executed
     * @param parameters the parameter to perform the call
     * @return the statement ready to be executed
     * @throws SQLException if an error occurs preparing the statement
     */
    private CallableStatement prepareStatement(String query, ArrayList<SqlParameter> parameters) throws SQLException {
        final long startTime = System.currentTimeMillis();

        CallableStatement cs = connection.prepareCall(query);

        for (SqlParameter parameter : parameters) {
            if (parameter.getValue() == null) {
                cs.setString(parameter.getName(), null);
            } else {
                switch (parameter.getType()) {
                    case INPUT_STRING:
                        cs.setString(parameter.getName(), (String) parameter.getValue());
                        break;
                    case INPUT_SHORT:
                        cs.setShort(parameter.getName(), (Short) parameter.getValue());
                        break;
                    case INPUT_INT:
                        cs.setInt(parameter.getName(), (Integer) parameter.getValue());
                        break;
                    case INPUT_DOUBLE:
                        cs.setDouble(parameter.getName(), (Double) parameter.getValue());
                        break;
                    case INPUT_LONG:
                        cs.setLong(parameter.getName(), ((Long) parameter.getValue()).longValue());
                        break;
                    case INPUT_BIGINT:
                        cs.setObject(parameter.getName(), (BigInteger) parameter.getValue());
                        break;
                    default:
                        break;

                }
            }
        }

        long elapsedTime = System.currentTimeMillis() - startTime;
        log.info("Callable statement prepared in {} ms", elapsedTime);
        return cs;
    }

    /**
     * This method will close the statement and connection from database.
     * 
     * @throws SQLException if an error occurs closing the items.
     */
    private void closeConnection() throws SQLException {
        final long startTime = System.currentTimeMillis();

        if (this.statement != null) {
            this.statement.close();
        }
        if (this.connection != null) {
            this.connection.close();
        }

        long elapsedTime = System.currentTimeMillis() - startTime;
        log.info("Connection closed in {} ms", elapsedTime);
    }
}
