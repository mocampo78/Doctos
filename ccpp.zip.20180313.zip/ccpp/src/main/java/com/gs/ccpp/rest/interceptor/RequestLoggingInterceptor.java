package com.gs.ccpp.rest.interceptor;

import java.util.UUID;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import com.gs.ccpp.rest.to.AppErrorTO;
import com.gs.ccpp.rest.util.RequestValidator;

/**
 * Interceptor to handle common logic for each call.
 * 
 * @author Emmanuel Salazar
 */
@Component
public class RequestLoggingInterceptor extends HandlerInterceptorAdapter {
    private static Logger log = LoggerFactory.getLogger(RequestLoggingInterceptor.class);

    /**
     * This method will validate that the required headers are being provided in the call. Additionally it will validate the center and user received and generate an unique identifier for the received
     * request.
     */
    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) {
        final long startTime = System.currentTimeMillis();
        RequestValidator validator = new RequestValidator();

        if (!validator.validateRequestHeaders(request)) {
            log.error("Request received with missing  header parameters");

            AppErrorTO error = new AppErrorTO(HttpStatus.BAD_REQUEST, "Missing headers", "Please verify the headers defined for this call in the API");
            validator.processResponse(response, error);
            return false;
        }

        if (!validator.validateCenterUser(request)) {
            log.error("Invalid center/user received in the request");

            AppErrorTO error = new AppErrorTO(HttpStatus.BAD_REQUEST, "Invalid center/user received", "Please verify the user and center sent in the request");
            validator.processResponse(response, error);
            return false;
        }

        String transactionId = UUID.randomUUID().toString();
        request.setAttribute("startTime", startTime);
        request.setAttribute("x-gs-transaction-id", transactionId);

        log.info("[PreHandle id: {}] [{}] to {}", transactionId, request.getMethod(), request.getRequestURL());
        return true;
    }

    /**
     * This method will keep track of the time taken by the server to generate the response.
     */
    @Override
    public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex) {
        long startTime = (Long) request.getAttribute("startTime");
        String transactionId = (String) request.getAttribute("x-gs-transaction-id");

        long endTime = System.currentTimeMillis();

        log.info("[AfterCompletion id: {}] [{}] to {} in :: {} milliseconds", transactionId, request.getMethod(), request.getRequestURL(), endTime - startTime);
    }

}
