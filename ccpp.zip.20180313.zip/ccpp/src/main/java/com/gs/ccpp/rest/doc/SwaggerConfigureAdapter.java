package com.gs.ccpp.rest.doc;

import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

/**
 * Configuration class for the Swagger UI.
 * 
 * @author Emmanuel Salazar
 */
@EnableWebMvc
public class SwaggerConfigureAdapter extends WebMvcConfigurerAdapter {

    /**
     * This method will add the resources required for the Swagger UI extending the WebMvcConfigurerAdapter.
     * 
     * @Param registry the default resource handler registry
     */
    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        registry.addResourceHandler("swagger-ui.html").addResourceLocations("classpath:/META-INF/resources/");
        registry.addResourceHandler("/webjars/**").addResourceLocations("classpath:/META-INF/resources/webjars/");
    }

}
