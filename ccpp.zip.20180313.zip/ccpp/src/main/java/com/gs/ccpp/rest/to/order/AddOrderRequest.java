package com.gs.ccpp.rest.to.order;

import javax.validation.constraints.NotNull;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * Transfer Object for the request of the add order call.
 * 
 * @author Emmanuel Salazar
 */
@ApiModel(value = "Add order request")
public class AddOrderRequest {
    @NotNull(message = "Required field")
    private Double amount;
    @NotNull(message = "Required field")
    private String fiatCurrency;
    @NotNull(message = "Required field")
    private String cryptoCurrency;
    @NotNull(message = "Required field")
    private String description;

    @Override
    public String toString() {
        return "AddOrderRequestTO [amount=" + amount + ", fiatCurrency=" + fiatCurrency + ", cryptoCurrency=" + cryptoCurrency + ", description=" + description + "]";
    }

    /**
     * Get the fiat currency to be used in the order.
     * 
     * @return the fiat currency
     */
    @ApiModelProperty(value = "The fiat currency to be used in the order.", example = "MXN", dataType = "String", allowableValues = "BYN, EUR, MXN, RUB, USD", required = true)
    public String getFiatCurrency() {
        return fiatCurrency;
    }

    /**
     * Set the fiat currency to be used in the order.
     * 
     * @param fiatCurrency the fiat currency for the order
     */
    public void setFiatCurrency(String fiatCurrency) {
        this.fiatCurrency = fiatCurrency;
    }

    /**
     * Get the crypto currency to be used in the order.
     * 
     * @return the crypto currency
     */
    @ApiModelProperty(value = "The crypto currency to be used in the order.", example = "bitcoin", dataType = "String", allowableValues = "bitcoin, dash, ethereum, nem, steem, steem-dollars",
                    required = true)
    public String getCryptoCurrency() {
        return cryptoCurrency;
    }

    /**
     * Set the crypto currency to be used in the order.
     * 
     * @param cryptoCurrency the crypto currency for the order
     */
    public void setCryptoCurrency(String cryptoCurrency) {
        this.cryptoCurrency = cryptoCurrency;
    }

    /**
     * Get the order description to be used.
     * 
     * @return the order description
     */
    @ApiModelProperty(value = "The order's unique description.", example = "Order description", dataType = "String", required = true)
    public String getDescription() {
        return description;
    }

    /**
     * Set the order description to be used.
     * 
     * @param description the description for the order
     */
    public void setDescription(String description) {
        this.description = description;
    }

    /**
     * Get the order's amount.
     * 
     * @return the order amount
     */
    @ApiModelProperty(value = "The order's amount.", example = "100.0", dataType = "Double", required = true)
    public Double getAmount() {
        return amount;
    }

    /**
     * Set the order's amount.
     * 
     * @param amount the amount for the order
     */
    public void setAmount(Double amount) {
        this.amount = amount;
    }

}
