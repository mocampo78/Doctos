package com.gs.ccpp.dao.core;

import java.net.ConnectException;
import java.sql.Connection;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.gs.ccpp.dao.connection.ConnectionFactory;
import com.gs.ccpp.dao.connection.DevConnectionFactory;
import com.gs.ccpp.dao.connection.ProdConnectionFactory;

/**
 * Core Data Access Object for the CCPP application. This defines the establish connection method for the application.
 * 
 * @author Emmanuel Salazar
 */
public class CcppDAO extends CoreDAO {
    private static Logger log = LoggerFactory.getLogger(CcppDAO.class);
    private static String env;

    ConnectionFactory connectionFactory;

    static {
        env = System.getenv("environment");
        if (null == env) {
            env = System.getProperty("environment", "dev");
        }
    }

    /**
     * This method will use an environment variable: spring.profiles.active to define if it will use a JDBC or a connection pool to access the database.
     */
    @Override
    protected Connection establishConnection() throws ConnectException {
        log.info("Environment: {}", env);

        if (env.equals("prod")) {
            connectionFactory = ProdConnectionFactory.getInstance();
        } else {
            connectionFactory = new DevConnectionFactory();
        }

        return connectionFactory.createConnection();
    }
}
