package com.gs.ccpp.dao.connection;

import java.io.IOException;
import java.io.InputStream;
import java.net.ConnectException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Implmentation to define the database connection using JDBC. This is intended for development purposes.
 * 
 * @author Emmanuel Salazar
 */
public class DevConnectionFactory implements ConnectionFactory {
    private static Logger log = LoggerFactory.getLogger(DevConnectionFactory.class);

    private String url;
    private String user;
    private String password;

    /**
     * Implementation of the create connection method using JDBC.
     */
    @Override
    public Connection createConnection() throws ConnectException {
        loadConnectionrProperties();

        try {
            final long startTime = System.currentTimeMillis();
            DriverManager.setLoginTimeout(5);
            Connection connection = DriverManager.getConnection(url, user, password);

            long elapsedTime = System.currentTimeMillis() - startTime;
            log.info("Connection stablished with jdbc to [{}] in {} ms", url, elapsedTime);

            return connection;
        } catch (Exception e) {
            log.error("There is an error creating the connection - URL [{}] for user [{}]", url, user, e);
            throw new ConnectException(e.getMessage());
        }
    }

    /**
     * This method will access the application.properties to retrieve the connection data.
     */
    private void loadConnectionrProperties() {
        Properties properties = new Properties();
        try {
            final long startTime = System.currentTimeMillis();

            InputStream is = getClass().getClassLoader().getResourceAsStream("application.properties");
            properties.load(is);

            url = properties.getProperty("database.url");
            user = properties.getProperty("database.user");
            password = properties.getProperty("database.pass");

            long elapsedTime = System.currentTimeMillis() - startTime;
            log.info("Properties file loaded for dev environment in {} ms", elapsedTime);
        } catch (IOException e) {
            log.error("An error occurs loading the application properties", e);
        }
    }
}
