package com.gs.ccpp.core;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

/**
 * Core class to start the spring boot module. This application will use the internal tomcat defined in spring boot to run the application.
 * 
 * @author Emmanuel Salazar
 */
@SpringBootApplication
@ComponentScan({"com.gs.ccpp.core", "com.gs.ccpp.rest.controller", "com.gs.ccpp.rest.interceptor", "com.gs.ccpp.rest.handler", "com.gs.ccpp.rest.security", "com.gs.ccpp.rest.doc"})
public class CcppApplication {

    /**
     * Main method to run the spring boot application.
     * 
     * @param args NO args are required
     */
    public static void main(String[] args) {
        SpringApplication.run(CcppApplication.class, args);
    }
}
