package com.gs.ccpp.rest.to.order;

import io.swagger.annotations.ApiModelProperty;

/**
 * Transfer Object for the response of the add order call.
 * 
 * @author Emmanuel Salazar
 */
public class AddOrderResponse {

    private String orderId;
    private String qrText;
    private String cryptoPrice;
    private Integer timeout;
    private String address;

    @Override
    public String toString() {
        return "AddOrderTO [orderId=" + orderId + ", qrText=" + qrText + ", cryptoPrice=" + cryptoPrice + ", timeout=" + timeout + ", address=" + address + "]";
    }

    /**
     * Obtain the order Id created in the call.
     * 
     * @return retrive the order Id
     */
    @ApiModelProperty(value = "The order's identifier.", example = "14a7e4c8-d50f-40df-a1d3-4e053c7357a1", dataType = "String")
    public String getOrderId() {
        return orderId;
    }

    /**
     * Set the order Id created in the add order call.
     * 
     * @param orderId the order Id created
     */
    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    /**
     * Retrieve the text that must be used to generate the QR code that will be used for payment.
     * 
     * @return the text to be included in the QR code
     */
    @ApiModelProperty(value = "The text to be included in the QR code.", example = "bitcoin:mgWukXX3hcz2FZTKox1GAptGrgaHwH98QV?amount=0.00065587", dataType = "String")
    public String getQrText() {
        return qrText;
    }

    /**
     * Set the text that will be used to generate the QR code.
     * 
     * @param qrText the text for the QR code
     */
    public void setQrText(String qrText) {
        this.qrText = qrText;
    }

    /**
     * The crypto price calculated from the request information.
     * 
     * @return The crypto price required for the transaction
     */
    @ApiModelProperty(value = "The calculated crypto price for the order.", example = "0.00065587", dataType = "Double")
    public String getCryptoPrice() {
        return cryptoPrice;
    }

    /**
     * Set the crypto amount required for the transaction.
     * 
     * @param cryptoPrice The crypto amount required
     */
    public void setCryptoPrice(String cryptoPrice) {
        this.cryptoPrice = cryptoPrice;
    }

    /**
     * Get the time in which the crypto price provided is valid.
     * 
     * @return The timeout value for the price provided
     */
    @ApiModelProperty(value = "The time in which the order is valid (Milliseconds).", example = "300000", dataType = "Integer")
    public Integer getTimeout() {
        return timeout;
    }

    /**
     * Set the time in which the crypto price will expire.
     * 
     * @param timeout the timeout value to be used
     */
    public void setTimeout(Integer timeout) {
        this.timeout = timeout;
    }

    /**
     * Get the address in which the payment is required.
     * 
     * @return the address to perform the payment
     */
    @ApiModelProperty(value = "The address in which the payment has to be made.", example = "mgWukXX3hcz2FZTKox1GAptGrgaHwH98QV", dataType = "String")
    public String getAddress() {
        return address;
    }

    /**
     * Set the address in which the payment should be made.
     * 
     * @param address the address to receive the payment
     */
    public void setAddress(String address) {
        this.address = address;
    }
}
