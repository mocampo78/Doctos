package com.gs.ccpp.coppay.client.order;

import java.io.IOException;

import org.slf4j.LoggerFactory;

import com.gs.ccpp.coppay.client.CopPayClient;
import com.gs.ccpp.coppay.client.to.ClientErrorResponse;
import com.gs.ccpp.coppay.client.to.order.RefreshOrderClientRequest;
import com.gs.ccpp.coppay.client.to.order.RefreshOrderClientResponse;
import com.gs.ccpp.coppay.client.util.CopPayOperUtil;
import com.gs.ccpp.rest.vo.RequestDataVO;

/**
 * Client for CopPay's web service to refresh an order.
 * 
 * @author Emmanuel Salazar
 */
public class RefreshOrderClient extends CopPayClient {
    public static final Short REFRESH_OPER = 4;

    private RefreshOrderClientResponse response;

    /**
     * The constructor for the refresh order client.
     * 
     * @param requestDataVO the information of the caller for the request
     */
    public RefreshOrderClient(RequestDataVO requestDataVO) {
        super(requestDataVO);

        log = LoggerFactory.getLogger(AddOrderClient.class);
        url = CopPayOperUtil.getInstance().getCopPayMap().get(REFRESH_OPER).getEndpoint();
    }

    /**
     * Execute the refresh order web service from CopPay.
     * 
     * @param orderId the order id to be retrieved
     * @return the information about the updated order
     */
    public RefreshOrderClientResponse refreshOrder(String orderId) {
        log.info("Request received to refresh order: {}", orderId);
        RefreshOrderClientRequest request = new RefreshOrderClientRequest(requestDataVO.getApiKey(), orderId);
        responseEntity = execute(REFRESH_OPER, request);

        try {
            response = mapper.readValue(responseEntity.getBody(), RefreshOrderClientResponse.class);
            response.setOrderId(orderId);
        } catch (IOException e) {
            log.error("Error parsing the response from CopPay", e);
            elapsedTime = System.currentTimeMillis() - startTime;

            ClientErrorResponse error = new ClientErrorResponse(e.getMessage());
            saveClientLog(error, false);

            throw new RuntimeException(e);
        }

        saveClientLog(response, true);
        log.info("Refresh order request processed with response: {}", response.toString());
        return response;
    }
}
