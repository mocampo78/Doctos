package com.gs.ccpp.coppay.client.to.order;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * The response information from CopPay to the delete order call.
 * 
 * @author Emmanuel Salazar
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class DeleteOrderClientResponse {
    private String orderId;
    private Boolean isDeleteSuccessful;
    private String message;

    @Override
    public String toString() {
        return "DeleteOrderClientResponse [orderId=" + orderId + ", isDeleteSuccessful=" + isDeleteSuccessful + ", message=" + message + "]";
    }

    /**
     * Obtain the order Id from the call.
     * 
     * @return the order ID
     */
    public String getOrderId() {
        return orderId;
    }

    /**
     * Set the order Id for the call.
     * 
     * @param orderId the order Id sent to be deleted
     */
    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    /**
     * Obtain a flag to validate if the delete process was successful.
     * 
     * @return flag for delete success status
     */
    public Boolean getIsDeleteSuccessful() {
        return isDeleteSuccessful;
    }

    /**
     * Set the flag about the delete process.
     * 
     * @param isDeleteSuccessful if the delete process was successful
     */
    public void setIsDeleteSuccessful(Boolean isDeleteSuccessful) {
        this.isDeleteSuccessful = isDeleteSuccessful;
    }

    /**
     * Retrieve the message from the delete process performed by CopPay.
     * 
     * @return the message received from CopPay
     */
    public String getMessage() {
        return message;
    }

    /**
     * Get the message from the delete process performed by CopPay.
     * 
     * @param message the message from CopPay's process
     */
    public void setMessage(String message) {
        this.message = message;
    }
}
