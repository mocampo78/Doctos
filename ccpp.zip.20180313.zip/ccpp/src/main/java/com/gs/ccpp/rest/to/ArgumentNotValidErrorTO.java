package com.gs.ccpp.rest.to;

import java.util.List;

import org.springframework.http.HttpStatus;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * Transfer Object to communicate argument validation errors.
 * 
 * @author Emmanuel Salazar
 */
@ApiModel(value = "Argument Error")
public class ArgumentNotValidErrorTO extends AppErrorTO {
    private List<String> argumentErrors;

    /**
     * Empty constructor.
     */
    public ArgumentNotValidErrorTO() {}

    /**
     * The constructor with parameters.
     * 
     * @param status the HTTP status
     * @param errorCode The error code
     * @param errorDescription The error description
     */
    public ArgumentNotValidErrorTO(HttpStatus status, String errorCode, String errorDescription) {
        this.status = status;
        this.errorCode = errorCode;
        this.errorDescription = errorDescription;
    }

    @Override
    public String toString() {
        return "ArgumentNotValidErrorTO [status=" + status + ", errorCode=" + errorCode + ", errorDescription=" + errorDescription + "argumentErrors=" + argumentErrors + "]";
    }

    /**
     * Retrieve the call input argument's errors.
     * 
     * @return the errors validating the input arguments
     */
    @ApiModelProperty(value = "The list of argument errors.",
                    example = "[\n\"[Request.description] - Required field - Rejected value: null\",\n\"[Request.amount] - Required field - Rejected value: null\"\n]")
    public List<String> getArgumentErrors() {
        return argumentErrors;
    }

    /**
     * Set the call input argument's errors. 
     * 
     * @param argumentErrors the erros validating the input arguments
     */
    public void setArgumentErrors(List<String> argumentErrors) {
        this.argumentErrors = argumentErrors;
    }
}
