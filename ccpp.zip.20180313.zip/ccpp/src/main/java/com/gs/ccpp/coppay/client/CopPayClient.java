package com.gs.ccpp.coppay.client;

import org.slf4j.Logger;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.gs.ccpp.coppay.client.to.ClientErrorResponse;
import com.gs.ccpp.coppay.client.to.CopPayRequest;
import com.gs.ccpp.coppay.client.util.CopPayClientUtil;
import com.gs.ccpp.coppay.client.util.CopPayOperUtil;
import com.gs.ccpp.core.util.JsonUtil;
import com.gs.ccpp.dao.coppay.ExternalTransactionLogDAO;
import com.gs.ccpp.dto.coppay.ExternalTransactionLogDTO;
import com.gs.ccpp.rest.vo.RequestDataVO;

/**
 * Core client to consume the CopPay's web services.
 * 
 * @author Emmanuel Salazar
 */
public class CopPayClient {
    protected final Short providerId = 1;
    protected Short providerOperationId;
    protected Logger log;

    protected RestTemplate restTemplate;
    protected ResponseEntity<String> responseEntity;
    protected String url;

    protected String requestStr;
    protected String responseStr;

    protected long startTime;
    protected long elapsedTime;

    protected RequestDataVO requestDataVO;
    protected ObjectMapper mapper = new ObjectMapper();

    public CopPayClient(RequestDataVO requestDataVO) {
        this.requestDataVO = requestDataVO;
    }

    /**
     * Executes the call to the provider's web service.
     * 
     * @param operationId the operation to be executed
     * @param request the request body to call the web service
     * @return the response from the web service call
     */
    protected ResponseEntity<String> execute(Short operationId, CopPayRequest request) {
        restTemplate = new RestTemplate(CopPayClientUtil.getRequestFactory(CopPayOperUtil.getInstance().getCopPayMap().get(operationId).getTimeout()));
        providerOperationId = operationId;
        try {
            startTime = System.currentTimeMillis();
            responseEntity = restTemplate.postForEntity(url, getHttpEntity(request), String.class);
            elapsedTime = System.currentTimeMillis() - startTime;

            log.info("CopPay call executed in [{} ms] with status {}", elapsedTime, responseEntity.getStatusCodeValue());

            if (responseEntity.getStatusCodeValue() != 200) {
                throw new ResourceAccessException("Error retrieving response from CopPay, with http code: " + responseEntity.getStatusCodeValue());
            }
        } catch (Exception e) {
            log.error("CopPay call failed with message {}", e.getMessage(), e);
            elapsedTime = System.currentTimeMillis() - startTime;

            ClientErrorResponse error = new ClientErrorResponse(e.getMessage());
            saveClientLog(error, false);

            throw e;
        }
        return responseEntity;
    }

    /**
     * Save the client communication log in the database.
     * 
     * @param response the response received from the provider
     * @param isSuccess indicates if the call to provider was successful
     */
    protected void saveClientLog(Object response, Boolean isSuccess) {
        responseStr = JsonUtil.getJsonString(response);

        ExternalTransactionLogDTO externaltransactionLogDTO = new ExternalTransactionLogDTO();
        externaltransactionLogDTO.setRequestData(requestStr);
        externaltransactionLogDTO.setResponseData(responseStr);

        externaltransactionLogDTO.setTransactionId(requestDataVO.getTransactionId());
        externaltransactionLogDTO.setIpAddress(requestDataVO.getIpAddress());
        externaltransactionLogDTO.setCenterOperation(requestDataVO.getCenterId());
        externaltransactionLogDTO.setUser(requestDataVO.getUserId());

        externaltransactionLogDTO.setProviderId(providerId);
        externaltransactionLogDTO.setProviderOperationId(providerOperationId);
        externaltransactionLogDTO.setResponseTime((int) elapsedTime);
        externaltransactionLogDTO.setExternalTransactionStatus(isSuccess ? (short) 1 : (short) 0);

        ExternalTransactionLogDAO externalTransactionLogDAO = new ExternalTransactionLogDAO();
        externalTransactionLogDAO.addExternalTransactionLog(externaltransactionLogDTO);

        log.info("Log for client transaction saved: Request[ {} ] - Response [ {} ]", requestStr, responseStr);
    }

    /**
     * This method will create the HttpEntity to perform the call to CopPay's web service it will include the object parsed as json string for the body and the required http headers. As it is required
     * now the only header required is: content-type as application/json
     * 
     * @param obj The object to be sent in the http request body
     * @return the entity with the required body and headers
     */
    private HttpEntity<String> getHttpEntity(Object obj) {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);

        requestStr = JsonUtil.getJsonString(obj);
        return new HttpEntity<>(requestStr, headers);
    }

}
