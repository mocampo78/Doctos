package com.gs.ccpp.coppay.client.order;

import java.io.IOException;

import org.slf4j.LoggerFactory;

import com.gs.ccpp.coppay.client.CopPayClient;
import com.gs.ccpp.coppay.client.to.ClientErrorResponse;
import com.gs.ccpp.coppay.client.to.order.AddOrderClientRequest;
import com.gs.ccpp.coppay.client.to.order.AddOrderClientResponse;
import com.gs.ccpp.coppay.client.util.CopPayOperUtil;
import com.gs.ccpp.rest.vo.RequestDataVO;

/**
 * Client for CopPay's web service to add/create an order.
 * 
 * @author Emmanuel Salazar
 */
public class AddOrderClient extends CopPayClient {
    public static final Short ADD_OPER = 1;

    private AddOrderClientResponse response;

    /**
     * The constructor for the add order client.
     * 
     * @param requestDataVO the information of the caller for the request
     */
    public AddOrderClient(RequestDataVO requestDataVO) {
        super(requestDataVO);

        log = LoggerFactory.getLogger(AddOrderClient.class);
        url = CopPayOperUtil.getInstance().getCopPayMap().get(ADD_OPER).getEndpoint();
    }

    /**
     * Execute the add order web service from CopPay.
     * 
     * @param request the information required to perform the call
     * @return the information about the order created by CopPay
     */
    public AddOrderClientResponse addOrder(AddOrderClientRequest request) {
        log.info("Request received to add an order: {}", request.toString());
        responseEntity = execute(ADD_OPER, request);

        try {
            response = mapper.readValue(responseEntity.getBody(), AddOrderClientResponse.class);
        } catch (IOException e) {
            log.error("Error parsing the response from CopPay", e);
            elapsedTime = System.currentTimeMillis() - startTime;

            ClientErrorResponse error = new ClientErrorResponse(e.getMessage());
            saveClientLog(error, false);

            throw new RuntimeException(e);
        }

        saveClientLog(response, true);
        log.info("Add order request processed with response: {}", response.toString());
        return response;
    }
}
