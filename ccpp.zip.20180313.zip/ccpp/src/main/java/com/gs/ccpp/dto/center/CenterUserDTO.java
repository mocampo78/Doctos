package com.gs.ccpp.dto.center;

import javax.persistence.Column;
import javax.persistence.Entity;

import com.gs.ccpp.dto.CoreDTO;

/**
 * DTO to be used to retrieve Center's information from database.
 * 
 * @author Emmanuel Salazar
 */
@Entity
public class CenterUserDTO extends CoreDTO {
    @Column(name = "FC_CENTER_OPERATION")
    private String centerId;
    @Column(name = "FC_USER")
    private String userId;
    @Column(name = "FC_CENTER_COPPAY_CONF")
    private String apiKey;

    @Override
    public String toString() {
        return "CenterUserDTO [centerId=" + centerId + ", userId=" + userId + ", apiKey=" + apiKey + "]";
    }

    public String getCenterId() {
        return centerId;
    }

    public void setCenterId(String centerId) {
        this.centerId = centerId;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getApiKey() {
        return apiKey;
    }

    public void setApiKey(String apiKey) {
        this.apiKey = apiKey;
    }
}
