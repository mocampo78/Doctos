package com.gs.ccpp.coppay.client.to.order;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * The response information from CopPay to the refresh order call.
 * 
 * @author Emmanuel Salazar
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class RefreshOrderClientResponse {
    private String orderId;
    private String cryptoPrice;
    private Integer timeout;
    private String qrText;

    @Override
    public String toString() {
        return "RefreshOrderTO [orderId=" + orderId + ", cryptoPrice=" + cryptoPrice + ", timeout=" + timeout + ", qrText=" + qrText + "]";
    }

    /**
     * Obtain the order Id from the call.
     * 
     * @return the order ID
     */
    public String getOrderId() {
        return orderId;
    }

    /**
     * Set the the order Id for the call.
     * 
     * @param orderId the order Id to be used
     */
    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    /**
     * Get the updated crypto price for the order.
     * 
     * @return the updated crypto price
     */
    public String getCryptoPrice() {
        return cryptoPrice;
    }

    /**
     * Set the updated crypto price for the order.
     * 
     * @param cryptoPrice the updated crypto price for the order
     */
    public void setCryptoPrice(String cryptoPrice) {
        this.cryptoPrice = cryptoPrice;
    }

    /**
     * Get the timeout for the updated crypto price.
     * 
     * @return the timeout for the updated crypto price
     */
    public Integer getTimeout() {
        return timeout;
    }

    /**
     * Set the timeout for the crypto price.
     * 
     * @param timeout the timeout for the updated crypto price
     */
    public void setTimeout(Integer timeout) {
        this.timeout = timeout;
    }

    /**
     * Get the updated QR text with the updated crypto price.
     * 
     * @return the QR text with the updated crypto price
     */
    public String getQrText() {
        return qrText;
    }

    /**
     * Set the updated QR text with the updated crypto price.
     * 
     * @param qrText set the QR text with the updated crypto price
     */
    public void setQrText(String qrText) {
        this.qrText = qrText;
    }
}
