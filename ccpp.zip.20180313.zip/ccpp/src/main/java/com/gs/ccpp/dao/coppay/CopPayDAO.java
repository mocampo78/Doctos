package com.gs.ccpp.dao.coppay;

import java.net.ConnectException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import com.gs.ccpp.dao.core.CcppDAO;
import com.gs.ccpp.dao.util.SqlParameter;
import com.gs.ccpp.dao.util.SqlParameter.SqlParameterType;
import com.gs.ccpp.dto.coppay.CopPayDataDTO;

/**
 * Data Access Object for CopPay's entity.
 * 
 * @author Emmanuel Salazar
 */
public class CopPayDAO extends CcppDAO {
    /**
     * The provider Id defined for Coppay.
     */
    public static final Short COPPAY_PROVIDER = 1;
    private static final String GET_COPPAY_DATA_QUERY = "{call SP_SEL_PROVIDER_OPERATION(?)}";

    /**
     * Returns the provider connection information per operation.
     * 
     * @param providerId the provider id to be looked up
     * @return the information from provider's operation
     */
    public Map<Short, CopPayDataDTO> getCopPayData(Short providerId) {
        parameters = new ArrayList<>();
        parameters.add(new SqlParameter(SqlParameterType.INPUT_SHORT, "PI_PROVIDER_ID", providerId));

        List<CopPayDataDTO> copPayDataList;
        try {
            copPayDataList = executeForList(GET_COPPAY_DATA_QUERY, parameters, CopPayDataDTO.class);
        } catch (ConnectException | SQLException e) {
            throw new RuntimeException(e.getMessage());
        }

        Map<Short, CopPayDataDTO> resultMap = new HashMap<Short, CopPayDataDTO>();

        for (Iterator<CopPayDataDTO> iterator = copPayDataList.iterator(); iterator.hasNext();) {
            CopPayDataDTO copPayDataVO = (CopPayDataDTO) iterator.next();
            resultMap.put(copPayDataVO.getOperationId(), copPayDataVO);
        }

        return resultMap;
    }
}
