package com.gs.ccpp.coppay.client.to;

/**
 * Abstract class with the common elements for the CopPay's web services request.
 * 
 * @author Emmanuel Salazar
 */
public abstract class CopPayRequest {
    /**
     * The api key defined to communicate with CopPay.
     */
    protected final String apiKey;

    public CopPayRequest(String apiKey) {
        this.apiKey = apiKey;
    }

    /**
     * Get the API key to be used in the call.
     * 
     * @return the API key
     */
    public String getApiKey() {
        return apiKey;
    }

}
