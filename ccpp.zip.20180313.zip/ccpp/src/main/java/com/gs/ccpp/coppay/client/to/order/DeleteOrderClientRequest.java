package com.gs.ccpp.coppay.client.to.order;

import com.gs.ccpp.coppay.client.to.CopPayRequest;

/**
 * Request to delete/close an order from CopPay.
 * 
 * @author Emmanuel Salazar
 */
public class DeleteOrderClientRequest extends CopPayRequest {
    private String orderId;

    /**
     * Instantiate the request with the order Id.
     * 
     * @param orderId the order Id to be deleted
     */
    public DeleteOrderClientRequest(String apiKey, String orderId) {
        super(apiKey);
        this.orderId = orderId;
    }

    @Override
    public String toString() {
        return "DeleteOrderClientRequest [orderId=" + orderId + ", apiKey=" + apiKey + "]";
    }

    /**
     * Obtain the order Id from the call.
     * 
     * @return the order ID
     */
    public String getOrderId() {
        return orderId;
    }

    /**
     * Set the order Id for the call.
     * 
     * @param orderId the order Id to be deleted
     */
    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }
}
