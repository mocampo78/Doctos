package com.gs.ccpp.coppay.client.util;

import java.util.Map;

import com.gs.ccpp.dto.coppay.CopPayDataDTO;

/**
 * Utility to handle the information from CopPay's WS methods.
 * 
 * @author Emmanuel Salazar
 */
public class CopPayOperUtil {
    private static final CopPayOperUtil instance = new CopPayOperUtil();
    private Map<Short, CopPayDataDTO> copPayMap;

    private CopPayOperUtil() {}

    /**
     * Return the singleton instance of this class.
     * 
     * @return the singleton instance
     */
    public static CopPayOperUtil getInstance() {
        return instance;
    }

    /**
     * Retrieve a map with the information of CopPay's webservice method.
     * 
     * @return A map with the information for CopPay's operations
     */
    public Map<Short, CopPayDataDTO> getCopPayMap() {
        return copPayMap;
    }

    /**
     * Set the map with the information of CopPay's webservice method.
     * 
     * @param copPayMap the map to be set
     */
    public void setCopPayMap(Map<Short, CopPayDataDTO> copPayMap) {
        this.copPayMap = copPayMap;
    }

}
