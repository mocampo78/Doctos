package com.gs.ccpp.rest.handler;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.MethodParameter;
import org.springframework.http.MediaType;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.server.ServerHttpRequest;
import org.springframework.http.server.ServerHttpResponse;
import org.springframework.http.server.ServletServerHttpRequest;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.servlet.mvc.method.annotation.ResponseBodyAdvice;

/**
 * Handler to add the CORS headers to the reponses.
 * 
 * @author Emmanuel Salazar
 */
@ControllerAdvice
public class HeadersModifierHandler implements ResponseBodyAdvice<Object> {
    private static Logger log = LoggerFactory.getLogger(HeadersModifierHandler.class);

    @Override
    public boolean supports(final MethodParameter returnType, final Class<? extends HttpMessageConverter<?>> converterType) {
        return true;
    }

    /**
     * Befor return the response, the server will add the CORS headers.
     */
    @Override
    public Object beforeBodyWrite(final Object body, final MethodParameter returnType, final MediaType selectedContentType, final Class<? extends HttpMessageConverter<?>> selectedConverterType,
                    final ServerHttpRequest request, final ServerHttpResponse response) {
        ServletServerHttpRequest servletRequest = (ServletServerHttpRequest) request;
        String context = servletRequest.getServletRequest().getRequestURI();
        String transactionId = (String) servletRequest.getServletRequest().getAttribute("x-gs-transaction-id");

        if (context.contains("ccpp") && null != transactionId) {
            response.getHeaders().add("Access-Control-Allow-Origin", "*");
            response.getHeaders().add("Access-Control-Allow-Headers", "origin, content-type, accept, authorization, x-gs-transaction-id, x-gs-center-id");
            response.getHeaders().add("Access-Control-Request-Headers", "origin, content-type, accept, authorization, x-gs-transaction-id, x-gs-center-id");
            response.getHeaders().add("Access-Control-Allow-Credentials", "true");
            response.getHeaders().add("Access-Control-Allow-Methods", "GET,POST,PUT,DELETE");
            response.getHeaders().add("Access-Control-Max-Age", "1209600");
            response.getHeaders().add("x-gs-transaction-id", transactionId);

            log.info("Custom headers added for transaction id {}.", transactionId);
        }

        return body;
    }
}
