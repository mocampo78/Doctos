package com.gs.ccpp.coppay.client.util;

import java.security.cert.X509Certificate;

import javax.net.ssl.SSLContext;

import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.ssl.TrustStrategy;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;

import com.gs.ccpp.core.util.JsonUtil;

/**
 * Utility class to encapsulate the logic needed to communicate to CopPay's web services.
 * 
 * @author Emmanuel Salazar
 */
public class CopPayClientUtil {

    private static Logger log = LoggerFactory.getLogger(CopPayClientUtil.class);

    /**
     * This method will return a request factory that does not validate the SSL certificates from CopPay, as them are not signed by a trusted authority.
     * 
     * @param timeout The timeout for the connection with the provider
     * @return the request factory that allows to communicate with CopPay
     */
    public static HttpComponentsClientHttpRequestFactory getRequestFactory(int timeout) {
        TrustStrategy acceptingTrustStrategy = (X509Certificate[] chain, String authType) -> true;

        SSLContext sslContext;
        try {
            sslContext = org.apache.http.ssl.SSLContexts.custom().loadTrustMaterial(null, acceptingTrustStrategy).build();
        } catch (Exception e) {
            log.error("An error occurs creating the SSLContext for the request factory", e);
            return null;
        }

        SSLConnectionSocketFactory csf = new SSLConnectionSocketFactory(sslContext);
        CloseableHttpClient httpClient = HttpClients.custom().setSSLSocketFactory(csf).build();

        HttpComponentsClientHttpRequestFactory requestFactory = new HttpComponentsClientHttpRequestFactory();
        requestFactory.setHttpClient(httpClient);
        requestFactory.setConnectTimeout(timeout);

        return requestFactory;
    }

    /**
     * This method will create the HttpEntity to perform the call to CopPay's web service it will include the object parsed as json string for the body and the required http headers. As it is required
     * now the only header required is: content-type as application/json.
     * 
     * @param obj The object to be sent in the http request body
     * @return the entity with the required body and headers
     */
    public static HttpEntity<String> getHttpEntity(Object obj) {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);

        return new HttpEntity<>(JsonUtil.getJsonString(obj), headers);
    }
}
