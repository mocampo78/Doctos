package com.gs.ccpp.rest.to.order;

import io.swagger.annotations.ApiModelProperty;

/**
 * Transfer Object for the response of the refresh order call.
 * 
 * @author Emmanuel Salazar
 */
public class RefreshOrderResponse {
    private String orderId;
    private String cryptoPrice;
    private Integer timeout;
    private String qrText;

    @Override
    public String toString() {
        return "RefreshOrderTO [orderId=" + orderId + ", cryptoPrice=" + cryptoPrice + ", timeout=" + timeout + ", qrText=" + qrText + "]";
    }

    /**
     * Obtain the order Id from the call.
     * 
     * @return the order ID
     */
    @ApiModelProperty(value = "Echo of the requested order's identifier.", example = "14a7e4c8-d50f-40df-a1d3-4e053c7357a1", dataType = "String")
    public String getOrderId() {
        return orderId;
    }

    /**
     * Set the the order Id for the call.
     * 
     * @param orderId the id of the order 
     */
    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    /**
     * Get the updated crypto price for the order.
     * 
     * @return the updated crypto price
     */
    @ApiModelProperty(value = "The updated crypto price for the order.", example = "0.00069355", dataType = "Double")
    public String getCryptoPrice() {
        return cryptoPrice;
    }

    /**
     * Set the updated crypto price for the order.
     * 
     * @param cryptoPrice the updated crypto price for the order
     */
    public void setCryptoPrice(String cryptoPrice) {
        this.cryptoPrice = cryptoPrice;
    }

    /**
     * Get the timeout for the updated crypto price.
     * 
     * @return the timeout for the updated crypto price
     */
    @ApiModelProperty(value = "The time in which the order is valid (Milliseconds).", example = "300000", dataType = "Integer")
    public Integer getTimeout() {
        return timeout;
    }

    /**
     * Set the timeout for the crypto price.
     * 
     * @param timeout the timeout for the updated crypto price
     */
    public void setTimeout(Integer timeout) {
        this.timeout = timeout;
    }

    /**
     * Get the updated QR text with the updated crypto price.
     * 
     * @return the QR text with the updated crypto price
     */
    @ApiModelProperty(value = "The updated text to be included in the QR code.", example = "bitcoin:mgWukXX3hcz2FZTKox1GAptGrgaHwH98QV?amount=0.00069355", dataType = "String")
    public String getQrText() {
        return qrText;
    }

    /**
     * Set the updated QR text with the updated crypto price.
     * 
     * @param qrText set the QR text with the updated crypto price
     */
    public void setQrText(String qrText) {
        this.qrText = qrText;
    }
}
