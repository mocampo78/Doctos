package com.gs.ccpp.rest.security;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.authentication.www.BasicAuthenticationEntryPoint;

import com.gs.ccpp.core.util.JsonUtil;
import com.gs.ccpp.rest.to.AppErrorTO;

/**
 * Entry point to perform the Basic authentication for the web sercices.
 * 
 * @author Emmanuel Salazar
 */
public class CustomBasicAuthenticationEntryPoint extends BasicAuthenticationEntryPoint {
    private static Logger log = LoggerFactory.getLogger(CustomBasicAuthenticationEntryPoint.class);

    /**
     * If an invalid authentication event is received, it will generate the proper response to the consumer.
     */
    @Override
    public void commence(final HttpServletRequest request, final HttpServletResponse response, final AuthenticationException authException) throws IOException, ServletException {
        response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
        response.addHeader("WWW-Authenticate", "Basic realm=" + getRealmName() + "");
        response.addHeader("Content-type", "application/json");

        log.error("Invalid login attempt from {}", request.getRemoteAddr(), authException);

        AppErrorTO error = new AppErrorTO(HttpStatus.UNAUTHORIZED, "Unauthorized access", "Please verify the credentials used in the call");

        PrintWriter writer = response.getWriter();
        writer.println(JsonUtil.getJsonString(error));
    }

    /**
     * Defines the authentication realm used.
     */
    @Override
    public void afterPropertiesSet() throws Exception {
        setRealmName("CCPP_REALM");
        super.afterPropertiesSet();
    }
}
