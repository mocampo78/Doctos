package com.gs.ccpp.rest.util;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.gs.ccpp.core.util.JsonUtil;
import com.gs.ccpp.dao.center.CenterDAO;
import com.gs.ccpp.dto.center.CenterUserDTO;
import com.gs.ccpp.rest.to.AppErrorTO;

/**
 * Utility to validate the request received.
 * 
 * @author Emmanuel Salazar
 */
public class RequestValidator {
    private static Logger log = LoggerFactory.getLogger(RequestValidator.class);

    String centerId;
    String userId;

    /**
     * Validates the provided request headers.
     * 
     * @param request the HTTP request
     * @return flag to indicate if the required headers are received
     */
    public Boolean validateRequestHeaders(HttpServletRequest request) {
        try {
            centerId = request.getHeader("x-gs-center-id");

            if (null != centerId && !centerId.isEmpty()) {
                request.setAttribute("x-gs-center-id", centerId);
                return true;
            }
        } catch (Exception e) {
            return false;
        }

        return false;
    }

    /**
     * Validates if the user and center provided are valid.
     * 
     * @param request the HTTP request
     * @return flag to indicate if the center and user are valid
     */
    public boolean validateCenterUser(HttpServletRequest request) {
        try {
            userId = request.getUserPrincipal().getName();

            CenterDAO centerDAO = new CenterDAO();
            CenterUserDTO centerUserDTO = centerDAO.getCenterUser(centerId, userId);
            if (null != centerUserDTO) {
                request.setAttribute("x-gs-api-key", centerUserDTO.getApiKey());
                return true;
            }
            return false;
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * Process an error response.
     * 
     * @param response the HTTP response
     * @param error the error detected
     */
    public void processResponse(HttpServletResponse response, AppErrorTO error) {
        log.error("Request received with missing parameters");

        response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
        response.addHeader("Content-type", "application/json");

        try {
            PrintWriter writer = response.getWriter();
            writer.println(JsonUtil.getJsonString(error));
        } catch (IOException e) {
            log.error("An error occurs when creating the response for invalid request", e);
            throw new RuntimeException(e.getMessage());
        }
    }

}
