package com.gs.ccpp.dto;

import javax.persistence.Column;
import javax.persistence.Entity;

/**
 * Core Data Transfer Object to be used for the database.
 * 
 * @author Emmanuel Salazar
 */
@Entity
public abstract class CoreDTO {
    @Column(name = "FC_CCPP_TRANSAC_ID")
    protected String transactionId;
    @Column(name = "FC_USER")
    protected String user;
    @Column(name = "FC_IP_ADDRESS")
    protected String ipAddress;
    @Column(name = "FC_CENTER_OPERATION")
    protected String centerOperation;

    public String getTransactionId() {
        return transactionId;
    }

    public void setTransactionId(String transactionId) {
        this.transactionId = transactionId;
    }

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public String getIpAddress() {
        return ipAddress;
    }

    public void setIpAddress(String ipAddress) {
        this.ipAddress = ipAddress;
    }

    public String getCenterOperation() {
        return centerOperation;
    }

    public void setCenterOperation(String centerOperation) {
        this.centerOperation = centerOperation;
    }
}
