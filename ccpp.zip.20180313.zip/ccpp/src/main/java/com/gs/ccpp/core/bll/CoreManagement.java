package com.gs.ccpp.core.bll;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.gs.ccpp.rest.vo.RequestDataVO;

/**
 * Core managemet class to be extended by the management classes. It handles the information from the requestor to make it available in the deeper layers of the application.
 * 
 * @author Emmanuel Salazar
 */
public class CoreManagement {

    protected RequestDataVO requestDataVO = new RequestDataVO();
    private static Logger log = LoggerFactory.getLogger(CoreManagement.class);

    /**
     * The constructor for the management class.
     * 
     * @param httpRequest the information from the HTTP request
     */
    public CoreManagement(HttpServletRequest httpRequest) {
        try {
            requestDataVO.setTransactionId((String) httpRequest.getAttribute("x-gs-transaction-id"));
            requestDataVO.setCenterId((String) httpRequest.getAttribute("x-gs-center-id"));
            requestDataVO.setIpAddress(httpRequest.getRemoteAddr());
            requestDataVO.setUserId(httpRequest.getUserPrincipal().getName());
            requestDataVO.setApiKey((String) httpRequest.getAttribute("x-gs-api-key"));
        } catch (Exception e) {
            log.error("Missing information in the request", e);
            throw new IllegalArgumentException("Missing information in the request");
        }
    }
}
