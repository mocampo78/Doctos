package com.gs.ccpp.rest.vo;

/**
 * Value object with the request information received.
 * 
 * @author Emmanuel Salazar
 */
public class RequestDataVO {
    private String transactionId;
    private String ipAddress;
    private String userId;
    private String centerId;
    private String apiKey;

    @Override
    public String toString() {
        return "RequestDataVO [transactionId=" + transactionId + ", ipAddress=" + ipAddress + ", userId=" + userId + ", centerId=" + centerId + "]";
    }

    public String getTransactionId() {
        return transactionId;
    }

    public void setTransactionId(String transactionId) {
        this.transactionId = transactionId;
    }

    public String getIpAddress() {
        return ipAddress;
    }

    public void setIpAddress(String ipAddress) {
        this.ipAddress = ipAddress;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getCenterId() {
        return centerId;
    }

    public void setCenterId(String centerId) {
        this.centerId = centerId;
    }

    public String getApiKey() {
        return apiKey;
    }

    public void setApiKey(String apiKey) {
        this.apiKey = apiKey;
    }

}
