package com.gs.ccpp.rest.to.order;

import io.swagger.annotations.ApiModelProperty;

/**
 * Transfer Object for the response of the check order call.
 * 
 * @author Emmanuel Salazar
 */
public class CheckOrderResponse {

    private String orderId;
    private Boolean isConfirmed;
    private Boolean isClosed;
    private Boolean isSuspended;
    private Integer timeout;

    @Override
    public String toString() {
        return "CheckOrderTO [orderId=" + orderId + ", isConfirmed=" + isConfirmed + ", isClosed=" + isClosed + ", isSuspended=" + isSuspended + ", timeout=" + timeout + "]";
    }

    /**
     * Obtain the order Id from the call.
     * 
     * @return the order Id
     */
    @ApiModelProperty(value = "Echo of the requested order's identifier.", example = "14a7e4c8-d50f-40df-a1d3-4e053c7357a1", dataType = "String")
    public String getOrderId() {
        return orderId;
    }

    /**
     * Set the order Id for the call.
     * 
     * @param orderId the order Id that has been retrieved
     */
    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    /**
     * Retrieves the confirmation status from the order.
     * 
     * @return the confirmation status
     */
    @ApiModelProperty(value = "Flag to validate if the order is confirmed/paid.", example = "false", dataType = "Boolean")
    public Boolean getIsConfirmed() {
        return isConfirmed;
    }

    /**
     * Set the confirmation status for the order.
     * 
     * @param isConfirmed flag for the confirmation status
     */
    public void setIsConfirmed(Boolean isConfirmed) {
        this.isConfirmed = isConfirmed;
    }

    /**
     * Retrieves the close status from the order.
     * 
     * @return the close status
     */
    @ApiModelProperty(value = "Flag to validate if the order is deleted/closed.", example = "false", dataType = "Boolean")
    public Boolean getIsClosed() {
        return isClosed;
    }

    /**
     * Set the close status for the order.
     * 
     * @param isClosed flag for the close status
     */
    public void setIsClosed(Boolean isClosed) {
        this.isClosed = isClosed;
    }

    /**
     * Retrieves the suspended status from the order.
     * 
     * @return the suspended status
     */
    @ApiModelProperty(value = "Flag to validate if the order is suspended/expired.", example = "false", dataType = "Boolean")
    public Boolean getIsSuspended() {
        return isSuspended;
    }

    /**
     * Set the suspended status for the order.
     * 
     * @param isSuspended flag for the suspended status
     */
    public void setIsSuspended(Boolean isSuspended) {
        this.isSuspended = isSuspended;
    }

    /**
     * Retrieves the timeout for the order price.
     * 
     * @return the timeout for the order price
     */
    @ApiModelProperty(value = "The time in which the order is valid (Milliseconds).", example = "290000", dataType = "Integer")
    public Integer getTimeout() {
        return timeout;
    }

    /**
     * Set the timeout for the order price.
     * 
     * @param timeout the timeout for the order price
     */
    public void setTimeout(Integer timeout) {
        this.timeout = timeout;
    }
}
