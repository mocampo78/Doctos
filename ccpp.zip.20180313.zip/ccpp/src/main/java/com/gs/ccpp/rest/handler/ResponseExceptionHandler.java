package com.gs.ccpp.rest.handler;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.NoHandlerFoundException;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.gs.ccpp.core.util.ValidationUtil;
import com.gs.ccpp.rest.to.AppErrorTO;
import com.gs.ccpp.rest.to.ArgumentNotValidErrorTO;

/**
 * Handler for the runtime exceptions.
 * 
 * @author Emmanuel Salazar
 */
@ControllerAdvice
public class ResponseExceptionHandler extends ResponseEntityExceptionHandler {
    private static Logger log = LoggerFactory.getLogger(ResponseExceptionHandler.class);

    @ExceptionHandler(value = {ResourceAccessException.class})
    protected ResponseEntity<Object> handleResourceAccess(RuntimeException ex, WebRequest request) {
        log.error("Client resource access exception: [ {} ]", ex.getCause());
        AppErrorTO error = new AppErrorTO(HttpStatus.SERVICE_UNAVAILABLE, "Client resource access exception",
                        "There is an error communicating with the provider, please contact dev team for further information");

        return handleExceptionInternal(ex, error, new HttpHeaders(), HttpStatus.SERVICE_UNAVAILABLE, request);
    }

    @Override
    protected ResponseEntity<Object> handleHttpRequestMethodNotSupported(HttpRequestMethodNotSupportedException ex, HttpHeaders headers, HttpStatus status, WebRequest request) {
        log.error("Not supported method exception", ex);
        AppErrorTO error = new AppErrorTO(HttpStatus.METHOD_NOT_ALLOWED, "Method not allowed", "The requested method is not allowed, please verify the API definition");

        return handleExceptionInternal(ex, error, new HttpHeaders(), HttpStatus.METHOD_NOT_ALLOWED, request);
    }

    @Override
    protected ResponseEntity<Object> handleMethodArgumentNotValid(MethodArgumentNotValidException ex, HttpHeaders headers, HttpStatus status, WebRequest request) {
        log.error("Not valid argument exception", ex);

        ArgumentNotValidErrorTO error = new ArgumentNotValidErrorTO(HttpStatus.BAD_REQUEST, "Not valid arguments", "The arguments sent are not valid, please verify the API definition");
        error.setArgumentErrors(ValidationUtil.fromBindingErrors(ex.getBindingResult()));

        return handleExceptionInternal(ex, error, new HttpHeaders(), HttpStatus.BAD_REQUEST, request);
    }

    @Override
    protected ResponseEntity<Object> handleNoHandlerFoundException(NoHandlerFoundException ex, HttpHeaders headers, HttpStatus status, WebRequest request) {
        String detail = "No handler found for " + ex.getHttpMethod() + " " + ex.getRequestURL();

        log.error(detail, ex);
        AppErrorTO error = new AppErrorTO(HttpStatus.NOT_FOUND, "No handler defined", detail);

        return handleExceptionInternal(ex, error, new HttpHeaders(), HttpStatus.NOT_FOUND, request);
    }

    @ExceptionHandler(IllegalArgumentException.class)
    protected ResponseEntity<Object> handleIllegalArgumentException(IllegalArgumentException ex, WebRequest request) {
        log.error("Illegal argument exception", ex);
        AppErrorTO error = new AppErrorTO(HttpStatus.BAD_REQUEST, "Missing information in the request", "Please verify the API for required information");

        return handleExceptionInternal(ex, error, new HttpHeaders(), HttpStatus.BAD_REQUEST, request);
    }

    @ExceptionHandler(RuntimeException.class)
    protected ResponseEntity<Object> handleGlobalException(RuntimeException ex, WebRequest request) {
        log.error("Unhandled exception", ex);
        AppErrorTO error = new AppErrorTO(HttpStatus.INTERNAL_SERVER_ERROR, "Unhandled exception", "Please contact dev team for further information");

        return handleExceptionInternal(ex, error, new HttpHeaders(), HttpStatus.INTERNAL_SERVER_ERROR, request);
    }
}
