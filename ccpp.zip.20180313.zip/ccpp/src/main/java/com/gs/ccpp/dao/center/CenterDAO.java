package com.gs.ccpp.dao.center;

import java.net.ConnectException;
import java.sql.SQLException;
import java.util.ArrayList;

import com.gs.ccpp.dao.core.CcppDAO;
import com.gs.ccpp.dao.util.SqlParameter;
import com.gs.ccpp.dao.util.SqlParameter.SqlParameterType;
import com.gs.ccpp.dto.center.CenterUserDTO;

/**
 * Data Access Object for the center entity.
 * 
 * @author Emmanuel Salazar
 */
public class CenterDAO extends CcppDAO {
    private static final String GET_CENTER_USER_QUERY = "{call SP_SEL_CENTER_USER(?,?)}";

    /**
     * Validate that the center and user provided are active and retrieves the center's information.
     * 
     * @param centerId the center to be validated
     * @param userId the user to be validated
     * @return the center information
     */
    public CenterUserDTO getCenterUser(String centerId, String userId) {
        parameters = new ArrayList<>();
        parameters.add(new SqlParameter(SqlParameterType.INPUT_STRING, "PI_CENTER_OPERATION", centerId));
        parameters.add(new SqlParameter(SqlParameterType.INPUT_STRING, "PI_USER", userId));

        try {
            return (CenterUserDTO) executeForObject(GET_CENTER_USER_QUERY, parameters, CenterUserDTO.class);
        } catch (ConnectException | SQLException e) {
            throw new RuntimeException(e.getMessage());
        }
    }
}
