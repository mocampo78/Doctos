package com.gs.ccpp.dao.connection;

import java.net.ConnectException;
import java.sql.Connection;

/**
 * Interface to define the database connection factory.
 * 
 * @author Emmanuel Salazar
 */
public interface ConnectionFactory {
    /**
     * This method will retrieve the connection to access the database.
     * 
     * @return the database connection
     * @throws ConnectException when a database connection exception occurs
     */
    Connection createConnection() throws ConnectException;
}
