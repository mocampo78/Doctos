package com.gs.ccpp.dao.util;

import java.lang.reflect.Field;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.lang.ArrayUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.mapping.model.MappingException;

/**
 * Object mapper, using the annotations in the DTO's will map the information retrieved from a result set.
 * 
 * @author Emmanuel Salazar
 */
public class ObjectMapper<T> {
    private static Logger log = LoggerFactory.getLogger(ObjectMapper.class);

    /**
     * Save the information from the result set to a DTO.
     * 
     * @param outputClass the class to be used for the mapping process
     * @param resultSet the result set with the information from database
     * @return a list of objects of outputClass with the information retrieved from database
     */
    public List<T> loadObjectWithDBColumn(Class<T> outputClass, ResultSet resultSet) {
        List<T> outputList = new ArrayList<>();
        try {
            ResultSetMetaData rsmd = resultSet.getMetaData();
            Field[] fields = outputClass.getDeclaredFields();
            Field[] inheritedFields = outputClass.getSuperclass().getDeclaredFields();

            Field[] totalFields = (Field[]) ArrayUtils.addAll(fields, inheritedFields);

            if (rsmd.getColumnCount() == 1) {
                String columnName = rsmd.getColumnName(1);

                if (columnName.equals("err_message")) {
                    return null;
                }
            }

            while (resultSet.next()) {
                T bean = (T) outputClass.newInstance();
                for (int i = 0; i < rsmd.getColumnCount(); i++) {
                    String columnName = rsmd.getColumnName(i + 1);
                    Object columnValue = resultSet.getObject(i + 1);

                    for (Field field : totalFields) {
                        if (field.isAnnotationPresent(Column.class)) {
                            Column column = field.getAnnotation(Column.class);
                            if (column.name().equalsIgnoreCase(columnName) && columnValue != null) {
                                BeanUtils.setProperty(bean, field.getName(), columnValue);
                                break;
                            }
                        }
                    }
                }
                outputList.add(bean);
            }
        } catch (Exception e) {
            log.error("An error occurs parsing the resultset to an object", e);
            throw new MappingException(e.getMessage());
        }

        return outputList;
    }
}
