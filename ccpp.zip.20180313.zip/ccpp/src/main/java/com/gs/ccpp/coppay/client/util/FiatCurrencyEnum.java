package com.gs.ccpp.coppay.client.util;

/**
 * Enum with the fiat currencies available in CopPay.
 * 
 * @author Emmanuel Salazar
 */
public enum FiatCurrencyEnum {
    EUR("EUR"), USD("USD"), MXN("MXN"), BYN("BYN"), RUB("RUB");

    private String value;

    /**
     * Instantiate the enum with a valid value for CopPay's fiatcurrency catalog.
     * 
     * @param value the fiatcurrency item to be used
     */
    FiatCurrencyEnum(String value) {
        this.value = value;
    }

    /**
     * The value defined by CopPay for the fiatcurrency catalog.
     * 
     * @return the catalog value to be used in the call
     */
    public String getValue() {
        return value;
    }

}
