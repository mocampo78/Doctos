package com.gs.ccpp.coppay.client.to.order;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * The response information from CopPay to the check order call.
 * 
 * @author Emmanuel Salazar
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class CheckOrderClientResponse {

    private String orderId;
    private Boolean isConfirmed;
    private Boolean isClosed;
    private Boolean isSuspended;
    private Integer timeout;

    @Override
    public String toString() {
        return "CheckOrderTO [orderId=" + orderId + ", isConfirmed=" + isConfirmed + ", isClosed=" + isClosed + ", isSuspended=" + isSuspended + ", timeout=" + timeout + "]";
    }

    /**
     * Obtain the order Id from the call.
     * 
     * @return the order Id
     */
    public String getOrderId() {
        return orderId;
    }

    /**
     * Set the order Id for the call.
     * 
     * @param orderId the order Id that has been retrieved
     */
    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    /**
     * Retrieves the confirmation status from the order.
     * 
     * @return the confirmation status
     */
    public Boolean getIsConfirmed() {
        return isConfirmed;
    }

    /**
     * Set the confirmation status for the order.
     * 
     * @param isConfirmed flag for the confirmation status
     */
    public void setIsConfirmed(Boolean isConfirmed) {
        this.isConfirmed = isConfirmed;
    }

    /**
     * Retrieves the close status from the order.
     * 
     * @return the close status
     */
    public Boolean getIsClosed() {
        return isClosed;
    }

    /**
     * Set the close status for the order.
     * 
     * @param isClosed flag for the close status
     */
    public void setIsClosed(Boolean isClosed) {
        this.isClosed = isClosed;
    }

    /**
     * Retrieves the suspended status from the order.
     * 
     * @return the suspended status
     */
    public Boolean getIsSuspended() {
        return isSuspended;
    }

    /**
     * Set the suspended status for the order.
     * 
     * @param isSuspended flag for the suspended status
     */
    public void setIsSuspended(Boolean isSuspended) {
        this.isSuspended = isSuspended;
    }

    /**
     * Retrieves the timeout for the order price.
     * 
     * @return the timeout for the order price
     */
    public Integer getTimeout() {
        return timeout;
    }

    /**
     * Set the timeout for the order price.
     * 
     * @param timeout the timeout for the order price
     */
    public void setTimeout(Integer timeout) {
        this.timeout = timeout;
    }
}
