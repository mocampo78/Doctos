package com.gs.ccpp.coppay.client.to.order;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * The response information from CopPay to the create order call..
 * 
 * @author Emmanuel Salazar
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class AddOrderClientResponse {

    private String orderId;
    private String qrText;
    private String cryptoPrice;
    private Integer timeout;
    private String address;

    @Override
    public String toString() {
        return "AddOrderTO [orderId=" + orderId + ", qrText=" + qrText + ", cryptoPrice=" + cryptoPrice + ", timeout=" + timeout + ", address=" + address + "]";
    }

    /**
     * Obtain the order Id created in the call.
     * 
     * @return retrive the order Id
     */
    public String getOrderId() {
        return orderId;
    }

    /**
     * Set the order Id created in the add order call.
     * 
     * @param orderId the order Id created
     */
    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    /**
     * Retrieve the text that must be used to generate the QR code that will be used for payment.
     * 
     * @return the text to be included in the QR code
     */
    public String getQrText() {
        return qrText;
    }

    /**
     * Set the text that will be used to generate the QR code.
     * 
     * @param qrText the text for the QR code
     */
    public void setQrText(String qrText) {
        this.qrText = qrText;
    }

    /**
     * The crypto price calculated from the request information.
     * 
     * @return The crypto price required for the transaction
     */
    public String getCryptoPrice() {
        return cryptoPrice;
    }

    /**
     * Set the crypto amount required for the transaction.
     * 
     * @param cryptoPrice The crypto amount required
     */
    public void setCryptoPrice(String cryptoPrice) {
        this.cryptoPrice = cryptoPrice;
    }

    /**
     * Get the time in which the crypto price provided is valid.
     * 
     * @return The timeout value for the price provided
     */
    public Integer getTimeout() {
        return timeout;
    }

    /**
     * Set the time in which the crypto price will expire.
     * 
     * @param timeout the timeout value to be used
     */
    public void setTimeout(Integer timeout) {
        this.timeout = timeout;
    }

    /**
     * Get the address in which the payment is required.
     * 
     * @return the address to perform the payment
     */
    public String getAddress() {
        return address;
    }

    /**
     * Set the address in which the payment should be made.
     * 
     * @param address the address to receive the payment
     */
    public void setAddress(String address) {
        this.address = address;
    }
}
