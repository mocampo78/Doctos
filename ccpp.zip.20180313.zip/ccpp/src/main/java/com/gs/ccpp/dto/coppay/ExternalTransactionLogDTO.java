package com.gs.ccpp.dto.coppay;

import com.gs.ccpp.dto.CoreDTO;

/**
 * DTO to be used to retrieve external transaction log information from database.
 * 
 * @author Emmanuel Salazar
 */
public class ExternalTransactionLogDTO extends CoreDTO {

    public Long externalTransactionID;
    public Short providerId;
    public Short providerOperationId;
    public Short externalTransactionStatus;
    public String requestData;
    public String responseData;
    public Integer responseTime;

    @Override
    public String toString() {
        return "ExternalTransactionLogDTO [externalTransactionID=" + externalTransactionID + ", providerId=" + providerId + ", providerOperationId=" + providerOperationId
                        + ", externalTransactionStatus=" + externalTransactionStatus + ", requestData=" + requestData + ", responseData=" + responseData + ",responseTime" + responseTime
                        + ", transactionId=" + transactionId + ", user=" + user + ", ipAddress=" + ipAddress + ", centerOperation=" + centerOperation + "]";
    }

    public Long getExternalTransactionID() {
        return externalTransactionID;
    }

    public void setExternalTransactionID(Long externalTransactionID) {
        this.externalTransactionID = externalTransactionID;
    }

    public Short getProviderId() {
        return providerId;
    }

    public void setProviderId(Short providerId) {
        this.providerId = providerId;
    }

    public Short getProviderOperationId() {
        return providerOperationId;
    }

    public void setProviderOperationId(Short providerOperationId) {
        this.providerOperationId = providerOperationId;
    }

    public Short getExternalTransactionStatus() {
        return externalTransactionStatus;
    }

    public void setExternalTransactionStatus(Short externalTransactionStatus) {
        this.externalTransactionStatus = externalTransactionStatus;
    }

    public String getRequestData() {
        return requestData;
    }

    public void setRequestData(String requestData) {
        this.requestData = requestData;
    }

    public String getResponseData() {
        return responseData;
    }

    public void setResponseData(String responseData) {
        this.responseData = responseData;
    }

    public Integer getResponseTime() {
        return responseTime;
    }

    public void setResponseTime(Integer responseTime) {
        this.responseTime = responseTime;
    }
}
