package com.gs.ccpp.coppay.client.to;

/**
 * Transfer object for error messages from the provider.
 * 
 * @author esalazard
 */
public class ClientErrorResponse {
    private String message;

    /**
     * The constructor of the class.
     * 
     * @param message the error message
     */
    public ClientErrorResponse(String message) {
        super();
        this.message = message;
    }

    @Override
    public String toString() {
        return "ErrorResponse [message=" + message + "]";
    }

    /**
     * Get the error message.
     * 
     * @return error message
     */
    public String getMessage() {
        return message;
    }

    /**
     * Set the error message.
     * 
     * @param message the message to be saved
     */
    public void setMessage(String message) {
        this.message = message;
    }


}
