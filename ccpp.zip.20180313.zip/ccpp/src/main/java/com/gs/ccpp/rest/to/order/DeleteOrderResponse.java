package com.gs.ccpp.rest.to.order;

import io.swagger.annotations.ApiModelProperty;

/**
 * Transfer Object for the response of the delete order call.
 * 
 * @author Emmanuel Salazar
 */
public class DeleteOrderResponse {
    private String orderId;
    private Boolean isDeleteSuccessful;
    private String message;

    @Override
    public String toString() {
        return "DeleteOrderClientResponse [orderId=" + orderId + ", isDeleteSuccessful=" + isDeleteSuccessful + ", message=" + message + "]";
    }

    /**
     * Obtain the order Id from the call.
     * 
     * @return the order ID
     */
    @ApiModelProperty(value = "Echo of the requested order's identifier.", example = "14a7e4c8-d50f-40df-a1d3-4e053c7357a1", dataType = "String")
    public String getOrderId() {
        return orderId;
    }

    /**
     * Set the order Id for the call.
     * 
     * @param orderId the order Id sent to be deleted
     */
    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    /**
     * Obtain a flag to validate if the delete process was successful.
     * 
     * @return flag for delete success status
     */
    @ApiModelProperty(value = "Flag to confirm if the delete process was successful.", example = "true", dataType = "Boolean")
    public Boolean getIsDeleteSuccessful() {
        return isDeleteSuccessful;
    }

    /**
     * Set the flag about the delete process.
     * 
     * @param isDeleteSuccessful if the delete process was successful
     */
    public void setIsDeleteSuccessful(Boolean isDeleteSuccessful) {
        this.isDeleteSuccessful = isDeleteSuccessful;
    }

    /**
     * Retrieve the message from the delete process performed by CopPay.
     * 
     * @return the message received from CopPay
     */
    @ApiModelProperty(value = "Output message of the order's delete process.", example = "OK", dataType = "String")
    public String getMessage() {
        return message;
    }

    /**
     * Get the message from the delete process performed by CopPay.
     * 
     * @param message the message from CopPay's process
     */
    public void setMessage(String message) {
        this.message = message;
    }
}
