package com.gs.ccpp.rest.controller;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.gs.ccpp.core.bll.OrderManagement;
import com.gs.ccpp.rest.doc.OrderAPI;
import com.gs.ccpp.rest.to.AppErrorTO;
import com.gs.ccpp.rest.to.ArgumentNotValidErrorTO;
import com.gs.ccpp.rest.to.order.AddOrderRequest;
import com.gs.ccpp.rest.to.order.AddOrderResponse;
import com.gs.ccpp.rest.to.order.CheckOrderResponse;
import com.gs.ccpp.rest.to.order.DeleteOrderResponse;
import com.gs.ccpp.rest.to.order.RefreshOrderResponse;

import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

/**
 * Controller class for the order entity. This class will expose the Delete-Get-Post-Put methods as Restful API.
 * 
 * @author Emmanuel Salazar
 */
@RestController
public class OrderController {
    /**
     * Post end-point to create orders.
     * 
     * @param request the required information to create an order
     * @return the order's information created by the provider
     */
    @PostMapping(path = "/ccpp/order/", consumes = "application/json", produces = "application/json")
    @ApiOperation(value = OrderAPI.POST_TITLE, notes = OrderAPI.POST_NOTES)
    @ApiImplicitParams({@ApiImplicitParam(name = "x-gs-center-id", value = "Unique identifier for the center performing the call", dataType = "String", paramType = "header")})
    @ApiResponses(value = {@ApiResponse(code = 201, message = "Order created", response = AddOrderResponse.class),
                    @ApiResponse(code = 400, message = "Bad request", response = ArgumentNotValidErrorTO.class), @ApiResponse(code = 401, message = "Unauthorized access", response = AppErrorTO.class),
                    @ApiResponse(code = 500, message = "Unhandled exception", response = AppErrorTO.class), @ApiResponse(code = 503, message = "Provider unavailable", response = AppErrorTO.class)})
    @ResponseStatus(value = HttpStatus.CREATED)
    public ResponseEntity<AddOrderResponse> addOrder(@ApiParam(value = "The information required to create the order.", required = true) @Valid @RequestBody AddOrderRequest request,
                    HttpServletRequest httpRequest) {
        AddOrderResponse response = new OrderManagement(httpRequest).addOrder(request);
        return new ResponseEntity<>(response, HttpStatus.CREATED);
    }

    /**
     * Get end-point to retrieve information of an order.
     *
     * @param orderId the id of the order to be retrieved
     * @return the order's information
     */
    @GetMapping(path = "/ccpp/order/{orderId}", produces = "application/json")
    @ApiOperation(value = OrderAPI.GET_TITLE, notes = OrderAPI.GET_NOTES)
    @ApiImplicitParams({@ApiImplicitParam(name = "x-gs-center-id", value = "Unique identifier for the center performing the call", dataType = "String", paramType = "header")})
    @ApiResponses(value = {@ApiResponse(code = 200, message = "Successful", response = CheckOrderResponse.class),
                    @ApiResponse(code = 401, message = "Unauthorized access", response = AppErrorTO.class), @ApiResponse(code = 500, message = "Unhandled exception", response = AppErrorTO.class),
                    @ApiResponse(code = 503, message = "Provider unavailable", response = AppErrorTO.class)})
    @ResponseStatus(value = HttpStatus.OK)
    public ResponseEntity<CheckOrderResponse> checkOrder(@ApiParam(value = "The requested order Id.", required = true) @PathVariable(value = "orderId") String orderId,
                    HttpServletRequest httpRequest) {
        CheckOrderResponse response = new OrderManagement(httpRequest).checkOrder(orderId);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    /**
     * Delete end-point to close an order.
     * 
     * @param orderId the id of the order to be deleted/closed
     * @return information about the delete process
     */
    @DeleteMapping(path = "/ccpp/order/{orderId}", produces = "application/json")
    @ApiOperation(value = OrderAPI.DELETE_TITLE, notes = OrderAPI.DELETE_NOTES)
    @ApiImplicitParams({@ApiImplicitParam(name = "x-gs-center-id", value = "Unique identifier for the center performing the call", dataType = "String", paramType = "header")})
    @ApiResponses(value = {@ApiResponse(code = 200, message = "Successful", response = DeleteOrderResponse.class),
                    @ApiResponse(code = 401, message = "Unauthorized access", response = AppErrorTO.class), @ApiResponse(code = 500, message = "Unhandled exception", response = AppErrorTO.class),
                    @ApiResponse(code = 503, message = "Provider unavailable", response = AppErrorTO.class)})
    @ResponseStatus(value = HttpStatus.OK)
    public ResponseEntity<DeleteOrderResponse> deleteOrder(@ApiParam(value = "The Id of the order to be deleted.", required = true) @PathVariable(value = "orderId") String orderId,
                    HttpServletRequest httpRequest) {
        DeleteOrderResponse response = new OrderManagement(httpRequest).deleteOrder(orderId);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    /**
     * Put end-point to refresh an order.
     * 
     * @param orderId the id of the order to be refreshed
     * @return the updated order's information
     */
    @PutMapping(path = "/ccpp/order/{orderId}", produces = "application/json")
    @ApiOperation(value = OrderAPI.PUT_TITLE, notes = OrderAPI.PUT_NOTES)
    @ApiImplicitParams({@ApiImplicitParam(name = "x-gs-center-id", value = "Unique identifier for the center performing the call", dataType = "String", paramType = "header")})
    @ApiResponses(value = {@ApiResponse(code = 200, message = "Successful", response = RefreshOrderResponse.class),
                    @ApiResponse(code = 401, message = "Unauthorized access", response = AppErrorTO.class), @ApiResponse(code = 500, message = "Unhandled exception", response = AppErrorTO.class),
                    @ApiResponse(code = 503, message = "Provider unavailable", response = AppErrorTO.class)})
    @ResponseStatus(value = HttpStatus.OK)
    public ResponseEntity<RefreshOrderResponse> refreshOrder(@ApiParam(value = "The Id of the order to be refreshed.", required = true) @PathVariable(value = "orderId") String orderId,
                    HttpServletRequest httpRequest) {
        RefreshOrderResponse response = new OrderManagement(httpRequest).refreshOrder(orderId);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }
}
