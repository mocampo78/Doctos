package com.gs.ccpp.rest.handler;

import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.stereotype.Component;

import com.gs.ccpp.coppay.client.util.CopPayOperUtil;
import com.gs.ccpp.dao.connection.ProdConnectionFactory;
import com.gs.ccpp.dao.coppay.CopPayDAO;

/**
 * Handler to initiate the spring's DataSource in production environment.
 * 
 * @author Emmanuel Salazar
 */
@Component
public class DatasourceInitHandler implements ApplicationListener<ContextRefreshedEvent> {
    private static Logger log = LoggerFactory.getLogger(DatasourceInitHandler.class);

    @Autowired
    DataSource dataSource;

    /**
     * This method will get the Spring's DataSource to be used in the application. It will also retrieve the information about the CopPay's operations.
     */
    @Override
    public void onApplicationEvent(ContextRefreshedEvent event) {
        log.info("DatasourceInitHandler: {}", dataSource);
        ProdConnectionFactory factory = ProdConnectionFactory.getInstance();
        factory.setDataSource(dataSource);

        CopPayOperUtil.getInstance().setCopPayMap(new CopPayDAO().getCopPayData(CopPayDAO.COPPAY_PROVIDER));
    }
}
