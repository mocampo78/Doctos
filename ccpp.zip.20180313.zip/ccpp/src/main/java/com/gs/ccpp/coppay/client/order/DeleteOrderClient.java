package com.gs.ccpp.coppay.client.order;

import org.slf4j.LoggerFactory;

import com.gs.ccpp.coppay.client.CopPayClient;
import com.gs.ccpp.coppay.client.to.order.DeleteOrderClientRequest;
import com.gs.ccpp.coppay.client.to.order.DeleteOrderClientResponse;
import com.gs.ccpp.coppay.client.util.CopPayOperUtil;
import com.gs.ccpp.rest.vo.RequestDataVO;

/**
 * Client for CopPay's web service to delete/close an order.
 * 
 * @author Emmanuel Salazar
 */
public class DeleteOrderClient extends CopPayClient {
    public static final Short DELETE_OPER = 3;

    private DeleteOrderClientRequest request;
    private DeleteOrderClientResponse response;

    /**
     * The constructor for the delete order client.
     * 
     * @param requestDataVO the information of the caller for the request
     */
    public DeleteOrderClient(RequestDataVO requestDataVO) {
        super(requestDataVO);

        log = LoggerFactory.getLogger(DeleteOrderClient.class);
        url = CopPayOperUtil.getInstance().getCopPayMap().get(DELETE_OPER).getEndpoint();
    }

    /**
     * Execute the delete order web service from CopPay.
     * 
     * @param orderId the order id to be deleted/closed
     * @return the information about the delete process
     */
    public DeleteOrderClientResponse deleteOrder(String orderId) {
        log.info("Request receive to delete order: {}", orderId);

        request = new DeleteOrderClientRequest(requestDataVO.getApiKey(), orderId);
        responseEntity = execute(DELETE_OPER, request);

        response = new DeleteOrderClientResponse();
        response.setOrderId(orderId);

        // CopPay's response when successful delete is null
        if (null == responseEntity.getBody()) {
            response.setIsDeleteSuccessful(true);
            response.setMessage("OK");
            // If the order is already closed or it does not exists
        } else if (responseEntity.getBody().contains("order not found")) {
            response.setIsDeleteSuccessful(false);
            response.setMessage("Order not found");
        } else {
            response.setIsDeleteSuccessful(false);
            response.setMessage(responseEntity.getBody());
        }

        saveClientLog(response, response.getIsDeleteSuccessful());
        log.info("Delete order request processed with response: {}", response.toString());
        return response;
    }
}
