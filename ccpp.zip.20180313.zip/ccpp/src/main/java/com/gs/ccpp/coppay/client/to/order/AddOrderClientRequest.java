package com.gs.ccpp.coppay.client.to.order;

import com.gs.ccpp.coppay.client.to.CopPayRequest;

/**
 * Request to create an order in CopPay.
 * 
 * @author Emmanuel Salazar
 */
public class AddOrderClientRequest extends CopPayRequest {

    private String baseCurrencyName;
    private String baseCurrencyPrice;
    private String cryptoCurrencyName;
    private String description;

    public AddOrderClientRequest(String apiKey) {
        super(apiKey);
    }

    @Override
    public String toString() {
        return "AddOrderClientRequest [baseCurrencyName=" + baseCurrencyName + ", baseCurrencyPrice=" + baseCurrencyPrice + ", cryptoCurrencyName=" + cryptoCurrencyName + ", description="
                        + description + ", apiKey=" + apiKey + "]";
    }

    /**
     * Obtain the fiat currency used as base for the order.
     * 
     * @return the fiat currency
     */
    public String getBaseCurrencyName() {
        return baseCurrencyName;
    }

    /**
     * Set the fiat currency for the order.
     * 
     * @param baseCurrencyName the fiat currency to be used for the order
     */
    public void setBaseCurrencyName(String baseCurrencyName) {
        this.baseCurrencyName = baseCurrencyName;
    }

    /**
     * Obtain the fiat currency amount.
     * 
     * @return the fiat currency amount
     */
    public String getBaseCurrencyPrice() {
        return baseCurrencyPrice;
    }

    /**
     * Set the fiat currency amount.
     * 
     * @param baseCurrencyPrice the fiat currency amount
     */
    public void setBaseCurrencyPrice(String baseCurrencyPrice) {
        this.baseCurrencyPrice = baseCurrencyPrice;
    }

    /**
     * Obtain the crypto currency that will be used in the order.
     * 
     * @return the crypto currency
     */
    public String getCryptoCurrencyName() {
        return cryptoCurrencyName;
    }

    /**
     * Set the crypto currency for the order.
     * 
     * @param cryptoCurrencyName the crypto currency
     */
    public void setCryptoCurrencyName(String cryptoCurrencyName) {
        this.cryptoCurrencyName = cryptoCurrencyName;
    }

    /**
     * Obtain the order's description.
     * 
     * @return the order's description
     */
    public String getDescription() {
        return description;
    }

    /**
     * Set the order's description.
     * 
     * @param description the order's description
     */
    public void setDescription(String description) {
        this.description = description;
    }
}
