package com.gs.ccpp.coppay.client.util;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import org.junit.Test;
import org.springframework.http.HttpEntity;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;

import com.gs.ccpp.rest.to.order.AddOrderRequest;

public class CopPayClientUtilTest {

	@Test
	public void getRequestFactory() {
		HttpComponentsClientHttpRequestFactory requestFactory = CopPayClientUtil.getRequestFactory(300000);
		assertNotNull(requestFactory);
	}
	
	@Test
	public void getHttpEntity() {
		AddOrderRequest request = new AddOrderRequest();
		request.setAmount(100.0);
		request.setFiatCurrency("MXN");
		request.setCryptoCurrency("ethereum");
		request.setDescription("AddOrderClientTest");
		
		HttpEntity<String> httpEntity = CopPayClientUtil.getHttpEntity(request);
		assertNotNull(httpEntity);
		assertEquals("{\"amount\":100.0,\"fiatCurrency\":\"MXN\",\"cryptoCurrency\":\"ethereum\",\"description\":\"AddOrderClientTest\"}", httpEntity.getBody());
		assertEquals("application/json", httpEntity.getHeaders().get("Content-Type").get(0));
	}
}
