package com.gs.ccpp.dao.coppay;

import static org.junit.Assert.assertNotNull;

import java.util.Map;

import org.junit.Test;

import com.gs.ccpp.dto.coppay.CopPayDataDTO;

public class CopPayDAOTest {

	@Test
	public void getCopPayData() {
		CopPayDAO copPayDAO = new CopPayDAO();
		Map<Short, CopPayDataDTO> resultMap = copPayDAO.getCopPayData(CopPayDAO.COPPAY_PROVIDER);
		
		assertNotNull(resultMap);
	}
}
