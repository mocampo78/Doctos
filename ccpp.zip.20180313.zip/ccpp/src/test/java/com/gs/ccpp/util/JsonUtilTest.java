package com.gs.ccpp.util;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import org.junit.Test;

import com.gs.ccpp.core.util.JsonUtil;
import com.gs.ccpp.rest.to.order.AddOrderRequest;

public class JsonUtilTest {
	
	@Test
	public void getJsonStringTest() {
		// Valid object transformation
		AddOrderRequest request = new AddOrderRequest();
		request.setAmount(100.0);
		request.setFiatCurrency("MXN");
		request.setCryptoCurrency("ethereum");
		request.setDescription("AddOrderClientTest");
	
		String jsonStr = JsonUtil.getJsonString(request);
		assertNotNull(jsonStr);
		assertEquals("{\"amount\":100.0,\"fiatCurrency\":\"MXN\",\"cryptoCurrency\":\"ethereum\",\"description\":\"AddOrderClientTest\"}", jsonStr);

		// Null object
		jsonStr = JsonUtil.getJsonString(null);
		assertEquals("null", jsonStr);
	}
}
