package com.gs.ccpp.dao.coppay;

import org.junit.Test;

import com.gs.ccpp.dto.coppay.ExternalTransactionLogDTO;

public class ExternalTransactionLogDAOTest {

	@Test
	public void addExternalTransactionLogTest() {
		ExternalTransactionLogDTO request = new ExternalTransactionLogDTO();
		request.setTransactionId("123");
		request.setProviderId((short) 1);
		request.setProviderOperationId((short) 1);
		request.setExternalTransactionStatus((short) 1);
		request.setRequestData("ajsdfkajsoiuqwperjlkajsdfñkljasd");
		request.setResponseData("A");
		request.setResponseTime(200);
		request.setUser("ccppUser");
		request.setIpAddress("127.0.0.2");
		request.setCenterOperation("TestCenter");

		ExternalTransactionLogDAO externalTransactionLogDAO = new ExternalTransactionLogDAO();
		externalTransactionLogDAO.addExternalTransactionLog(request);
	}
}