package com.gs.ccpp.coppay.client;

import static org.junit.Assert.assertNotNull;

import org.junit.Test;

import com.gs.ccpp.coppay.client.order.CheckOrderClient;
import com.gs.ccpp.coppay.client.to.order.CheckOrderClientResponse;
import com.gs.ccpp.coppay.client.util.CopPayOperUtil;
import com.gs.ccpp.dao.coppay.CopPayDAO;
import com.gs.ccpp.rest.vo.RequestDataVO;

public class CheckOrderClientTest {

	@Test
	public void checkOrder() {
		CopPayOperUtil.getInstance().setCopPayMap(new CopPayDAO().getCopPayData(CopPayDAO.COPPAY_PROVIDER));
		
		RequestDataVO requestDataVO = new RequestDataVO();
		requestDataVO.setTransactionId("testTransaction");
		requestDataVO.setIpAddress("127.0.0.28");
		requestDataVO.setCenterId("testCenter");
		requestDataVO.setUserId("testUser");
		requestDataVO.setApiKey("e3f9c16SSc321wweWWa3e8951*!!99b76ab50917Dw7b850a2d+5cae149WeqwG054e54fccfaK");
		
		String orderId = "ffd43952-78d7-4bac-b00f-8d9bfff16311";
		
		CheckOrderClientResponse checkOrderTo = new CheckOrderClient(requestDataVO).checkOrder(orderId);
		assertNotNull(checkOrderTo);
	}
}