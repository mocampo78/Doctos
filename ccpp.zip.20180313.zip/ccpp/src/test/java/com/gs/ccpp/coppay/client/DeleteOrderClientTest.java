package com.gs.ccpp.coppay.client;

import static org.junit.Assert.assertNotNull;

import org.junit.Test;

import com.gs.ccpp.coppay.client.order.DeleteOrderClient;
import com.gs.ccpp.coppay.client.to.order.DeleteOrderClientResponse;
import com.gs.ccpp.coppay.client.util.CopPayOperUtil;
import com.gs.ccpp.dao.coppay.CopPayDAO;
import com.gs.ccpp.rest.vo.RequestDataVO;

public class DeleteOrderClientTest {

	@Test
	public void deleteOrder() {
		CopPayOperUtil.getInstance().setCopPayMap(new CopPayDAO().getCopPayData(CopPayDAO.COPPAY_PROVIDER));
		
		RequestDataVO requestDataVO = new RequestDataVO();
		requestDataVO.setTransactionId("testTransaction");
		requestDataVO.setIpAddress("127.0.0.28");
		requestDataVO.setCenterId("testCenter");
		requestDataVO.setUserId("testUser");
		requestDataVO.setApiKey("e3f9c16SSc321wweWWa3e8951*!!99b76ab50917Dw7b850a2d+5cae149WeqwG054e54fccfaK");
		
		String orderId = "0017ae35-6f9d-4f6f-be7f-5a2959888c49";
		
		DeleteOrderClientResponse deleteOrderTO = new DeleteOrderClient(requestDataVO).deleteOrder(orderId);
		assertNotNull(deleteOrderTO);
	}
}
