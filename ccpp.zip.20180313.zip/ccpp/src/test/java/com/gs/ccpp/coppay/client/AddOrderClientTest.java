package com.gs.ccpp.coppay.client;

import static org.junit.Assert.assertNotNull;

import org.junit.Test;

import com.gs.ccpp.coppay.client.order.AddOrderClient;
import com.gs.ccpp.coppay.client.to.order.AddOrderClientRequest;
import com.gs.ccpp.coppay.client.to.order.AddOrderClientResponse;
import com.gs.ccpp.coppay.client.util.CopPayOperUtil;
import com.gs.ccpp.coppay.client.util.CryptoCurrencyEnum;
import com.gs.ccpp.coppay.client.util.FiatCurrencyEnum;
import com.gs.ccpp.dao.coppay.CopPayDAO;
import com.gs.ccpp.rest.vo.RequestDataVO;

public class AddOrderClientTest {
	
	@Test
	public void addOrder() {
		CopPayOperUtil.getInstance().setCopPayMap(new CopPayDAO().getCopPayData(CopPayDAO.COPPAY_PROVIDER));
		
		RequestDataVO requestDataVO = new RequestDataVO();
		requestDataVO.setTransactionId("testTransaction");
		requestDataVO.setIpAddress("127.0.0.28");
		requestDataVO.setCenterId("testCenter");
		requestDataVO.setUserId("testUser");
		requestDataVO.setApiKey("e3f9c16SSc321wweWWa3e8951*!!99b76ab50917Dw7b850a2d+5cae149WeqwG054e54fccfaK");
		
		AddOrderClientRequest addOrderClientRequest = new AddOrderClientRequest(requestDataVO.getApiKey());
		
		addOrderClientRequest.setBaseCurrencyPrice("100.0");
		addOrderClientRequest.setBaseCurrencyName(FiatCurrencyEnum.MXN.getValue());
		addOrderClientRequest.setCryptoCurrencyName(CryptoCurrencyEnum.ethereum.getValue());
		addOrderClientRequest.setDescription("AddOrderClientTest");
		
		AddOrderClientResponse addOrderTO = new AddOrderClient(requestDataVO).addOrder(addOrderClientRequest);
		assertNotNull(addOrderTO);
	}
}
