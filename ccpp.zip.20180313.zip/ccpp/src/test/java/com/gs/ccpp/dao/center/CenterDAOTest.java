package com.gs.ccpp.dao.center;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import org.junit.Test;

import com.gs.ccpp.dto.center.CenterUserDTO;

public class CenterDAOTest {

	@Test
	public void getCenterUser() {
		CenterDAO centerDAO = new CenterDAO();
		CenterUserDTO centerDTO = centerDAO.getCenterUser("ekt", "ektuser");
		
		assertNotNull(centerDTO);
		assertEquals("e3f9c16SSc321wweWWa3e8951*!!99b76ab50917Dw7b850a2d+5cae149WeqwG054e54fccfaK", centerDTO.getApiKey());
		System.out.println(centerDTO);
	}
}
