package com.gs.ccpp.coppay.client;

import static org.junit.Assert.assertNotNull;

import org.junit.Test;

import com.gs.ccpp.coppay.client.order.RefreshOrderClient;
import com.gs.ccpp.coppay.client.to.order.RefreshOrderClientResponse;
import com.gs.ccpp.coppay.client.util.CopPayOperUtil;
import com.gs.ccpp.dao.coppay.CopPayDAO;
import com.gs.ccpp.rest.vo.RequestDataVO;

public class RefreshOrderClientTest {

	@Test
	public void refreshOrder() {
		CopPayOperUtil.getInstance().setCopPayMap(new CopPayDAO().getCopPayData(CopPayDAO.COPPAY_PROVIDER));
		
		RequestDataVO requestDataVO = new RequestDataVO();
		requestDataVO.setTransactionId("testTransaction");
		requestDataVO.setIpAddress("127.0.0.28");
		requestDataVO.setCenterId("testCenter");
		requestDataVO.setUserId("testUser");
		requestDataVO.setApiKey("e3f9c16SSc321wweWWa3e8951*!!99b76ab50917Dw7b850a2d+5cae149WeqwG054e54fccfaK");
		
		String orderId = "78ccea58-a763-4490-b85c-b759a6da9e0f";
		
		RefreshOrderClientResponse refreshOrderTO = new RefreshOrderClient(requestDataVO).refreshOrder(orderId);
		assertNotNull(refreshOrderTO);
	}
}
