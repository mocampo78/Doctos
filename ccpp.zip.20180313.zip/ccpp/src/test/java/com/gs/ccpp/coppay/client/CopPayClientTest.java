package com.gs.ccpp.coppay.client;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

import com.gs.ccpp.coppay.client.order.AddOrderClient;
import com.gs.ccpp.coppay.client.order.CheckOrderClient;
import com.gs.ccpp.coppay.client.order.DeleteOrderClient;
import com.gs.ccpp.coppay.client.order.RefreshOrderClient;
import com.gs.ccpp.coppay.client.to.order.AddOrderClientRequest;
import com.gs.ccpp.coppay.client.to.order.AddOrderClientResponse;
import com.gs.ccpp.coppay.client.to.order.CheckOrderClientResponse;
import com.gs.ccpp.coppay.client.to.order.DeleteOrderClientResponse;
import com.gs.ccpp.coppay.client.to.order.RefreshOrderClientResponse;
import com.gs.ccpp.coppay.client.util.CopPayOperUtil;
import com.gs.ccpp.coppay.client.util.CryptoCurrencyEnum;
import com.gs.ccpp.coppay.client.util.FiatCurrencyEnum;
import com.gs.ccpp.dao.coppay.CopPayDAO;
import com.gs.ccpp.rest.vo.RequestDataVO;

public class CopPayClientTest {

	@Test
	public void copPayFullTest() {
		CopPayOperUtil.getInstance().setCopPayMap(new CopPayDAO().getCopPayData(CopPayDAO.COPPAY_PROVIDER));
		
		RequestDataVO requestDataVO = new RequestDataVO();
		requestDataVO.setTransactionId("testTransaction");
		requestDataVO.setIpAddress("127.0.0.28");
		requestDataVO.setCenterId("testCenter");
		requestDataVO.setUserId("testUser");
		requestDataVO.setApiKey("e3f9c16SSc321wweWWa3e8951*!!99b76ab50917Dw7b850a2d+5cae149WeqwG054e54fccfaK");
		
		// 1 - Create an order
		AddOrderClientRequest addOrderClientRequest = new AddOrderClientRequest(requestDataVO.getApiKey());
		
		addOrderClientRequest.setBaseCurrencyPrice("100.0");
		addOrderClientRequest.setBaseCurrencyName(FiatCurrencyEnum.MXN.getValue());
		addOrderClientRequest.setCryptoCurrencyName(CryptoCurrencyEnum.ethereum.getValue());
		addOrderClientRequest.setDescription("AddOrderClientTest");
		
		AddOrderClientResponse addOrderResponse = new AddOrderClient(requestDataVO).addOrder(addOrderClientRequest);
		assertNotNull(addOrderResponse);
		assertTrue(addOrderResponse.getQrText().contains(addOrderResponse.getCryptoPrice()));
		
		// 2 - Check order
		CheckOrderClientResponse checkOrderTo = new CheckOrderClient(requestDataVO).checkOrder(addOrderResponse.getOrderId());
		assertNotNull(checkOrderTo);
		assertFalse(checkOrderTo.getIsConfirmed());
		assertFalse(checkOrderTo.getIsClosed());
		assertFalse(checkOrderTo.getIsSuspended());
		Integer timeout = checkOrderTo.getTimeout();
		
		// 3 - Refresh order
		RefreshOrderClientResponse refreshOrderTO = new RefreshOrderClient(requestDataVO).refreshOrder(addOrderResponse.getOrderId());
		assertNotNull(refreshOrderTO);
		assertFalse(checkOrderTo.getIsConfirmed());
		assertFalse(checkOrderTo.getIsClosed());
		assertFalse(checkOrderTo.getIsSuspended());
		assertTrue(refreshOrderTO.getTimeout() > timeout);
		
		// 4 - Delete order
		DeleteOrderClientResponse deleteOrderTO = new DeleteOrderClient(requestDataVO).deleteOrder(addOrderResponse.getOrderId());
		assertNotNull(deleteOrderTO);
		assertTrue(deleteOrderTO.getIsDeleteSuccessful());
		
		// 5 - Second delete, should be invalid
		deleteOrderTO = new DeleteOrderClient(requestDataVO).deleteOrder(addOrderResponse.getOrderId());
		assertNotNull(deleteOrderTO);
		assertFalse(deleteOrderTO.getIsDeleteSuccessful());
		
		// 6 - Check order again
		checkOrderTo = new CheckOrderClient(requestDataVO).checkOrder(addOrderResponse.getOrderId());
		assertNotNull(checkOrderTo);
		assertFalse(checkOrderTo.getIsConfirmed());
		assertTrue(checkOrderTo.getIsClosed());
		assertFalse(checkOrderTo.getIsSuspended());
	}
}
