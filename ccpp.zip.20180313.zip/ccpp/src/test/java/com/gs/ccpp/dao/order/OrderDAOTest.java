package com.gs.ccpp.dao.order;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import java.util.UUID;

import org.junit.Test;

import com.gs.ccpp.dto.order.OrderDTO;

public class OrderDAOTest {
	
	@Test
	public void addOrderTest() {
		OrderDTO orderDTO = new OrderDTO();
		orderDTO.setAddress("testAddress");
		orderDTO.setCenterOperation("testCenter");
		orderDTO.setCryptoCode("ETH");
		orderDTO.setCryptoPrice("0.0034523");
		orderDTO.setDescription("Test description");
		orderDTO.setFiatCode("MXN");
		orderDTO.setFiatPrice(100.0);
		orderDTO.setIpAddress("127.0.0.28");
		orderDTO.setOrderId(UUID.randomUUID().toString());
		orderDTO.setQrText("QR TEXT");
		orderDTO.setTimeout(300000);
		orderDTO.setTransactionId(UUID.randomUUID().toString());
		orderDTO.setUser("Test user");
		
		OrderDAO orderDAO = new OrderDAO();
		OrderDTO result = orderDAO.addOrder(orderDTO);

		assertNotNull(result);

		orderDTO = new OrderDTO();
		orderDTO.setOrderId(result.getOrderId());
		orderDTO.setTransactionId(UUID.randomUUID().toString());
		orderDTO.setCryptoPrice("0.0034523");
		orderDTO.setQrText("QR TEXT");
		orderDTO.setOrderStatusId(OrderDAO.ST_PENDING);
		orderDTO.setOperationId(OrderDAO.OPER_REFRESH);
		orderDTO.setTimeout(300000);
		orderDTO.setUser("Test user");
		orderDTO.setIpAddress("127.0.0.28");
		orderDTO.setCenterOperation("testCenter");
		
		result = orderDAO.updateOrder(orderDTO);
		
		assertNotNull(result);
		
		orderDTO.setOrderId("6a5f8973-INVALID-NUM-9ada-7b7acf0a4da1");
		result = orderDAO.updateOrder(orderDTO);
		
		assertNull(result);
	}
}
